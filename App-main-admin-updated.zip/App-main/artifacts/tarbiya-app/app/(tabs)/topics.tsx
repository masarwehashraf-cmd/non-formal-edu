import React, { useState } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Platform,
  Modal, FlatList,
} from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { LinearGradient } from "expo-linear-gradient";
import { useApp } from "@/context/AppContext";

interface TopicActivity {
  id: string;
  name: string;
  description: string;
  duration: string;
  targetAge: string;
  materials: string;
  steps: string[];
  skills: string[];
  evaluation: string;
}

interface Topic {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  activities: TopicActivity[];
  skills: string[];
  ageRange: string;
  category: string;
  emoji: string;
}

const EDUCATIONAL_TOPICS: Topic[] = [
  {
    id: "1", title: "القيادة وصنع القرار", description: "تطوير مهارات القيادة وتعزيز القدرة على اتخاذ القرارات الصحيحة في المواقف المختلفة وبناء شخصية قيادية متوازنة.",
    icon: "award", color: "#E67E22", ageRange: "14-18 سنة", category: "مهارات شخصية", emoji: "🏆",
    skills: ["القيادة", "اتخاذ القرار", "التأثير", "الثقة بالنفس"],
    activities: [
      {
        id: "1-1", name: "لعبة القائد الصامت",
        description: "نشاط يتحدى المشاركين لقيادة مجموعتهم دون استخدام الكلام — باستخدام الإيماءات وحركات الجسد فقط.",
        duration: "40 دقيقة", targetAge: "14-18 سنة", materials: "عصابات العيون، مكعبات بناء، بطاقات التعليمات",
        steps: ["قسّم المجموعة إلى فرق من 5 أشخاص", "اختر قائداً لكل فريق — القائد لا يتكلم طوال النشاط", "أعطِ كل فريق تعليمات لبناء هيكل معين", "القائد يوجه فريقه بالإشارات فقط", "الفريق الذي ينهي التحدي أولاً يفوز", "ناقش: ما الصعوبات؟ كيف تواصلتم؟"],
        skills: ["القيادة غير اللفظية", "الثقة المتبادلة", "التنسيق الجماعي"],
        evaluation: "مدى نجاح المجموعة في إتمام المهمة، جودة القيادة غير اللفظية، مستوى الثقة بين الأعضاء",
      },
      {
        id: "1-2", name: "سيناريو صنع القرار تحت الضغط",
        description: "يواجه المشاركون مواقف حياتية واقعية تستوجب اتخاذ قرارات سريعة وحكيمة تحت ضغط الوقت.",
        duration: "60 دقيقة", targetAge: "15-18 سنة", materials: "بطاقات السيناريوهات، ورقة قرار لكل مجموعة، أقلام",
        steps: ["اشرح مفهوم صنع القرار (10 دق)", "وزّع بطاقات السيناريو على كل مجموعة", "كل مجموعة تناقش ثم تكتب قرارها في 10 دقائق", "عروض تقديمية: كل مجموعة تشرح قرارها ولماذا", "مناقشة جماعية حول أفضل القرارات", "تلخيص الدروس المستخلصة"],
        skills: ["صنع القرار تحت ضغط", "التفكير النقدي", "التبرير المنطقي"],
        evaluation: "جودة القرار المتخذ، وضوح التبرير، الأخذ بعين الاعتبار لجميع الأطراف",
      },
      {
        id: "1-3", name: "مجلس قيادة الطلاب",
        description: "يقوم الطلاب بتشكيل مجلس طلابي وهمي ويحاولون اتخاذ قرارات مؤسسية حقيقية لمدرستهم.",
        duration: "90 دقيقة", targetAge: "15-18 سنة", materials: "جدول أعمال، ورق التصويت، بطاقات الأدوار",
        steps: ["توزيع الأدوار: رئيس، نائب، أمين سر، أعضاء", "قراءة قضايا المدرسة وتحديدها", "كل عضو يطرح مقترحاً وحجته", "التصويت على المقترحات بشكل ديمقراطي", "كتابة قرارات المجلس رسمياً", "تقييم: ما الذي سيتغير لو طُبّقت هذه القرارات؟"],
        skills: ["القيادة المؤسسية", "الديمقراطية", "التفاوض", "الحوكمة"],
        evaluation: "جودة الحوار والنقاش، ديمقراطية التصويت، واقعية المقترحات المقدمة",
      },
    ],
  },
  {
    id: "2", title: "التفكير الإبداعي والابتكار", description: "تنمية التفكير خارج الصندوق وتحفيز الإبداع من خلال أنشطة متنوعة وتحديات مبتكرة تُطلق خيال المشاركين.",
    icon: "zap", color: "#9B59B6", ageRange: "10-18 سنة", category: "مهارات معرفية", emoji: "💡",
    skills: ["الإبداع", "الابتكار", "التفكير النقدي", "الخيال"],
    activities: [
      {
        id: "2-1", name: "العصف الذهني الملوّن",
        description: "كل مشارك يكتب أفكاراً على ملاحظات ملونة مختلفة حسب نوع الفكرة، ثم يُصنَّف ويُرتَّب الجميع معاً.",
        duration: "45 دقيقة", targetAge: "12-18 سنة", materials: "ملاحظات لاصقة ملونة (4 ألوان)، أقلام، لوح أبيض كبير",
        steps: ["اشرح القواعد: لا نقد أثناء العصف", "لون أصفر: أفكار عملية · أخضر: أفكار جريئة · أزرق: أسئلة · أحمر: مخاوف", "عصف فردي صامت 10 دقائق — كل شخص يكتب أفكاره", "الصق الملاحظات على اللوح حسب اللون", "ناقش الأفكار وصوّت على الأفضل", "خلاصة: أفضل 3 أفكار للتنفيذ"],
        skills: ["الإبداع الحر", "تصنيف الأفكار", "التقييم الجماعي"],
        evaluation: "كمية الأفكار المطروحة، تنوعها، جودة النقاش، الفكرة الفائزة",
      },
      {
        id: "2-2", name: "تحدي المخترع الصغير",
        description: "المشاركون يصنعون أداة مبتكرة من مواد بسيطة تحل مشكلة يومية حقيقية في حياتهم.",
        duration: "90 دقيقة", targetAge: "10-15 سنة", materials: "ورق مقوى، مقص، غراء، شريط لاصق، خيوط، مواد إعادة تدوير",
        steps: ["تحديد مشكلة يومية يريد حلها (15 دق)", "رسم تصميم الحل على الورق (15 دق)", "بناء النموذج الأولي من المواد (40 دق)", "اختبار الاختراع هل يعمل؟ (10 دق)", "عرض الاختراع أمام الجميع + تصويت (10 دق)"],
        skills: ["التفكير التصميمي", "حل المشكلات", "الإبداع التطبيقي"],
        evaluation: "وضوح المشكلة المحددة، إبداع الحل، عملية التنفيذ، جودة العرض",
      },
    ],
  },
  {
    id: "3", title: "التواصل الفعّال", description: "تعزيز مهارات التواصل اللفظي وغير اللفظي والاستماع الفعّال وفن الحوار البنّاء مع الآخرين.",
    icon: "message-circle", color: "#3498DB", ageRange: "12-18 سنة", category: "مهارات اجتماعية", emoji: "💬",
    skills: ["التحدث العام", "الاستماع الفعّال", "لغة الجسد", "الحوار"],
    activities: [
      {
        id: "3-1", name: "ألعاب الاستماع الفعّال",
        description: "سلسلة من التمارين التي تختبر مدى قدرة المشاركين على الاستماع الحقيقي لا مجرد الانتظار للكلام.",
        duration: "50 دقيقة", targetAge: "12-18 سنة", materials: "بطاقات التعليمات، ورقة تسجيل، قلم",
        steps: ["لعبة الهاتف المكسور: ابدأ بجملة مركبة ومررها همساً", "لعبة الإعادة: كل شخص يُلخص ما قاله الشخص قبله بكلماته", "لعبة الأسئلة: المستمع يسأل 3 أسئلة عما سمع", "تقييم: من كان الأفضل استماعاً ولماذا؟"],
        skills: ["الاستماع النشط", "التركيز", "إعادة الصياغة"],
        evaluation: "دقة نقل المعلومة، جودة الأسئلة المطروحة، الحضور الذهني",
      },
      {
        id: "3-2", name: "عرضي في دقيقة واحدة",
        description: "كل مشارك يعرض فكرة أو موضوعاً بأقصى إقناع في دقيقة واحدة فقط أمام الجميع.",
        duration: "60 دقيقة", targetAge: "14-18 سنة", materials: "موضوعات مكتوبة على بطاقات، مؤقت، لائحة تقييم",
        steps: ["وزّع الموضوعات عشوائياً (5 دق للتحضير)", "كل مشارك يقف ويعرض لمدة دقيقة واحدة فقط", "الجمهور يصوت على مدى الإقناع (1-5)", "نقاش جماعي: ماذا أضاف المتحدث؟ ماذا نقص؟", "تكرار الجولة مع التحسينات"],
        skills: ["الخطابة", "الإيجاز", "الإقناع", "لغة الجسد"],
        evaluation: "وضوح الفكرة، الإقناع، لغة الجسد، التواصل البصري مع الجمهور",
      },
    ],
  },
  {
    id: "4", title: "العمل التطوعي والمواطنة", description: "تعزيز قيم المواطنة والانتماء وتنمية روح التطوع والمسؤولية الاجتماعية نحو المجتمع.",
    icon: "heart", color: "#E74C3C", ageRange: "جميع الأعمار", category: "قيم ومواطنة", emoji: "❤️",
    skills: ["المسؤولية", "الانتماء", "التضامن", "خدمة المجتمع"],
    activities: [
      {
        id: "4-1", name: "خريطة مجتمعنا",
        description: "المشاركون يرسمون خريطة لمجتمعهم ويحددون مشكلاته الفعلية ثم يقترحون حلولاً تطوعية قابلة للتطبيق.",
        duration: "75 دقيقة", targetAge: "13-18 سنة", materials: "ورق كبير A0، أقلام ملونة، ملصقات، صور من المجتمع",
        steps: ["ناقش: ما هي مشكلات مجتمعنا الحقيقية؟", "ارسموا خريطة مجتمعكم بالمناطق والمرافق", "ضعوا نجمة حمراء على كل مشكلة تجدونها", "اقترحوا حلاً تطوعياً لكل مشكلة", "حددوا مهمة واحدة قابلة للتنفيذ الآن", "اكتبوا خطة التطوع مع توزيع الأدوار"],
        skills: ["التفكير المجتمعي", "حل المشكلات", "التخطيط التطوعي"],
        evaluation: "واقعية المشكلات المحددة، إبداع الحلول، وضوح خطة التطوع",
      },
      {
        id: "4-2", name: "يوم العطاء",
        description: "يوم كامل يقضيه الطلاب في خدمة مجتمعهم من خلال مبادرات متنوعة: تنظيف، زراعة، زيارة مسنّين، مساعدة ذوي الاحتياجات.",
        duration: "يوم كامل", targetAge: "جميع الأعمار", materials: "أدوات التنظيف، شتلات، هدايا رمزية، كاميرا للتوثيق",
        steps: ["تقسيم الطلاب إلى مجموعات حسب النشاط", "كل مجموعة تنفذ مبادرتها بشكل مستقل", "توثيق كل خطوة بالصور والملاحظات", "اجتماع ختامي: كل مجموعة تشارك تجربتها", "التقييم والتخطيط للمبادرة القادمة"],
        skills: ["التطوع", "العمل الميداني", "التعاطف", "المسؤولية"],
        evaluation: "مستوى المشاركة، الأثر الفعلي على المستفيدين، روح التطوع",
      },
    ],
  },
  {
    id: "5", title: "الصحة النفسية والرفاهية", description: "تطوير المهارات العاطفية وتعزيز الصحة النفسية والقدرة على إدارة الضغوط والتحديات اليومية.",
    icon: "smile", color: "#1ABC9C", ageRange: "10-18 سنة", category: "صحة ورفاهية", emoji: "🌿",
    skills: ["الذكاء العاطفي", "إدارة الضغوط", "التعاطف", "الصمود"],
    activities: [
      {
        id: "5-1", name: "دفتر المشاعر اليومي",
        description: "كل مشارك يكتب أو يرسم مشاعره اليومية في دفتر خاص ويشارك ما يريد مع المجموعة بشكل آمن.",
        duration: "30 دقيقة", targetAge: "10-16 سنة", materials: "دفاتر صغيرة، أقلام ملونة، بطاقات المشاعر",
        steps: ["قدّم بطاقات المشاعر المختلفة واشرح كلاً منها", "كل مشارك يختار 3 مشاعر يشعر بها اليوم", "يرسم أو يكتب عنها في دفتره الخاص (10 دق)", "من يريد يشارك الجماعة بما يريد فقط", "نقاش: كيف نتعامل مع المشاعر الصعبة؟"],
        skills: ["الوعي العاطفي", "التعبير الآمن", "التعاطف"],
        evaluation: "مستوى الانفتاح، عمق التعبير، جودة النقاش حول المشاعر",
      },
      {
        id: "5-2", name: "تقنيات إدارة الضغوط",
        description: "ورشة عملية لتعلم أساليب علمية وعملية للتعامل مع الضغوط اليومية والقلق المدرسي.",
        duration: "60 دقيقة", targetAge: "13-18 سنة", materials: "أوراق عمل، ألوان مائية، موسيقى هادئة، وسائد",
        steps: ["ما هي ضغوطك الأكثر شيوعاً؟ (كتابة فردية)", "شرح تقنية التنفس 4-7-8 وتطبيقها", "تمرين الاسترخاء التدريجي للعضلات (10 دق)", "رسم المشاعر والضغوط بالألوان (صرخة الفن)", "نقاش: ما الذي يساعدك شخصياً؟", "إعداد 'صندوق أدوات' شخصي للتعامل مع الضغوط"],
        skills: ["إدارة الضغط", "الوعي بالجسد", "الاسترخاء", "التنظيم الذاتي"],
        evaluation: "مستوى التطبيق العملي، الوعي بالمحفزات الشخصية، اكتساب أداة واحدة على الأقل",
      },
    ],
  },
  {
    id: "6", title: "البيئة والاستدامة", description: "توعية الطلاب بأهمية البيئة وتطوير مفاهيم الاستدامة والمسؤولية البيئية نحو الأرض والطبيعة.",
    icon: "globe", color: "#27AE60", ageRange: "جميع الأعمار", category: "قيم ومواطنة", emoji: "🌱",
    skills: ["الوعي البيئي", "التفكير المستدام", "المسؤولية"],
    activities: [
      {
        id: "6-1", name: "تحدي الأسبوع الأخضر",
        description: "مسابقة أسبوعية يتحدى فيها المشاركون بعضهم على تطبيق أكبر عدد من الممارسات البيئية في حياتهم.",
        duration: "أسبوع + جلسة ختامية 45 دق", targetAge: "جميع الأعمار", materials: "بطاقة التحديات، جدول تتبع، ختم خاص",
        steps: ["أعطِ كل مشارك قائمة بـ20 ممارسة بيئية يومية", "كل مشارك يضع علامة على ما يطبقه يومياً", "في نهاية الأسبوع: احسب النقاط", "جلسة مشاركة: ما الذي كان صعباً وما الذي كان سهلاً؟", "تكريم المتميزين وتحديد أهداف للشهر القادم"],
        skills: ["الاستدامة", "المسؤولية الشخصية", "الوعي البيئي"],
        evaluation: "عدد الممارسات البيئية اليومية المطبقة، الالتزام طوال الأسبوع",
      },
      {
        id: "6-2", name: "مشروع إعادة التدوير الإبداعي",
        description: "تحويل النفايات إلى أعمال فنية وأدوات نافعة من خلال ورشة عمل إبداعية تجمع البيئة والفن معاً.",
        duration: "120 دقيقة", targetAge: "8-18 سنة", materials: "زجاجات فارغة، علب كرتون، خيوط، غراء، ألوان",
        steps: ["جمع المواد المعاد تدويرها قبل الجلسة", "إلهام: عرض أمثلة على التدوير الإبداعي", "كل فريق يبتكر مشروعاً من المواد المتاحة (60 دق)", "عرض المشاريع وشرح الفكرة", "تصويت: أجمل مشروع + أكثر مشروع نفعاً"],
        skills: ["الإبداع", "الوعي البيئي", "التفكير المستدام"],
        evaluation: "إبداع المشروع، الاستفادة من المواد، الرسالة البيئية الواضحة",
      },
    ],
  },
  {
    id: "7", title: "الفنون والثقافة", description: "تنمية الحس الجمالي والتذوق الفني من خلال الفنون البصرية والموسيقى والمسرح والتراث.",
    icon: "feather", color: "#F39C12", ageRange: "6-18 سنة", category: "إبداع وفنون", emoji: "🎨",
    skills: ["التعبير الإبداعي", "التذوق الفني", "الثقة بالنفس"],
    activities: [
      {
        id: "7-1", name: "مسرحية دقيقة واحدة",
        description: "مجموعات تمثل قصصاً قصيرة معبّرة في 60 ثانية فقط باستخدام الإيماءات والتعابير.",
        duration: "70 دقيقة", targetAge: "10-18 سنة", materials: "بطاقات القصص، موقت، كراسي للجمهور",
        steps: ["قسّم إلى مجموعات من 3-4 أشخاص", "كل مجموعة تسحب بطاقة فيها قصة قصيرة (10 دق تحضير)", "كل مجموعة تمثل القصة في 60 ثانية بالضبط", "الجمهور يخمن القصة ويقيّم التعبير", "نقاش: كيف نعبّر عن مشاعر بلا كلام؟"],
        skills: ["التعبير الجسدي", "الإبداع المسرحي", "التعاون"],
        evaluation: "وضوح القصة، قوة التعبير، التعاون بين الأعضاء، ردة فعل الجمهور",
      },
    ],
  },
  {
    id: "8", title: "التكنولوجيا والبرمجة", description: "تعريف الطلاب بأساسيات التكنولوجيا والبرمجة في إطار تربوي ممتع وتفاعلي يُعدّهم لمستقبل رقمي.",
    icon: "monitor", color: "#2C3E50", ageRange: "10-18 سنة", category: "مهارات معرفية", emoji: "💻",
    skills: ["التفكير المنطقي", "حل المشكلات", "الإبداع الرقمي"],
    activities: [
      {
        id: "8-1", name: "البرمجة بدون حاسوب",
        description: "تعلم مفاهيم البرمجة (التسلسل، الحلقات، الشروط) من خلال أنشطة حركية لا تحتاج جهازاً.",
        duration: "60 دقيقة", targetAge: "10-15 سنة", materials: "بطاقات الأوامر، أقلام، مخطط الخوارزمية",
        steps: ["اشرح مفهوم البرنامج كتسلسل أوامر (10 دق)", "نشاط البشري الآلي: شخص يُبرمَج ويتبع الأوامر حرفياً", "تحدي: اكتب أوامراً لتحضير كوب شاي خطوة بخطوة", "مناقشة: ماذا لو كانت الأوامر غير واضحة؟", "خلاصة: الحاسوب يفعل فقط ما تأمره به بدقة تامة"],
        skills: ["التفكير المنطقي", "التسلسل", "الدقة"],
        evaluation: "وضوح الأوامر المكتوبة، منطقية التسلسل، القدرة على إيجاد الأخطاء",
      },
    ],
  },
  {
    id: "9", title: "التربية الرياضية والحركية", description: "تعزيز اللياقة البدنية وروح الرياضة وقيم التنافس الشريف والعمل الجماعي والاحترام المتبادل.",
    icon: "trending-up", color: "#E91E63", ageRange: "جميع الأعمار", category: "صحة ورفاهية", emoji: "⚽",
    skills: ["اللياقة البدنية", "روح الرياضة", "التعاون"],
    activities: [
      {
        id: "9-1", name: "أولمبياد التعاون",
        description: "سلسلة من الألعاب الجماعية حيث الهدف ليس الفوز الفردي بل إتمام المهام معاً كفريق واحد.",
        duration: "90 دقيقة", targetAge: "جميع الأعمار", materials: "حبل، بالونات، أكياس، أعلام ملونة",
        steps: ["قسّم إلى فرق مختلطة من 6 أشخاص", "لعبة 1: نقل البالون بدون اليدين (5 دق)", "لعبة 2: عبور الوادي بلوح واحد (15 دق)", "لعبة 3: الشبكة البشرية — لا أحد يُلمس (20 دق)", "لعبة 4: بناء برج أعلى من المواد (20 دق)", "تكريم جماعي: كل الفرق تفوز بالتعاون!"],
        skills: ["التعاون", "التنسيق", "التخطيط المشترك"],
        evaluation: "مستوى التعاون، الأداء الجماعي، الروح الرياضية، التعامل مع الإخفاق",
      },
    ],
  },
  {
    id: "10", title: "التربية المالية", description: "تثقيف الطلاب بمفاهيم المال والاقتصاد وتطوير المهارات المالية الأساسية للحياة المستقلة.",
    icon: "dollar-sign", color: "#16A085", ageRange: "12-18 سنة", category: "مهارات معرفية", emoji: "💰",
    skills: ["الوعي المالي", "التخطيط", "الادخار"],
    activities: [
      {
        id: "10-1", name: "محاكاة السوق",
        description: "بيئة تجارية مصغرة يبيع فيها المشاركون ويشترون منتجات وهمية ليتعلموا مبادئ الاقتصاد بشكل تجريبي.",
        duration: "90 دقيقة", targetAge: "13-18 سنة", materials: "عملة ورقية مصنوعة يدوياً، بطاقات المنتجات، طاولات للبيع",
        steps: ["أعطِ كل مشارك ميزانية بداية (10 وحدات مالية)", "كل شخص يختار ماذا يبيع (بطاقات منتجات)", "افتح السوق لمدة 30 دقيقة — بيع وشراء حر", "أغلق السوق: من ربح أكثر؟ من خسر؟ لماذا؟", "نقاش: العرض والطلب، الادخار، الاستثمار الذكي"],
        skills: ["الوعي المالي", "التفاوض", "اتخاذ قرار اقتصادي"],
        evaluation: "نتيجة التداول، جودة القرارات المالية، الفهم المفاهيمي في النقاش",
      },
    ],
  },
  {
    id: "11", title: "حل النزاعات والوساطة", description: "تعلم مهارات إدارة الخلافات والوساطة وتحقيق السلام الاجتماعي من خلال الحوار والتفاهم.",
    icon: "shuffle", color: "#8E44AD", ageRange: "12-18 سنة", category: "مهارات اجتماعية", emoji: "🤝",
    skills: ["الوساطة", "الاستماع", "التعاطف"],
    activities: [
      {
        id: "11-1", name: "محكمة الطلاب",
        description: "سيناريو نزاع خيالي يؤدي فيه المشاركون أدوار القاضي والوسيط والأطراف المتنازعة لإيجاد حل عادل.",
        duration: "75 دقيقة", targetAge: "14-18 سنة", materials: "بطاقات الأدوار، سيناريو النزاع، مطرقة القاضي الرمزية",
        steps: ["اقرأ سيناريو النزاع على الجميع (5 دق)", "وزّع الأدوار: طرف أ، طرف ب، وسيط، قاضي، جمهور (شهود)", "كل طرف يعرض موقفه 5 دقائق", "الوسيط يحاول إيجاد أرضية مشتركة", "القاضي يصدر قراراً مسبّباً", "نقاش: هل كان القرار عادلاً؟ ماذا كنت ستفعل؟"],
        skills: ["الوساطة", "الإنصاف", "التفكير القانوني", "التعاطف"],
        evaluation: "عدالة الحل المقترح، مهارة الوسيط، جودة حجج كل طرف",
      },
    ],
  },
  {
    id: "12", title: "ريادة الأعمال", description: "تنمية روح المبادرة وتطوير المهارات الريادية وتشجيع التفكير الاستثماري والمشاريع الصغيرة.",
    icon: "briefcase", color: "#D35400", ageRange: "14-18 سنة", category: "مهارات شخصية", emoji: "🚀",
    skills: ["المبادرة", "الإبداع", "التخطيط", "الإقناع"],
    activities: [
      {
        id: "12-1", name: "عرض الفكرة — Dragon's Den",
        description: "كل مشارك أو فريق يعرض فكرة مشروعه أمام لجنة من المستثمرين الوهميين ويحاول إقناعهم بالاستثمار.",
        duration: "90 دقيقة", targetAge: "14-18 سنة", materials: "ورقة خطة العمل، شاشة عرض، لجنة المحكمين (3 أشخاص)",
        steps: ["اشرح مكونات خطة العمل البسيطة (15 دق)", "الفرق تحضر فكرة مشروعها في 20 دقيقة", "كل فريق يعرض 5 دقائق + 5 دقائق أسئلة", "المستثمرون يقررون: هل يستثمرون؟ بكم؟ لماذا؟", "تكريم الفكرة الأكثر إقناعاً وجدوى"],
        skills: ["ريادة الأعمال", "الإقناع", "التخطيط التجاري", "الثقة بالنفس"],
        evaluation: "وضوح الفكرة، جدواها، قوة العرض، الإجابة على الأسئلة بثقة",
      },
    ],
  },
];

const CATEGORIES = ["الكل", "مهارات شخصية", "مهارات معرفية", "مهارات اجتماعية", "قيم ومواطنة", "صحة ورفاهية", "إبداع وفنون"];

function ActivityDetailModal({ activity, color, onClose }: { activity: TopicActivity; color: string; onClose: () => void }) {
  const colors = useColors();
  return (
    <Modal visible animationType="slide" transparent presentationStyle="overFullScreen">
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" }}>
        <View style={{ height: "95%", backgroundColor: colors.background, borderTopLeftRadius: 28, borderTopRightRadius: 28 }}>
          <LinearGradient colors={[color + "30", color + "08"]} style={{ borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12 }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: color + "60", alignSelf: "center", marginBottom: 14 }} />
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
              <View style={{ flex: 1, marginRight: 12 }}>
                <Text style={{ fontSize: 18, color: colors.text, fontFamily: "Inter_700Bold", lineHeight: 24, marginBottom: 8 }}>{activity.name}</Text>
                <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
                  <View style={{ backgroundColor: color, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 }}>
                    <Text style={{ fontSize: 11, color: "#fff", fontFamily: "Inter_600SemiBold" }}>⏱ {activity.duration}</Text>
                  </View>
                  <View style={{ backgroundColor: colors.card, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 }}>
                    <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>👥 {activity.targetAge}</Text>
                  </View>
                </View>
              </View>
              <TouchableOpacity onPress={onClose} style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: colors.card, alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 }}>
                <Feather name="x" size={20} color={colors.text} />
              </TouchableOpacity>
            </View>
          </LinearGradient>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
            <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular", lineHeight: 20, marginBottom: 20 }}>{activity.description}</Text>
            {/* Materials */}
            <SectionCard icon="package" title="المواد والأدوات اللازمة" color={color}>
              {activity.materials.split("،").map((m, i) => (
                <View key={i} style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 6 }}>
                  <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: color }} />
                  <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_400Regular", flex: 1 }}>{m.trim()}</Text>
                </View>
              ))}
            </SectionCard>
            {/* Steps */}
            <SectionCard icon="list" title="خطوات التنفيذ التفصيلية" color={color}>
              {activity.steps.map((step, i) => (
                <View key={i} style={{ flexDirection: "row", alignItems: "flex-start", gap: 10, marginBottom: 10 }}>
                  <View style={{ width: 28, height: 28, borderRadius: 9, backgroundColor: color, alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 1 }}>
                    <Text style={{ fontSize: 13, color: "#fff", fontFamily: "Inter_700Bold" }}>{i + 1}</Text>
                  </View>
                  <Text style={{ flex: 1, fontSize: 13, color: colors.text, fontFamily: "Inter_400Regular", lineHeight: 20, paddingTop: 4 }}>{step}</Text>
                </View>
              ))}
            </SectionCard>
            {/* Skills */}
            <SectionCard icon="star" title="المهارات المكتسبة" color={color}>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                {activity.skills.map((s, i) => (
                  <View key={i} style={{ backgroundColor: color + "20", paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, flexDirection: "row", alignItems: "center", gap: 5 }}>
                    <Feather name="check" size={11} color={color} />
                    <Text style={{ fontSize: 12, color, fontFamily: "Inter_600SemiBold" }}>{s}</Text>
                  </View>
                ))}
              </View>
            </SectionCard>
            {/* Evaluation */}
            <View style={{ backgroundColor: color + "15", borderRadius: 16, padding: 16, borderWidth: 1.5, borderColor: color + "40" }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 }}>
                <View style={{ width: 32, height: 32, borderRadius: 10, backgroundColor: color + "30", alignItems: "center", justifyContent: "center" }}>
                  <Feather name="bar-chart-2" size={16} color={color} />
                </View>
                <Text style={{ fontSize: 14, color: colors.text, fontFamily: "Inter_700Bold" }}>معايير التقييم</Text>
              </View>
              <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_400Regular", lineHeight: 20 }}>{activity.evaluation}</Text>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

function SectionCard({ icon, title, color, children }: { icon: string; title: string; color: string; children: React.ReactNode }) {
  const colors = useColors();
  return (
    <View style={{ backgroundColor: colors.card, borderRadius: 16, padding: 14, marginBottom: 14, borderWidth: 1, borderColor: colors.border }}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 }}>
        <View style={{ width: 32, height: 32, borderRadius: 10, backgroundColor: color + "20", alignItems: "center", justifyContent: "center" }}>
          <Feather name={icon as any} size={15} color={color} />
        </View>
        <Text style={{ fontSize: 14, color: colors.text, fontFamily: "Inter_700Bold" }}>{title}</Text>
      </View>
      {children}
    </View>
  );
}

function TopicModal({ topic, onSelectActivity, onClose }: { topic: Topic; onSelectActivity: (a: TopicActivity) => void; onClose: () => void }) {
  const colors = useColors();
  return (
    <Modal visible animationType="slide" transparent presentationStyle="overFullScreen">
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
        <View style={{ backgroundColor: colors.background, borderTopLeftRadius: 28, borderTopRightRadius: 28, maxHeight: "92%", paddingBottom: Platform.OS === "web" ? 24 : 48 }}>
          <LinearGradient colors={[topic.color + "30", topic.color + "08"]} style={{ borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 20 }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: topic.color + "60", alignSelf: "center", marginBottom: 14 }} />
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12, flex: 1 }}>
                <View style={{ width: 56, height: 56, borderRadius: 16, backgroundColor: topic.color + "30", alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ fontSize: 28 }}>{topic.emoji}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 18, color: colors.text, fontFamily: "Inter_700Bold" }}>{topic.title}</Text>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 }}>
                    <View style={{ backgroundColor: topic.color, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 }}>
                      <Text style={{ fontSize: 10, color: "#fff", fontFamily: "Inter_600SemiBold" }}>{topic.category}</Text>
                    </View>
                    <Text style={{ fontSize: 10, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>👥 {topic.ageRange}</Text>
                  </View>
                </View>
              </View>
              <TouchableOpacity onPress={onClose} style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.card, alignItems: "center", justifyContent: "center" }}>
                <Feather name="x" size={20} color={colors.text} />
              </TouchableOpacity>
            </View>
          </LinearGradient>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}>
            <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular", lineHeight: 20, marginBottom: 16 }}>{topic.description}</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, marginBottom: 20 }}>
              {topic.skills.map((s, i) => (
                <View key={i} style={{ backgroundColor: topic.color + "20", paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20, flexDirection: "row", alignItems: "center", gap: 4 }}>
                  <Feather name="check" size={10} color={topic.color} />
                  <Text style={{ fontSize: 11, color: topic.color, fontFamily: "Inter_600SemiBold" }}>{s}</Text>
                </View>
              ))}
            </View>
            <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 12 }}>
              الأنشطة التفصيلية ({topic.activities.length})
            </Text>
            {topic.activities.map((act) => (
              <View key={act.id} style={{ backgroundColor: colors.card, borderRadius: 18, marginBottom: 12, overflow: "hidden", borderWidth: 1, borderColor: topic.color + "30", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.07, shadowRadius: 8, elevation: 3 }}>
                <LinearGradient colors={[topic.color + "18", topic.color + "05"]} style={{ padding: 14 }}>
                  <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                    <Text style={{ flex: 1, fontSize: 14, color: colors.text, fontFamily: "Inter_700Bold", marginRight: 10, lineHeight: 20 }}>{act.name}</Text>
                    <View style={{ backgroundColor: topic.color, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 }}>
                      <Text style={{ fontSize: 10, color: "#fff", fontFamily: "Inter_600SemiBold" }}>{act.duration}</Text>
                    </View>
                  </View>
                  <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular", lineHeight: 18, marginBottom: 10 }} numberOfLines={2}>{act.description}</Text>
                  <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 5, marginBottom: 12 }}>
                    {act.skills.slice(0, 3).map((s, i) => (
                      <View key={i} style={{ backgroundColor: colors.background, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20 }}>
                        <Text style={{ fontSize: 10, color: topic.color, fontFamily: "Inter_500Medium" }}>{s}</Text>
                      </View>
                    ))}
                  </View>
                  <TouchableOpacity
                    onPress={() => onSelectActivity(act)}
                    style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: topic.color, borderRadius: 12, paddingVertical: 11 }}
                    activeOpacity={0.85}
                  >
                    <Feather name="book-open" size={14} color="#fff" />
                    <Text style={{ fontSize: 13, color: "#fff", fontFamily: "Inter_700Bold" }}>عرض الخطوات والمواد التفصيلية</Text>
                    <Feather name="chevron-left" size={14} color="#fff" />
                  </TouchableOpacity>
                </LinearGradient>
              </View>
            ))}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

export default function TopicsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { appSettings } = useApp();
  const [selectedCategory, setSelectedCategory] = useState("الكل");
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);
  const [selectedActivity, setSelectedActivity] = useState<TopicActivity | null>(null);

  const topPad = insets.top;
  const bottomPad = Platform.OS === "web" ? 84 + 16 : 90 + insets.bottom;

  const filtered = selectedCategory === "الكل"
    ? EDUCATIONAL_TOPICS
    : EDUCATIONAL_TOPICS.filter((t) => t.category === selectedCategory);

  const handleSelectActivity = (act: TopicActivity) => {
    setSelectedActivity(act);
  };

  const handleCloseActivity = () => {
    setSelectedActivity(null);
  };

  const handleCloseTopic = () => {
    setSelectedTopic(null);
    setSelectedActivity(null);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient colors={[colors.primary + "15", colors.background]} style={[styles.header, { paddingTop: topPad + 16, borderBottomColor: colors.border }]}>
        <Text style={[styles.screenTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{appSettings.topicsPageTitle}</Text>
        <Text style={[styles.screenSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
          {EDUCATIONAL_TOPICS.length} موضوع · اضغط على موضوع لعرض أنشطته التفصيلية
        </Text>
        <FlatList
          horizontal showsHorizontalScrollIndicator={false}
          data={CATEGORIES} keyExtractor={(c) => c}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => setSelectedCategory(item)}
              style={[styles.catChip, { backgroundColor: selectedCategory === item ? colors.primary : colors.card, borderColor: selectedCategory === item ? colors.primary : colors.border }]}
            >
              <Text style={[styles.catText, { color: selectedCategory === item ? "#fff" : colors.text, fontFamily: "Inter_500Medium" }]}>{item}</Text>
            </TouchableOpacity>
          )}
          style={{ marginTop: 12 }}
        />
      </LinearGradient>
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        numColumns={2}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.topicCard, { backgroundColor: colors.card, borderColor: item.color + "40" }]}
            onPress={() => setSelectedTopic(item)}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[item.color + "20", item.color + "05"]} style={styles.topicCardGradient}>
              <View style={[styles.emojiCircle, { backgroundColor: item.color + "25" }]}>
                <Text style={styles.emoji}>{item.emoji}</Text>
              </View>
              <Text style={[styles.topicTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]} numberOfLines={2}>{item.title}</Text>
              <View style={[styles.catBadge, { backgroundColor: item.color + "20" }]}>
                <Text style={[styles.catBadgeText, { color: item.color, fontFamily: "Inter_600SemiBold" }]}>{item.category}</Text>
              </View>
              <Text style={[styles.topicDesc, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]} numberOfLines={2}>{item.description}</Text>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginBottom: 8 }}>
                <Feather name="layers" size={10} color={item.color} />
                <Text style={{ fontSize: 10, color: item.color, fontFamily: "Inter_600SemiBold" }}>{item.activities.length} أنشطة تفصيلية</Text>
              </View>
              <View style={[styles.viewBtn, { backgroundColor: item.color }]}>
                <Text style={[styles.viewBtnText, { fontFamily: "Inter_700Bold" }]}>عرض التفاصيل</Text>
                <Feather name="arrow-left" size={13} color="#fff" />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        )}
        contentContainerStyle={{ padding: 12, paddingBottom: bottomPad }}
        columnWrapperStyle={{ gap: 12 }}
        showsVerticalScrollIndicator={false}
      />
      {selectedTopic && !selectedActivity && (
        <TopicModal
          topic={selectedTopic}
          onSelectActivity={handleSelectActivity}
          onClose={handleCloseTopic}
        />
      )}
      {selectedActivity && selectedTopic && (
        <ActivityDetailModal
          activity={selectedActivity}
          color={selectedTopic.color}
          onClose={handleCloseActivity}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 14, borderBottomWidth: 1 },
  screenTitle: { fontSize: 22 },
  screenSub: { fontSize: 12, marginTop: 4 },
  catChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, marginRight: 8, borderWidth: 1 },
  catText: { fontSize: 12 },
  topicCard: { flex: 1, borderRadius: 20, borderWidth: 1.5, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 12, elevation: 5 },
  topicCardGradient: { padding: 14, gap: 8 },
  emojiCircle: { width: 52, height: 52, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  emoji: { fontSize: 26 },
  topicTitle: { fontSize: 14, lineHeight: 20 },
  catBadge: { alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 },
  catBadgeText: { fontSize: 10 },
  topicDesc: { fontSize: 11, lineHeight: 16 },
  viewBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, paddingVertical: 9, borderRadius: 12 },
  viewBtnText: { color: "#fff", fontSize: 12 },
});

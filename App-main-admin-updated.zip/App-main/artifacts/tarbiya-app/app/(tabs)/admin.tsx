import React, { useState } from "react";
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet, Platform,
  Alert, Modal, ScrollView, Switch, TextInput,
} from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/context/AuthContext";
import { useApp, ROLE_LABELS, ROLE_PERMISSIONS, ALL_PERMISSION_KEYS, normalizePermissions, RolePermissions, CustomRole, UserRole } from "@/context/AppContext";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

const ROLE_COLORS: Record<string, string> = {
  student: "#3498DB", teacher: "#9B59B6", supervisor: "#E67E22", admin: "#E74C3C",
};
const STANDARD_ROLES: UserRole[] = ["student", "teacher", "supervisor", "admin"];

function UserPermissionsModal({ user, baseRole, currentPerms, onClose, onSave }: {
  user: { fullName: string; username: string }; baseRole: UserRole;
  currentPerms: Partial<RolePermissions>; onClose: () => void;
  onSave: (perms: Partial<RolePermissions>) => void;
}) {
  const colors = useColors();
  const base = normalizePermissions(ROLE_PERMISSIONS[baseRole] || ROLE_PERMISSIONS.student);
  const [overrides, setOverrides] = useState<Partial<RolePermissions>>(currentPerms || {});

  const toggle = (key: keyof RolePermissions) => {
    const current = key in overrides ? overrides[key] : base[key];
    setOverrides(prev => ({ ...prev, [key]: !current }));
  };

  const getValue = (key: keyof RolePermissions) => key in overrides ? overrides[key] : base[key];

  const groups = [...new Set(ALL_PERMISSION_KEYS.map(p => p.group))];

  return (
    <Modal visible animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.55)" }}>
        <View style={{ flex: 1, marginTop: 60, backgroundColor: colors.background, borderTopLeftRadius: 28, borderTopRightRadius: 28 }}>
          <View style={{ padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <View>
              <Text style={{ fontSize: 17, color: colors.text, fontFamily: "Inter_700Bold" }}>صلاحيات {user.fullName}</Text>
              <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginTop: 2 }}>
                الدور الأساسي: {ROLE_LABELS[baseRole] || baseRole} · التعديلات تُطبَّق فوراً
              </Text>
            </View>
            <TouchableOpacity onPress={onClose} style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.card, alignItems: "center", justifyContent: "center" }}>
              <Feather name="x" size={18} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
            {groups.map(group => (
              <View key={group} style={{ marginBottom: 20 }}>
                <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_700Bold", marginBottom: 10, textTransform: "uppercase", letterSpacing: 0.5 }}>{group}</Text>
                {ALL_PERMISSION_KEYS.filter(p => p.group === group).map(({ key, label }) => {
                  const val = getValue(key) as boolean;
                  const isOverridden = key in overrides;
                  return (
                    <View key={key} style={{ flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.card, borderRadius: 14, padding: 12, marginBottom: 8, borderWidth: 1, borderColor: isOverridden ? "#9B59B650" : colors.border }}>
                      <View style={{ flex: 1 }}>
                        <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_600SemiBold" }}>{label}</Text>
                        {isOverridden && (
                          <Text style={{ fontSize: 10, color: "#9B59B6", fontFamily: "Inter_400Regular", marginTop: 2 }}>✏️ تم تعديله يدوياً</Text>
                        )}
                      </View>
                      <Switch value={val} onValueChange={() => { toggle(key); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
                        trackColor={{ false: colors.border, true: "#27AE6060" }}
                        thumbColor={val ? "#27AE60" : colors.mutedForeground} />
                    </View>
                  );
                })}
              </View>
            ))}
            <TouchableOpacity onPress={() => setOverrides({})} style={{ borderRadius: 14, padding: 12, borderWidth: 1, borderColor: colors.border, alignItems: "center", marginBottom: 12 }}>
              <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium", fontSize: 13 }}>♻️ إعادة تعيين لصلاحيات الدور الأساسي</Text>
            </TouchableOpacity>
          </ScrollView>
          <View style={{ padding: 20, borderTopWidth: 1, borderTopColor: colors.border }}>
            <TouchableOpacity onPress={() => onSave(overrides)} style={{ backgroundColor: "#E74C3C", borderRadius: 14, paddingVertical: 15, alignItems: "center" }} activeOpacity={0.85}>
              <Text style={{ color: "#fff", fontSize: 16, fontFamily: "Inter_700Bold" }}>حفظ الصلاحيات</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

function RoleModal({ currentRole, customRoles, onClose, onSave }: {
  currentRole: UserRole; customRoles: CustomRole[]; onClose: () => void; onSave: (role: UserRole) => void;
}) {
  const colors = useColors();
  const [selected, setSelected] = useState<UserRole>(currentRole);
  const allRoles = [...STANDARD_ROLES, ...customRoles.map(r => r.id)];

  return (
    <Modal visible animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
        <View style={{ backgroundColor: colors.card, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: Platform.OS === "web" ? 24 : 48, maxHeight: "80%" }}>
          <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border, alignSelf: "center", marginBottom: 20 }} />
          <Text style={{ fontSize: 18, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 16 }}>اختر دور المستخدم</Text>
          <ScrollView>
            {STANDARD_ROLES.map((role) => {
              const rc = ROLE_COLORS[role] || "#1B8A5A";
              const isSelected = selected === role;
              return (
                <TouchableOpacity key={role} onPress={() => setSelected(role)}
                  style={{ borderRadius: 14, padding: 12, marginBottom: 8, borderWidth: isSelected ? 2 : 1, borderColor: isSelected ? rc : colors.border, backgroundColor: isSelected ? rc + "15" : colors.background, flexDirection: "row", alignItems: "center", gap: 12 }} activeOpacity={0.8}>
                  <View style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: rc + "20", alignItems: "center", justifyContent: "center" }}>
                    <Feather name="shield" size={16} color={rc} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 14, color: colors.text, fontFamily: "Inter_700Bold" }}>{ROLE_LABELS[role]}</Text>
                  </View>
                  {isSelected && <View style={{ backgroundColor: rc, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}><Text style={{ color: "#fff", fontSize: 10, fontFamily: "Inter_700Bold" }}>محدد</Text></View>}
                </TouchableOpacity>
              );
            })}
            {customRoles.map((cr) => {
              const isSelected = selected === cr.id;
              return (
                <TouchableOpacity key={cr.id} onPress={() => setSelected(cr.id)}
                  style={{ borderRadius: 14, padding: 12, marginBottom: 8, borderWidth: isSelected ? 2 : 1, borderColor: isSelected ? cr.color : colors.border, backgroundColor: isSelected ? cr.color + "15" : colors.background, flexDirection: "row", alignItems: "center", gap: 12 }} activeOpacity={0.8}>
                  <View style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: cr.color + "20", alignItems: "center", justifyContent: "center" }}>
                    <MaterialCommunityIcons name="star-circle" size={16} color={cr.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 14, color: colors.text, fontFamily: "Inter_700Bold" }}>{cr.name}</Text>
                    <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>{cr.description || "دور مخصص"}</Text>
                  </View>
                  {isSelected && <View style={{ backgroundColor: cr.color, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}><Text style={{ color: "#fff", fontSize: 10, fontFamily: "Inter_700Bold" }}>محدد</Text></View>}
                </TouchableOpacity>
              );
            })}
          </ScrollView>
          <TouchableOpacity style={{ backgroundColor: "#E74C3C", borderRadius: 14, paddingVertical: 15, alignItems: "center", marginTop: 12 }} onPress={() => onSave(selected)} activeOpacity={0.85}>
            <Text style={{ color: "#fff", fontSize: 16, fontFamily: "Inter_700Bold" }}>حفظ الدور</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onClose} style={{ alignItems: "center", marginTop: 10, paddingVertical: 8 }}>
            <Text style={{ color: colors.mutedForeground, fontSize: 14 }}>إلغاء</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

function CreateRoleModal({ onClose, onSave }: { onClose: () => void; onSave: (role: Omit<CustomRole, "id" | "createdAt">) => void }) {
  const colors = useColors();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [color, setColor] = useState("#9B59B6");
  const [permissions, setPermissions] = useState<RolePermissions>(normalizePermissions(ROLE_PERMISSIONS.student));

  const PRESET_COLORS = ["#E74C3C", "#E67E22", "#27AE60", "#3498DB", "#9B59B6", "#1ABC9C", "#F39C12", "#2C3E50"];

  const toggle = (key: keyof RolePermissions) => {
    setPermissions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const submit = () => {
    if (!name.trim()) { Alert.alert("تنبيه", "اسم الرتبة مطلوب"); return; }
    onSave({ name: name.trim(), description: description.trim(), color, permissions });
    onClose();
  };

  const groups = [...new Set(ALL_PERMISSION_KEYS.map(p => p.group))];

  return (
    <Modal visible animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.55)" }}>
        <View style={{ flex: 1, marginTop: 60, backgroundColor: colors.background, borderTopLeftRadius: 28, borderTopRightRadius: 28 }}>
          <View style={{ padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <Text style={{ fontSize: 18, color: colors.text, fontFamily: "Inter_700Bold" }}>إنشاء رتبة جديدة</Text>
            <TouchableOpacity onPress={onClose} style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.card, alignItems: "center", justifyContent: "center" }}>
              <Feather name="x" size={18} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 6 }}>اسم الرتبة *</Text>
            <TextInput value={name} onChangeText={setName} placeholder="مثال: قائد مجموعة، منسق..." placeholderTextColor={colors.mutedForeground}
              style={{ backgroundColor: colors.card, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 14 }} />

            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 6 }}>وصف الرتبة</Text>
            <TextInput value={description} onChangeText={setDescription} placeholder="وصف مختصر لهذه الرتبة..." placeholderTextColor={colors.mutedForeground}
              style={{ backgroundColor: colors.card, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 14 }} />

            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 8 }}>لون الرتبة</Text>
            <View style={{ flexDirection: "row", gap: 10, marginBottom: 20 }}>
              {PRESET_COLORS.map(c => (
                <TouchableOpacity key={c} onPress={() => setColor(c)}
                  style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: c, borderWidth: color === c ? 3 : 0, borderColor: "#fff", shadowColor: c, shadowOpacity: 0.4, shadowRadius: 4, shadowOffset: { width: 0, height: 2 } }} />
              ))}
            </View>

            <Text style={{ fontSize: 14, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 14 }}>الصلاحيات</Text>
            {groups.map(group => (
              <View key={group} style={{ marginBottom: 16 }}>
                <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_700Bold", marginBottom: 8, letterSpacing: 0.5 }}>{group}</Text>
                {ALL_PERMISSION_KEYS.filter(p => p.group === group).map(({ key, label }) => (
                  <View key={key} style={{ flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.card, borderRadius: 12, padding: 10, marginBottom: 6 }}>
                    <Text style={{ flex: 1, fontSize: 12, color: colors.text, fontFamily: "Inter_400Regular" }}>{label}</Text>
                    <Switch value={!!permissions[key]} onValueChange={() => toggle(key)}
                      trackColor={{ false: colors.border, true: color + "60" }}
                      thumbColor={permissions[key] ? color : colors.mutedForeground} />
                  </View>
                ))}
              </View>
            ))}
          </ScrollView>
          <View style={{ padding: 20, borderTopWidth: 1, borderTopColor: colors.border }}>
            <TouchableOpacity onPress={submit} style={{ backgroundColor: color, borderRadius: 14, paddingVertical: 15, alignItems: "center" }} activeOpacity={0.85}>
              <Text style={{ color: "#fff", fontSize: 16, fontFamily: "Inter_700Bold" }}>إنشاء الرتبة</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

function EditRoleModal({ role, onClose, onSave }: { role: CustomRole; onClose: () => void; onSave: (updates: Partial<Omit<CustomRole, "id" | "createdAt">>) => void }) {
  const colors = useColors();
  const [name, setName] = useState(role.name);
  const [description, setDescription] = useState(role.description || "");
  const [color, setColor] = useState(role.color);
  const [permissions, setPermissions] = useState<RolePermissions>({ ...role.permissions });
  const PRESET_COLORS = ["#E74C3C", "#E67E22", "#27AE60", "#3498DB", "#9B59B6", "#1ABC9C", "#F39C12", "#2C3E50"];
  const toggle = (key: keyof RolePermissions) => { setPermissions(prev => ({ ...prev, [key]: !prev[key] })); };
  const submit = () => {
    if (!name.trim()) { Alert.alert("تنبيه", "اسم الرتبة مطلوب"); return; }
    onSave({ name: name.trim(), description: description.trim(), color, permissions });
    onClose();
  };
  const groups = [...new Set(ALL_PERMISSION_KEYS.map(p => p.group))];
  return (
    <Modal visible animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.55)" }}>
        <View style={{ flex: 1, marginTop: 60, backgroundColor: colors.background, borderTopLeftRadius: 28, borderTopRightRadius: 28 }}>
          <View style={{ padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <Text style={{ fontSize: 18, color: colors.text, fontFamily: "Inter_700Bold" }}>تعديل رتبة: {role.name}</Text>
            <TouchableOpacity onPress={onClose} style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.card, alignItems: "center", justifyContent: "center" }}>
              <Feather name="x" size={18} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 6 }}>اسم الرتبة *</Text>
            <TextInput value={name} onChangeText={setName} placeholder="اسم الرتبة..." placeholderTextColor={colors.mutedForeground}
              style={{ backgroundColor: colors.card, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 14 }} />
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 6 }}>وصف الرتبة</Text>
            <TextInput value={description} onChangeText={setDescription} placeholder="وصف مختصر..." placeholderTextColor={colors.mutedForeground}
              style={{ backgroundColor: colors.card, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 14 }} />
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 8 }}>لون الرتبة</Text>
            <View style={{ flexDirection: "row", gap: 10, marginBottom: 20 }}>
              {PRESET_COLORS.map(c => (
                <TouchableOpacity key={c} onPress={() => setColor(c)}
                  style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: c, borderWidth: color === c ? 3 : 0, borderColor: "#fff", shadowColor: c, shadowOpacity: 0.4, shadowRadius: 4, shadowOffset: { width: 0, height: 2 } }} />
              ))}
            </View>
            <Text style={{ fontSize: 14, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 14 }}>الصلاحيات</Text>
            {groups.map(group => (
              <View key={group} style={{ marginBottom: 16 }}>
                <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_700Bold", marginBottom: 8, letterSpacing: 0.5 }}>{group}</Text>
                {ALL_PERMISSION_KEYS.filter(p => p.group === group).map(({ key, label }) => (
                  <View key={key} style={{ flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.card, borderRadius: 12, padding: 10, marginBottom: 6 }}>
                    <Text style={{ flex: 1, fontSize: 12, color: colors.text, fontFamily: "Inter_400Regular" }}>{label}</Text>
                    <Switch value={!!permissions[key]} onValueChange={() => toggle(key)}
                      trackColor={{ false: colors.border, true: color + "60" }}
                      thumbColor={permissions[key] ? color : colors.mutedForeground} />
                  </View>
                ))}
              </View>
            ))}
          </ScrollView>
          <View style={{ padding: 20, borderTopWidth: 1, borderTopColor: colors.border }}>
            <TouchableOpacity onPress={submit} style={{ backgroundColor: color, borderRadius: 14, paddingVertical: 15, alignItems: "center" }} activeOpacity={0.85}>
              <Text style={{ color: "#fff", fontSize: 16, fontFamily: "Inter_700Bold" }}>💾 حفظ التعديلات</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

type AdminTab = "users" | "roles" | "visibility" | "security" | "notifications" | "settings" | "stats";

export default function AdminScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, allUsers, updateUserRole, toggleUserActive, deleteUser, updateUserPermissions } = useAuth();
  const { events, activities, announcements, addAnnouncement, deleteAnnouncement, deleteEvent, deleteActivity, customRoles, addCustomRole, deleteCustomRole, updateCustomRole, getPermissions, appSettings, updateAppSetting } = useApp();
  const [activeTab, setActiveTab] = useState<AdminTab>("users");
  const [roleModalFor, setRoleModalFor] = useState<string | null>(null);
  const [permModalFor, setPermModalFor] = useState<string | null>(null);
  const [showCreateRole, setShowCreateRole] = useState(false);
  const [showCredentials, setShowCredentials] = useState(false);
  const [editingSettings, setEditingSettings] = useState({ appName: appSettings.appName, subtitle: appSettings.subtitle, footerName: appSettings.footerName, footerSupervisor: appSettings.footerSupervisor });
  const router = useRouter();
  const [showAddAnn, setShowAddAnn] = useState(false);
  const [annTitle, setAnnTitle] = useState("");
  const [annContent, setAnnContent] = useState("");
  const [editingRoleId, setEditingRoleId] = useState<string | null>(null);
  const [notificationTitle, setNotificationTitle] = useState("");
  const [notificationContent, setNotificationContent] = useState("");
  const [maintenanceDraft, setMaintenanceDraft] = useState(appSettings.maintenanceMessage || "");

  const NAV_ITEMS = [
    { id: "index", label: "الرئيسية", icon: "home" },
    { id: "antivio", label: "ضد العنف", icon: "shield" },
    { id: "events", label: "الفعاليات", icon: "calendar" },
    { id: "activities", label: "الأنشطة", icon: "star" },
    { id: "ai", label: "المساعد الذكي", icon: "cpu" },
    { id: "topics", label: "المواضيع", icon: "book-open" },
    { id: "chat", label: "الدردشة", icon: "message-circle" },
    { id: "account", label: "حسابي", icon: "user" },
    { id: "admin", label: "الإدارة", icon: "shield" },
  ];
  const FEATURE_ITEMS = [
    { id: "editFab", label: "زر القلم الأخضر العائم", desc: "إخفاء زر تعديل النصوص من كل الصفحات" },
    { id: "homeQuickShortcuts", label: "اختصارات الرئيسية", desc: "تجهيز خيار لإخفاء مربعات الاختصارات" },
    { id: "publicCounters", label: "عدادات الإحصاء العامة", desc: "إخفاء أرقام الفعاليات والأنشطة عن الطلاب" },
  ];
  const hiddenTabs = appSettings.hiddenTabs ? appSettings.hiddenTabs.split(",").filter(Boolean) : [];
  const hiddenFeatures = appSettings.hiddenFeatures ? appSettings.hiddenFeatures.split(",").filter(Boolean) : [];
  const toggleCsvSetting = (key: "hiddenTabs" | "hiddenFeatures", id: string) => {
    const current = appSettings[key] ? appSettings[key].split(",").filter(Boolean) : [];
    const next = current.includes(id) ? current.filter(x => x !== id) : [...current, id];
    updateAppSetting(key, next.join(","));
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const topPad = insets.top;
  const bottomPad = Platform.OS === "web" ? 84 + 16 : 90 + insets.bottom;
  const permissions = getPermissions(user?.role ?? "guest");

  if (!permissions.canViewAdminPanel) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, alignItems: "center", justifyContent: "center" }]}>
        <Feather name="lock" size={48} color={colors.mutedForeground} />
        <Text style={{ color: colors.mutedForeground, fontSize: 16, fontFamily: "Inter_500Medium", marginTop: 16 }}>ليس لديك صلاحية الوصول</Text>
      </View>
    );
  }

  const roleModalUser = allUsers.find(u => u.id === roleModalFor);
  const permModalUser = allUsers.find(u => u.id === permModalFor);

  const handleDeleteUser = (userId: string, name: string) => {
    if (userId === "admin-001") {
      if (Platform.OS === "web") { window.alert("لا يمكن حذف حساب المدير الرئيسي"); } else { Alert.alert("تنبيه", "لا يمكن حذف حساب المدير الرئيسي"); }
      return;
    }
    if (Platform.OS === "web") {
      if (window.confirm(`هل تريد حذف "${name}" نهائياً؟`)) { deleteUser(userId); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning); }
      return;
    }
    Alert.alert("حذف المستخدم", `هل تريد حذف "${name}" نهائياً؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => { deleteUser(userId); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning); } },
    ]);
  };

  const saveSettings = () => {
    updateAppSetting("appName", editingSettings.appName);
    updateAppSetting("subtitle", editingSettings.subtitle);
    updateAppSetting("footerName", editingSettings.footerName);
    updateAppSetting("footerSupervisor", editingSettings.footerSupervisor);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert("✅ تم", "تم حفظ الإعدادات بنجاح — ستظهر التغييرات فوراً");
  };

  const TABS: { id: AdminTab; label: string; icon: string }[] = [
    { id: "users", label: "الأعضاء", icon: "users" },
    { id: "roles", label: "الصلاحيات", icon: "shield" },
    { id: "visibility", label: "إخفاء", icon: "eye-off" },
    { id: "security", label: "الأمان", icon: "lock" },
    { id: "notifications", label: "تنبيهات", icon: "send" },
    { id: "settings", label: "التحكم", icon: "settings" },
    { id: "stats", label: "الإحصاءات", icon: "bar-chart-2" },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient colors={["#E74C3C20", "#E74C3C08", colors.background]} style={[styles.header, { paddingTop: topPad + 16, borderBottomColor: colors.border }]}>
        <View style={styles.headerTop}>
          <LinearGradient colors={["#E74C3C", "#C0392B"]} style={styles.adminIcon}>
            <MaterialCommunityIcons name="shield-crown" size={24} color="#fff" />
          </LinearGradient>
          <View>
            <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>لوحة الإدارة المتقدمة</Text>
            <Text style={[styles.headerSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>مرحباً {user?.fullName} 👑</Text>
          </View>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={{ flexDirection: "row", gap: 8 }}>
            {TABS.map((tab) => (
              <TouchableOpacity key={tab.id} onPress={() => setActiveTab(tab.id)}
                style={[styles.tab, { backgroundColor: activeTab === tab.id ? "#E74C3C" : colors.card, borderColor: activeTab === tab.id ? "#E74C3C" : colors.border }]}>
                <Feather name={tab.icon as any} size={13} color={activeTab === tab.id ? "#fff" : colors.mutedForeground} />
                <Text style={[styles.tabText, { color: activeTab === tab.id ? "#fff" : colors.mutedForeground, fontFamily: "Inter_600SemiBold" }]}>{tab.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </LinearGradient>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: bottomPad }} showsVerticalScrollIndicator={false}>

        {/* ========== TAB: USERS ========== */}
        {activeTab === "users" && (
          <>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 0 }]}>الأعضاء ({allUsers.length})</Text>
              <View style={{ backgroundColor: "#27AE6015", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, flexDirection: "row", alignItems: "center", gap: 4 }}>
                <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: "#27AE60" }} />
                <Text style={{ fontSize: 11, color: "#27AE60", fontFamily: "Inter_600SemiBold" }}>{allUsers.filter(u => u.isActive).length} نشط</Text>
              </View>
            </View>
            {allUsers.map((u) => {
              const rc = ROLE_COLORS[u.role] || "#9B59B6";
              const isAdmin = u.id === "admin-001";
              const hasCustomPerms = u.customPermissions && Object.keys(u.customPermissions).length > 0;
              return (
                <View key={u.id} style={[styles.userCard, { backgroundColor: colors.card, borderColor: isAdmin ? "#E74C3C40" : colors.border }]}>
                  <View style={[styles.userAvatar, { backgroundColor: rc + "25" }]}>
                    <Text style={{ fontSize: 20, color: rc, fontFamily: "Inter_700Bold" }}>{u.fullName.charAt(0)}</Text>
                  </View>
                  <View style={styles.userInfo}>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 2, flexWrap: "wrap" }}>
                      <Text style={{ fontSize: 14, color: colors.text, fontFamily: "Inter_700Bold" }}>{u.fullName}</Text>
                      {isAdmin && <View style={{ backgroundColor: "#E74C3C20", paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 }}><Text style={{ fontSize: 9, color: "#E74C3C", fontFamily: "Inter_700Bold" }}>مدير</Text></View>}
                      {!u.isActive && <View style={{ backgroundColor: "#E74C3C15", paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 }}><Text style={{ fontSize: 9, color: "#E74C3C" }}>موقوف</Text></View>}
                      {hasCustomPerms && <View style={{ backgroundColor: "#9B59B615", paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 }}><Text style={{ fontSize: 9, color: "#9B59B6" }}>✏️ صلاحيات مخصصة</Text></View>}
                    </View>
                    <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginBottom: 4 }}>@{u.username}</Text>
                    <View style={{ backgroundColor: rc + "20", alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 }}>
                      <Text style={{ fontSize: 10, color: rc, fontFamily: "Inter_600SemiBold" }}>{ROLE_LABELS[u.role] || customRoles.find(r => r.id === u.role)?.name || u.role}</Text>
                    </View>
                  </View>
                  {!isAdmin && (
                    <View style={styles.userActions}>
                      <TouchableOpacity style={[styles.actionBtn, { backgroundColor: "#E74C3C20" }]} onPress={() => setRoleModalFor(u.id)}>
                        <Feather name="shield" size={13} color="#E74C3C" />
                      </TouchableOpacity>
                      <TouchableOpacity style={[styles.actionBtn, { backgroundColor: "#9B59B620" }]} onPress={() => setPermModalFor(u.id)}>
                        <Feather name="sliders" size={13} color="#9B59B6" />
                      </TouchableOpacity>
                      <TouchableOpacity style={[styles.actionBtn, { backgroundColor: (u.isActive ? "#E67E22" : "#27AE60") + "20" }]} onPress={() => { toggleUserActive(u.id); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); }}>
                        <Feather name={u.isActive ? "user-x" : "user-check"} size={13} color={u.isActive ? "#E67E22" : "#27AE60"} />
                      </TouchableOpacity>
                      <TouchableOpacity style={[styles.actionBtn, { backgroundColor: "#E74C3C20" }]} onPress={() => handleDeleteUser(u.id, u.fullName)}>
                        <Feather name="trash-2" size={13} color="#E74C3C" />
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
              );
            })}
          </>
        )}

        {/* ========== TAB: CUSTOM ROLES ========== */}
        {activeTab === "roles" && (
          <>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 0 }]}>الرتب والصلاحيات</Text>
              <TouchableOpacity onPress={() => setShowCreateRole(true)} style={{ flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#E74C3C", paddingHorizontal: 12, paddingVertical: 8, borderRadius: 14 }}>
                <Feather name="plus" size={15} color="#fff" />
                <Text style={{ color: "#fff", fontSize: 12, fontFamily: "Inter_700Bold" }}>رتبة جديدة</Text>
              </TouchableOpacity>
            </View>

            <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginBottom: 16 }}>
              الرتب الأساسية: طالب، معلم، مشرف، مدير. يمكنك إضافة رتب مخصصة بصلاحيات محددة وتعيينها للأعضاء.
            </Text>

            {STANDARD_ROLES.map((role) => {
              const rc = ROLE_COLORS[role] || "#1B8A5A";
              return (
                <View key={role} style={[styles.roleCard, { backgroundColor: colors.card, borderColor: rc + "40" }]}>
                  <LinearGradient colors={[rc + "20", rc + "05"]} style={{ flexDirection: "row", alignItems: "center", gap: 10, padding: 14, borderRadius: 14 }}>
                    <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: rc + "30", alignItems: "center", justifyContent: "center" }}>
                      <Feather name="shield" size={18} color={rc} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold" }}>{ROLE_LABELS[role]}</Text>
                      <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginTop: 2 }}>
                        {allUsers.filter(u => u.role === role).length} عضو · رتبة أساسية
                      </Text>
                    </View>
                    <View style={{ backgroundColor: rc + "20", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 }}>
                      <Text style={{ fontSize: 10, color: rc, fontFamily: "Inter_600SemiBold" }}>مدمجة</Text>
                    </View>
                  </LinearGradient>
                </View>
              );
            })}

            {customRoles.length > 0 && (
              <>
                <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold", marginTop: 20 }]}>الرتب المخصصة</Text>
                {customRoles.map((cr) => (
                  <View key={cr.id} style={[styles.roleCard, { backgroundColor: colors.card, borderColor: cr.color + "40" }]}>
                    <LinearGradient colors={[cr.color + "20", cr.color + "05"]} style={{ flexDirection: "row", alignItems: "center", gap: 10, padding: 14, borderRadius: 14 }}>
                      <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: cr.color + "30", alignItems: "center", justifyContent: "center" }}>
                        <MaterialCommunityIcons name="star-circle" size={18} color={cr.color} />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold" }}>{cr.name}</Text>
                        {cr.description ? <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginTop: 2 }}>{cr.description}</Text> : null}
                      </View>
                      <TouchableOpacity onPress={() => setEditingRoleId(cr.id)}
                        style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: "#3498DB20", alignItems: "center", justifyContent: "center", marginRight: 6 }}>
                        <Feather name="edit-2" size={14} color="#3498DB" />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => {
                        if (Platform.OS === "web") { if (window.confirm(`هل تريد حذف رتبة "${cr.name}"؟`)) deleteCustomRole(cr.id); }
                        else Alert.alert("حذف رتبة", `هل تريد حذف رتبة "${cr.name}"؟`, [{ text: "إلغاء", style: "cancel" }, { text: "حذف", style: "destructive", onPress: () => deleteCustomRole(cr.id) }]);
                      }} style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: "#E74C3C20", alignItems: "center", justifyContent: "center" }}>
                        <Feather name="trash-2" size={14} color="#E74C3C" />
                      </TouchableOpacity>
                    </LinearGradient>
                  </View>
                ))}
              </>
            )}

            {customRoles.length === 0 && (
              <View style={{ alignItems: "center", paddingVertical: 30, gap: 10 }}>
                <Feather name="plus-circle" size={48} color={colors.mutedForeground + "80"} />
                <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_500Medium", fontSize: 14, textAlign: "center" }}>لا توجد رتب مخصصة بعد. اضغط "رتبة جديدة" لإنشاء رتبة بصلاحيات محددة.</Text>
              </View>
            )}
          </>
        )}

        {/* ========== TAB: VISIBILITY ========== */}
        {activeTab === "visibility" && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>إخفاء وإظهار أقسام التطبيق</Text>
            <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border, marginBottom: 14 }]}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 12 }}>
                <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: "#E74C3C20", alignItems: "center", justifyContent: "center" }}>
                  <Feather name="eye-off" size={18} color="#E74C3C" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold" }}>إخفاء أزرار الشريط السفلي</Text>
                  <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginTop: 2 }}>أي قسم تخفيه يختفي فوراً من الـ bar السفلي للمستخدمين</Text>
                </View>
              </View>
              {NAV_ITEMS.map(item => {
                const hidden = hiddenTabs.includes(item.id);
                return (
                  <View key={item.id} style={{ flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 10, borderTopWidth: 1, borderTopColor: colors.border }}>
                    <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: hidden ? "#E74C3C20" : "#27AE6020", alignItems: "center", justifyContent: "center" }}>
                      <Feather name={item.icon as any} size={16} color={hidden ? "#E74C3C" : "#27AE60"} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={{ color: colors.text, fontSize: 13, fontFamily: "Inter_700Bold" }}>{item.label}</Text>
                      <Text style={{ color: hidden ? "#E74C3C" : "#27AE60", fontSize: 10, fontFamily: "Inter_500Medium", marginTop: 1 }}>{hidden ? "مخفي الآن" : "ظاهر الآن"}</Text>
                    </View>
                    <Switch value={!hidden} onValueChange={() => toggleCsvSetting("hiddenTabs", item.id)} trackColor={{ false: "#E74C3C50", true: "#27AE6060" }} thumbColor={!hidden ? "#27AE60" : "#E74C3C"} />
                  </View>
                );
              })}
            </View>

            <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 12 }}>أزرار وميزات إضافية</Text>
              {FEATURE_ITEMS.map(item => {
                const hidden = hiddenFeatures.includes(item.id);
                return (
                  <TouchableOpacity key={item.id} onPress={() => toggleCsvSetting("hiddenFeatures", item.id)} activeOpacity={0.8}
                    style={{ flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: hidden ? "#E74C3C10" : "#27AE6010", borderRadius: 14, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: hidden ? "#E74C3C30" : "#27AE6030" }}>
                    <Feather name={hidden ? "eye-off" : "eye"} size={18} color={hidden ? "#E74C3C" : "#27AE60"} />
                    <View style={{ flex: 1 }}>
                      <Text style={{ color: colors.text, fontSize: 13, fontFamily: "Inter_700Bold" }}>{item.label}</Text>
                      <Text style={{ color: colors.mutedForeground, fontSize: 11, fontFamily: "Inter_400Regular", marginTop: 2 }}>{item.desc}</Text>
                    </View>
                    <Text style={{ color: hidden ? "#E74C3C" : "#27AE60", fontSize: 11, fontFamily: "Inter_700Bold" }}>{hidden ? "مخفي" : "ظاهر"}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </>
        )}

        {/* ========== TAB: SECURITY ========== */}
        {activeTab === "security" && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>الأمان والتحكم المتقدم</Text>
            <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 12 }}>🛡️ مركز حماية التطبيق</Text>
              {[
                { title: "الطلبات الحساسة", desc: "أي محادثة شخصية أو انضمام لمجموعة يحتاج قبول/رفض قبل البداية.", color: "#3498DB", icon: "check-circle" },
                { title: "صلاحيات فردية", desc: "كل عضو يمكن إعطاؤه صلاحيات خاصة تختلف عن رتبته الأساسية.", color: "#9B59B6", icon: "sliders" },
                { title: "إيقاف المستخدم", desc: "إيقاف الحساب يمنع الدخول بدون حذف بياناته.", color: "#E67E22", icon: "user-x" },
                { title: "إدارة الظهور", desc: "قسم الإخفاء يتحكم بما يظهر للمستخدمين في الشريط السفلي والواجهات.", color: "#E74C3C", icon: "eye-off" },
              ].map(item => (
                <View key={item.title} style={{ flexDirection: "row", gap: 12, backgroundColor: item.color + "10", borderRadius: 14, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: item.color + "30" }}>
                  <Feather name={item.icon as any} size={18} color={item.color} />
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: colors.text, fontSize: 13, fontFamily: "Inter_700Bold" }}>{item.title}</Text>
                    <Text style={{ color: colors.mutedForeground, fontSize: 11, fontFamily: "Inter_400Regular", lineHeight: 18, marginTop: 2 }}>{item.desc}</Text>
                  </View>
                </View>
              ))}
            </View>

            <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border, marginTop: 14 }]}>
              <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 10 }}>رسالة صيانة اختيارية</Text>
              <TextInput value={maintenanceDraft} onChangeText={setMaintenanceDraft} placeholder="مثال: التطبيق تحت الصيانة من 8:00 حتى 9:00" placeholderTextColor={colors.mutedForeground}
                multiline style={{ backgroundColor: colors.background, color: colors.text, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: 12, minHeight: 72, textAlignVertical: "top", fontFamily: "Inter_400Regular" }} />
              <TouchableOpacity onPress={() => { updateAppSetting("maintenanceMessage", maintenanceDraft); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); Alert.alert("تم", "تم حفظ رسالة الصيانة"); }}
                style={{ backgroundColor: "#E74C3C", borderRadius: 14, paddingVertical: 13, alignItems: "center", marginTop: 10 }}>
                <Text style={{ color: "#fff", fontSize: 14, fontFamily: "Inter_700Bold" }}>حفظ رسالة الصيانة</Text>
              </TouchableOpacity>
            </View>
          </>
        )}

        {/* ========== TAB: NOTIFICATIONS ========== */}
        {activeTab === "notifications" && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>التنبيهات والإعلانات السريعة</Text>
            <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 12 }}>
                <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: "#1ABC9C20", alignItems: "center", justifyContent: "center" }}>
                  <Feather name="send" size={18} color="#1ABC9C" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold" }}>إرسال إعلان يظهر في الرئيسية</Text>
                  <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>مناسب للتنبيهات، المواعيد، والتعليمات المهمة.</Text>
                </View>
              </View>
              <TextInput value={notificationTitle} onChangeText={setNotificationTitle} placeholder="عنوان التنبيه..." placeholderTextColor={colors.mutedForeground}
                style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 10 }} />
              <TextInput value={notificationContent} onChangeText={setNotificationContent} placeholder="نص التنبيه..." placeholderTextColor={colors.mutedForeground}
                multiline numberOfLines={4} style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", minHeight: 90, textAlignVertical: "top" }} />
              <TouchableOpacity onPress={() => {
                if (!notificationTitle.trim() || !notificationContent.trim()) { Alert.alert("تنبيه", "اكتب عنوان ونص التنبيه"); return; }
                addAnnouncement({ title: notificationTitle.trim(), content: notificationContent.trim(), priority: "high" });
                setNotificationTitle(""); setNotificationContent("");
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                Alert.alert("✅ تم", "تم نشر التنبيه بنجاح");
              }} style={{ backgroundColor: "#1ABC9C", borderRadius: 14, paddingVertical: 14, alignItems: "center", marginTop: 12 }} activeOpacity={0.85}>
                <Text style={{ color: "#fff", fontSize: 15, fontFamily: "Inter_700Bold" }}>نشر التنبيه الآن</Text>
              </TouchableOpacity>
            </View>
          </>
        )}

        {/* ========== TAB: SETTINGS ========== */}
        {activeTab === "settings" && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>إعدادات التطبيق</Text>

            <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 12 }}>
                <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: "#27AE6020", alignItems: "center", justifyContent: "center" }}>
                  <Feather name="edit-2" size={18} color="#27AE60" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold" }}>تعديل محتوى التطبيق</Text>
                  <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginTop: 2 }}>استخدم زر القلم الأخضر ✏️ في أسفل الشاشة</Text>
                </View>
              </View>
              <View style={{ backgroundColor: "#27AE6010", borderRadius: 12, padding: 14, flexDirection: "row", alignItems: "center", gap: 12 }}>
                <Text style={{ fontSize: 28 }}>✏️</Text>
                <Text style={{ flex: 1, fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular", lineHeight: 20 }}>
                  الزر الأخضر في الزاوية السفلية يتيح تعديل عناوين ونصوص كل صفحة — من الرئيسية حتى الذكاء الاصطناعي.
                </Text>
              </View>
            </View>

            <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border, marginTop: 14 }]}>
              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: showAddAnn ? 14 : 0 }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: "#1ABC9C20", alignItems: "center", justifyContent: "center" }}>
                    <Feather name="bell" size={16} color="#1ABC9C" />
                  </View>
                  <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold" }}>إضافة إعلان</Text>
                </View>
                <TouchableOpacity onPress={() => setShowAddAnn(!showAddAnn)} style={{ backgroundColor: showAddAnn ? "#E74C3C20" : "#1ABC9C20", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 }}>
                  <Text style={{ fontSize: 12, color: showAddAnn ? "#E74C3C" : "#1ABC9C", fontFamily: "Inter_600SemiBold" }}>{showAddAnn ? "إلغاء" : "إضافة +"}</Text>
                </TouchableOpacity>
              </View>
              {showAddAnn && (
                <View style={{ gap: 10 }}>
                  <TextInput value={annTitle} onChangeText={setAnnTitle} placeholder="عنوان الإعلان..." placeholderTextColor={colors.mutedForeground}
                    style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular" }} />
                  <TextInput value={annContent} onChangeText={setAnnContent} placeholder="نص الإعلان التفصيلي..." placeholderTextColor={colors.mutedForeground}
                    multiline numberOfLines={3}
                    style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", minHeight: 80, textAlignVertical: "top" }} />
                  <TouchableOpacity onPress={() => {
                    if (!annTitle.trim() || !annContent.trim()) {
                      if (Platform.OS === "web") window.alert("العنوان والنص مطلوبان");
                      else Alert.alert("تنبيه", "العنوان والنص مطلوبان");
                      return;
                    }
                    addAnnouncement({ title: annTitle.trim(), content: annContent.trim(), priority: "medium" });
                    setAnnTitle(""); setAnnContent(""); setShowAddAnn(false);
                    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                  }} style={{ backgroundColor: "#1ABC9C", borderRadius: 14, paddingVertical: 14, alignItems: "center" }} activeOpacity={0.85}>
                    <Text style={{ color: "#fff", fontSize: 15, fontFamily: "Inter_700Bold" }}>نشر الإعلان</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>

            <View style={[styles.settingsCard, { backgroundColor: colors.card, borderColor: colors.border, marginTop: 14 }]}>
              <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 14 }}>⚡ إجراءات سريعة</Text>
              {[
                { label: `📥 تصدير البيانات والتقارير`, color: "#16A085", onPress: () => router.push("/export" as any) },
                { label: `🗑 مسح جميع الإعلانات (${announcements.length})`, color: "#E67E22", onPress: () => {
                  const msg = `هل تريد حذف ${announcements.length} إعلان؟`;
                  if (Platform.OS === "web") { if (window.confirm(msg)) { announcements.forEach(a => deleteAnnouncement(a.id)); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning); } }
                  else Alert.alert("مسح الإعلانات", msg, [{ text: "إلغاء", style: "cancel" }, { text: "مسح الكل", style: "destructive", onPress: () => { announcements.forEach(a => deleteAnnouncement(a.id)); } }]);
                }},
                { label: `🗑 مسح جميع الفعاليات (${events.length})`, color: "#E74C3C", onPress: () => {
                  const msg = `هل تريد حذف ${events.length} فعالية؟`;
                  if (Platform.OS === "web") { if (window.confirm(msg)) { events.forEach(e => deleteEvent(e.id)); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning); } }
                  else Alert.alert("مسح الفعاليات", msg, [{ text: "إلغاء", style: "cancel" }, { text: "مسح الكل", style: "destructive", onPress: () => { events.forEach(e => deleteEvent(e.id)); } }]);
                }},
                { label: `🗑 مسح جميع الأنشطة (${activities.length})`, color: "#9B59B6", onPress: () => {
                  const msg = `هل تريد حذف ${activities.length} نشاط؟`;
                  if (Platform.OS === "web") { if (window.confirm(msg)) { activities.forEach(a => deleteActivity(a.id)); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning); } }
                  else Alert.alert("مسح الأنشطة", msg, [{ text: "إلغاء", style: "cancel" }, { text: "مسح الكل", style: "destructive", onPress: () => { activities.forEach(a => deleteActivity(a.id)); } }]);
                }},
              ].map(({ label, color, onPress }) => (
                <TouchableOpacity key={label} onPress={onPress} activeOpacity={0.8}
                  style={{ flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: color + "12", borderRadius: 14, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: color + "30" }}>
                  <Text style={{ flex: 1, fontSize: 13, color: colors.text, fontFamily: "Inter_600SemiBold" }}>{label}</Text>
                  <Feather name="chevron-left" size={16} color={colors.mutedForeground} />
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}

        {/* ========== TAB: STATS ========== */}
        {activeTab === "stats" && (
          <>
            <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>إحصاءات التطبيق</Text>
            {[
              { label: "إجمالي المستخدمين", value: allUsers.length, icon: "users", color: "#3498DB" },
              { label: "المستخدمون النشطون", value: allUsers.filter(u => u.isActive).length, icon: "user-check", color: "#27AE60" },
              { label: "الموقوفون", value: allUsers.filter(u => !u.isActive).length, icon: "user-x", color: "#E74C3C" },
              { label: "الفعاليات", value: events.length, icon: "calendar", color: "#9B59B6" },
              { label: "الأنشطة", value: activities.length, icon: "star", color: "#E67E22" },
              { label: "الإعلانات", value: announcements.length, icon: "bell", color: "#1ABC9C" },
              { label: "الرتب المخصصة", value: customRoles.length, icon: "shield", color: "#E74C3C" },
            ].map(({ label, value, icon, color }) => (
              <View key={label} style={[styles.statRow, { backgroundColor: colors.card, borderColor: color + "30" }]}>
                <View style={[styles.statIcon, { backgroundColor: color + "20" }]}><Feather name={icon as any} size={20} color={color} /></View>
                <Text style={{ flex: 1, fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>{label}</Text>
                <Text style={{ fontSize: 26, color, fontFamily: "Inter_700Bold" }}>{value}</Text>
              </View>
            ))}

            <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold", marginTop: 20 }]}>توزيع الأدوار</Text>
            {[...STANDARD_ROLES, ...customRoles.map(r => r.id)].map((role) => {
              const count = allUsers.filter(u => u.role === role).length;
              const rc = ROLE_COLORS[role] || customRoles.find(r => r.id === role)?.color || "#9B59B6";
              const pct = allUsers.length > 0 ? (count / allUsers.length) * 100 : 0;
              return (
                <View key={role} style={[styles.distRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  <Text style={{ width: 70, fontSize: 12, color: colors.text, fontFamily: "Inter_600SemiBold" }} numberOfLines={1}>{ROLE_LABELS[role] || customRoles.find(r => r.id === role)?.name || role}</Text>
                  <View style={{ flex: 1, height: 8, borderRadius: 4, backgroundColor: colors.secondary, overflow: "hidden" }}>
                    <View style={{ height: 8, borderRadius: 4, backgroundColor: rc, width: `${Math.max(pct, count > 0 ? 5 : 0)}%` as any }} />
                  </View>
                  <Text style={{ width: 28, fontSize: 15, color: rc, fontFamily: "Inter_700Bold", textAlign: "right" }}>{count}</Text>
                </View>
              );
            })}

            {announcements.length > 0 && (
              <>
                <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold", marginTop: 20 }]}>الإعلانات ({announcements.length})</Text>
                {announcements.map(ann => (
                  <View key={ann.id} style={{ backgroundColor: colors.card, borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: colors.border, flexDirection: "row", alignItems: "center", gap: 12 }}>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_700Bold" }}>{ann.title}</Text>
                      <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginTop: 2 }} numberOfLines={1}>{ann.content}</Text>
                    </View>
                    <TouchableOpacity onPress={() => { deleteAnnouncement(ann.id); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning); }}
                      style={{ width: 34, height: 34, borderRadius: 10, backgroundColor: "#E74C3C20", alignItems: "center", justifyContent: "center" }}>
                      <Feather name="trash-2" size={14} color="#E74C3C" />
                    </TouchableOpacity>
                  </View>
                ))}
              </>
            )}
          </>
        )}
      </ScrollView>

      {roleModalFor && roleModalUser && (
        <RoleModal currentRole={roleModalUser.role} customRoles={customRoles}
          onClose={() => setRoleModalFor(null)}
          onSave={(role) => { updateUserRole(roleModalFor, role); setRoleModalFor(null); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); }} />
      )}

      {permModalFor && permModalUser && (
        <UserPermissionsModal
          user={permModalUser}
          baseRole={permModalUser.role}
          currentPerms={permModalUser.customPermissions || {}}
          onClose={() => setPermModalFor(null)}
          onSave={(perms) => { updateUserPermissions(permModalFor, perms); setPermModalFor(null); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); Alert.alert("✅ تم", "تم حفظ الصلاحيات المخصصة"); }} />
      )}

      {showCreateRole && (
        <CreateRoleModal onClose={() => setShowCreateRole(false)}
          onSave={(role) => { addCustomRole(role); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); Alert.alert("✅ تم", `تم إنشاء رتبة "${role.name}" بنجاح`); }} />
      )}

      {editingRoleId && (() => {
        const cr = customRoles.find(r => r.id === editingRoleId);
        if (!cr) return null;
        return (
          <EditRoleModal role={cr} onClose={() => setEditingRoleId(null)}
            onSave={(updates) => { updateCustomRole(editingRoleId, updates); setEditingRoleId(null); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); }} />
        );
      })()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 14, borderBottomWidth: 1 },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 14 },
  adminIcon: { width: 52, height: 52, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 18 },
  headerSub: { fontSize: 12, marginTop: 2 },
  tab: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20, borderWidth: 1 },
  tabText: { fontSize: 12 },
  sectionTitle: { fontSize: 17, marginBottom: 14 },
  userCard: { flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 16, padding: 12, marginBottom: 10, borderWidth: 1 },
  userAvatar: { width: 46, height: 46, borderRadius: 12, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  userInfo: { flex: 1 },
  userActions: { flexDirection: "column", gap: 5 },
  actionBtn: { width: 32, height: 32, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  roleCard: { borderRadius: 16, marginBottom: 10, overflow: "hidden", borderWidth: 1 },
  settingsCard: { borderRadius: 18, padding: 16, borderWidth: 1 },
  statRow: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 16, padding: 14, marginBottom: 10, borderWidth: 1 },
  statIcon: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  distRow: { flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 12, padding: 12, marginBottom: 8, borderWidth: 1 },
});

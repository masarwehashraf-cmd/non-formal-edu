import { BlurView } from "expo-blur";
import { isLiquidGlassAvailable } from "expo-glass-effect";
import { Tabs } from "expo-router";
import { Icon, Label, NativeTabs } from "expo-router/unstable-native-tabs";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import React from "react";
import { Platform, StyleSheet, View, useColorScheme } from "react-native";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/context/AuthContext";
import { ROLE_PERMISSIONS, useApp, normalizePermissions } from "@/context/AppContext";
import AdminEditFAB from "@/components/AdminEditFAB";

function NativeTabLayout({ showAdmin, hiddenTabs }: { showAdmin: boolean; hiddenTabs: string[] }) {
  return (
    <NativeTabs>
      {!hiddenTabs.includes("index") && (<NativeTabs.Trigger name="index">
        <Icon sf={{ default: "house", selected: "house.fill" }} />
        <Label>الرئيسية</Label>
      </NativeTabs.Trigger>)}
      {!hiddenTabs.includes("antivio") && (<NativeTabs.Trigger name="antivio">
        <Icon sf={{ default: "hand.raised", selected: "hand.raised.fill" }} />
        <Label>ضد العنف</Label>
      </NativeTabs.Trigger>)}
      {!hiddenTabs.includes("events") && (<NativeTabs.Trigger name="events">
        <Icon sf={{ default: "calendar", selected: "calendar.badge.checkmark" }} />
        <Label>الفعاليات</Label>
      </NativeTabs.Trigger>)}
      {!hiddenTabs.includes("activities") && (<NativeTabs.Trigger name="activities">
        <Icon sf={{ default: "star", selected: "star.fill" }} />
        <Label>الأنشطة</Label>
      </NativeTabs.Trigger>)}
      {!hiddenTabs.includes("ai") && (<NativeTabs.Trigger name="ai">
        <Icon sf={{ default: "cpu", selected: "cpu.fill" }} />
        <Label>مساعد ذكي</Label>
      </NativeTabs.Trigger>)}
      {!hiddenTabs.includes("topics") && (<NativeTabs.Trigger name="topics">
        <Icon sf={{ default: "book", selected: "book.fill" }} />
        <Label>المواضيع</Label>
      </NativeTabs.Trigger>)}
      {!hiddenTabs.includes("chat") && (<NativeTabs.Trigger name="chat">
        <Icon sf={{ default: "bubble.left.and.bubble.right", selected: "bubble.left.and.bubble.right.fill" }} />
        <Label>الدردشة</Label>
      </NativeTabs.Trigger>)}
      {!hiddenTabs.includes("account") && (<NativeTabs.Trigger name="account">
        <Icon sf={{ default: "person", selected: "person.fill" }} />
        <Label>حسابي</Label>
      </NativeTabs.Trigger>)}
      {showAdmin && !hiddenTabs.includes("admin") && (
        <NativeTabs.Trigger name="admin">
          <Icon sf={{ default: "shield", selected: "shield.fill" }} />
          <Label>الإدارة</Label>
        </NativeTabs.Trigger>
      )}
    </NativeTabs>
  );
}

function ClassicTabLayout({ showAdmin, hiddenTabs }: { showAdmin: boolean; hiddenTabs: string[] }) {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";
  const isIOS = Platform.OS === "ios";
  const isWeb = Platform.OS === "web";

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.mutedForeground,
        headerShown: false,
        tabBarStyle: {
          position: "absolute",
          backgroundColor: isIOS ? "transparent" : colors.card,
          borderTopWidth: 1,
          borderTopColor: colors.border,
          elevation: 0,
          height: isWeb ? 84 : undefined,
        },
        tabBarLabelStyle: { fontFamily: "Inter_500Medium", fontSize: 9 },
        tabBarBackground: () =>
          isIOS ? (
            <BlurView intensity={100} tint={isDark ? "dark" : "light"} style={StyleSheet.absoluteFill} />
          ) : isWeb ? (
            <View style={[StyleSheet.absoluteFill, { backgroundColor: colors.card }]} />
          ) : null,
      }}
    >
      <Tabs.Screen name="index" options={hiddenTabs.includes("index") ? { href: null } : { title: "الرئيسية", tabBarIcon: ({ color }) => <Feather name="home" size={20} color={color} /> }} />
      <Tabs.Screen name="antivio" options={hiddenTabs.includes("antivio") ? { href: null } : { title: "ضد العنف", tabBarIcon: ({ color }) => <MaterialCommunityIcons name="hand-peace" size={20} color={color} /> }} />
      <Tabs.Screen name="events" options={hiddenTabs.includes("events") ? { href: null } : { title: "الفعاليات", tabBarIcon: ({ color }) => <Feather name="calendar" size={20} color={color} /> }} />
      <Tabs.Screen name="activities" options={hiddenTabs.includes("activities") ? { href: null } : { title: "الأنشطة", tabBarIcon: ({ color }) => <MaterialCommunityIcons name="star-circle" size={20} color={color} /> }} />
      <Tabs.Screen name="ai" options={hiddenTabs.includes("ai") ? { href: null } : { title: "مساعد ذكي", tabBarIcon: ({ color }) => <MaterialCommunityIcons name="robot" size={20} color={color} /> }} />
      <Tabs.Screen name="topics" options={hiddenTabs.includes("topics") ? { href: null } : { title: "المواضيع", tabBarIcon: ({ color }) => <MaterialCommunityIcons name="book-open-page-variant" size={20} color={color} /> }} />
      <Tabs.Screen name="chat" options={hiddenTabs.includes("chat") ? { href: null } : { title: "الدردشة", tabBarIcon: ({ color }) => <Feather name="message-circle" size={20} color={color} /> }} />
      <Tabs.Screen name="account" options={hiddenTabs.includes("account") ? { href: null } : { title: "حسابي", tabBarIcon: ({ color }) => <Feather name="user" size={20} color={color} /> }} />
      <Tabs.Screen
        name="admin"
        options={showAdmin
          ? { title: "الإدارة", tabBarIcon: ({ color }) => <MaterialCommunityIcons name="shield-crown" size={20} color={color} /> }
          : { href: null }
        }
      />
    </Tabs>
  );
}

export default function TabLayout() {
  const { user } = useAuth();
  const role = user?.role ?? "guest";
  const { appSettings } = useApp();
  const hiddenTabs = appSettings.hiddenTabs ? appSettings.hiddenTabs.split(",").filter(Boolean) : [];
  const hiddenFeatures = appSettings.hiddenFeatures ? appSettings.hiddenFeatures.split(",").filter(Boolean) : [];
  const showAdmin = Boolean(normalizePermissions(ROLE_PERMISSIONS[role]).canViewAdminPanel) && !hiddenTabs.includes("admin");

  return (
    <View style={{ flex: 1 }}>
      {isLiquidGlassAvailable()
        ? <NativeTabLayout showAdmin={showAdmin} hiddenTabs={hiddenTabs} />
        : <ClassicTabLayout showAdmin={showAdmin} hiddenTabs={hiddenTabs} />}
      {!hiddenFeatures.includes("editFab") && <AdminEditFAB />}
    </View>
  );
}

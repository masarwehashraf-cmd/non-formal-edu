import React, { useState } from "react";
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet, Platform, TextInput,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import EventCard from "@/components/EventCard";
import AddEventModal from "@/components/AddEventModal";

const FILTERS = ["الكل", "ورشة عمل", "فعالية بيئية", "مسابقة", "رحلة", "تطوعي", "ندوة", "مبادرة"];

export default function EventsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { events, deleteEvent, getPermissions, appSettings } = useApp();
  const { user } = useAuth();
  const permissions = getPermissions(user?.role ?? "guest");
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("الكل");

  const topPad = insets.top;
  const bottomPad = Platform.OS === "web" ? 84 + 16 : 90 + insets.bottom;

  const filtered = events.filter((e) => {
    const matchSearch = e.title.includes(search) || e.description.includes(search) || e.location.includes(search);
    const matchFilter = filter === "الكل" || e.category === filter;
    return matchSearch && matchFilter;
  });

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 16, backgroundColor: colors.card, borderBottomColor: colors.border }]}>
        <View style={styles.headerRow}>
          <View>
            <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{appSettings.eventsPageTitle}</Text>
            <Text style={[styles.headerSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
              {events.length} فعالية متاحة · اضغط لرؤية طريقة التقديم
            </Text>
          </View>
          {permissions.canAddEvents && (
            <TouchableOpacity onPress={() => setShowAdd(true)} style={[styles.addBtn, { backgroundColor: colors.primary }]} activeOpacity={0.85}>
              <Feather name="plus" size={20} color="#fff" />
              <Text style={[styles.addBtnText, { fontFamily: "Inter_600SemiBold" }]}>إضافة</Text>
            </TouchableOpacity>
          )}
        </View>
        {/* Search */}
        <View style={[styles.searchRow, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
          <Feather name="search" size={16} color={colors.mutedForeground} />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="ابحث عن فعالية..."
            placeholderTextColor={colors.mutedForeground}
            style={[styles.searchInput, { color: colors.text, fontFamily: "Inter_400Regular" }]}
          />
          {search ? <TouchableOpacity onPress={() => setSearch("")}><Feather name="x" size={16} color={colors.mutedForeground} /></TouchableOpacity> : null}
        </View>
        {/* Filters */}
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={FILTERS}
          keyExtractor={(x) => x}
          contentContainerStyle={styles.filterList}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => setFilter(item)}
              style={[styles.filterChip, { backgroundColor: filter === item ? colors.primary : colors.secondary, borderColor: filter === item ? colors.primary : colors.border }]}
              activeOpacity={0.8}
            >
              <Text style={[styles.filterText, { color: filter === item ? "#fff" : colors.mutedForeground, fontFamily: filter === item ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                {item}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(e) => e.id}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPad }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="calendar" size={44} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
              {search ? "لا توجد نتائج للبحث" : "لا توجد فعاليات حالياً"}
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <EventCard event={item} canDelete={permissions.canDeleteEvents} onDelete={deleteEvent} />
        )}
      />

      {showAdd && <AddEventModal visible={showAdd} onClose={() => setShowAdd(false)} />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12, borderBottomWidth: 1 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 },
  headerTitle: { fontSize: 22 },
  headerSub: { fontSize: 12, marginTop: 3 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12 },
  addBtnText: { color: "#fff", fontSize: 14 },
  searchRow: { flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 14, paddingHorizontal: 14, height: 46, borderWidth: 1, marginBottom: 12 },
  searchInput: { flex: 1, fontSize: 14 },
  filterList: { gap: 8, paddingBottom: 4 },
  filterChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, borderWidth: 1 },
  filterText: { fontSize: 13 },
  empty: { alignItems: "center", paddingVertical: 60, gap: 12 },
  emptyText: { fontSize: 15 },
});

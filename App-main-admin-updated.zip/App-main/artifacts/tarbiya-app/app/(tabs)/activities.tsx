import React, { useState } from "react";
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet, Platform, TextInput,
  Modal, ScrollView, Alert,
} from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import ActivityCard from "@/components/ActivityCard";
import * as Haptics from "expo-haptics";

const TOPICS = [
  "الكل", "التفكير الإبداعي", "القيادة والإدارة", "بناء الفريق",
  "التواصل", "المواطنة", "الصحة النفسية", "البيئة", "الفنون",
];

const ALL_SKILLS = [
  "التفكير النقدي", "التواصل", "العمل الجماعي", "القيادة",
  "الإبداع", "حل المشكلات", "التنظيم", "الثقة بالنفس",
];

function AddActivityModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const colors = useColors();
  const { addActivity } = useApp();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [topic, setTopic] = useState(TOPICS[1]);
  const [targetAge, setTargetAge] = useState("");
  const [duration, setDuration] = useState("");
  const [skills, setSkills] = useState<string[]>([]);

  const reset = () => {
    setTitle(""); setDescription(""); setTopic(TOPICS[1]);
    setTargetAge(""); setDuration(""); setSkills([]);
  };

  const toggleSkill = (s: string) => {
    setSkills((prev) => prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]);
  };

  const submit = () => {
    if (!title.trim() || !description.trim()) {
      Alert.alert("تنبيه", "يرجى ملء العنوان والوصف");
      return;
    }
    addActivity({ title, description, topic, targetAge, duration, skills, materials: "", steps: "", evaluation: "" });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    reset();
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={addStyles.overlay}>
        <View style={[addStyles.sheet, { backgroundColor: colors.card }]}>
          <View style={[addStyles.handle, { backgroundColor: colors.border }]} />
          <View style={addStyles.header}>
            <Text style={[addStyles.title, { color: colors.text, fontFamily: "Inter_700Bold" }]}>إضافة نشاط جديد</Text>
            <TouchableOpacity onPress={onClose}><Feather name="x" size={22} color={colors.mutedForeground} /></TouchableOpacity>
          </View>
          <ScrollView showsVerticalScrollIndicator={false}>
            {[
              { label: "عنوان النشاط *", value: title, set: setTitle, ph: "ادخل عنوان النشاط" },
              { label: "الوصف *", value: description, set: setDescription, ph: "وصف تفصيلي للنشاط", multi: true },
              { label: "الفئة العمرية المستهدفة", value: targetAge, set: setTargetAge, ph: "مثال: 12-16 سنة" },
              { label: "مدة النشاط", value: duration, set: setDuration, ph: "مثال: 45 دقيقة" },
            ].map(({ label, value, set, ph, multi }) => (
              <View key={label} style={{ marginBottom: 14 }}>
                <Text style={[addStyles.label, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{label}</Text>
                <TextInput
                  value={value} onChangeText={set} placeholder={ph}
                  placeholderTextColor={colors.mutedForeground} multiline={multi}
                  style={[addStyles.input, {
                    color: colors.text, borderColor: colors.border, backgroundColor: colors.background,
                    fontFamily: "Inter_400Regular", height: multi ? 80 : 48, textAlignVertical: multi ? "top" : "center",
                  }]}
                />
              </View>
            ))}
            <Text style={[addStyles.label, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>الموضوع</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
              {TOPICS.slice(1).map((t) => (
                <TouchableOpacity
                  key={t}
                  onPress={() => setTopic(t)}
                  style={[addStyles.chip, { backgroundColor: topic === t ? colors.primary : colors.secondary, borderColor: topic === t ? colors.primary : colors.border }]}
                >
                  <Text style={[{ color: topic === t ? "#fff" : colors.text, fontFamily: "Inter_500Medium", fontSize: 12 }]}>{t}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <Text style={[addStyles.label, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>المهارات المكتسبة</Text>
            <View style={addStyles.skillsGrid}>
              {ALL_SKILLS.map((s) => (
                <TouchableOpacity
                  key={s}
                  onPress={() => toggleSkill(s)}
                  style={[addStyles.skillChip, {
                    backgroundColor: skills.includes(s) ? colors.primary + "20" : colors.secondary,
                    borderColor: skills.includes(s) ? colors.primary : colors.border,
                  }]}
                >
                  {skills.includes(s) && <Feather name="check" size={11} color={colors.primary} />}
                  <Text style={[{ color: skills.includes(s) ? colors.primary : colors.text, fontFamily: "Inter_500Medium", fontSize: 12 }]}>{s}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity style={[addStyles.submitBtn, { backgroundColor: colors.primary }]} onPress={submit}>
              <Feather name="plus-circle" size={18} color="#fff" />
              <Text style={[{ color: "#fff", fontSize: 16, fontFamily: "Inter_700Bold" }]}>إضافة النشاط</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const addStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: Platform.OS === "web" ? 20 : 40, maxHeight: "92%" },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 16 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  title: { fontSize: 18 },
  label: { fontSize: 13, marginBottom: 6 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, marginRight: 8, borderWidth: 1 },
  skillsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 16 },
  skillChip: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, borderWidth: 1 },
  submitBtn: { flexDirection: "row", borderRadius: 14, paddingVertical: 16, alignItems: "center", justifyContent: "center", gap: 8, marginTop: 8 },
});

export default function ActivitiesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { activities, deleteActivity, getPermissions, appSettings } = useApp();
  const { user } = useAuth();
  const permissions = getPermissions(user?.role ?? "guest");
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState("");
  const [topicFilter, setTopicFilter] = useState("الكل");

  const topPad = insets.top;
  const bottomPad = Platform.OS === "web" ? 84 + 16 : 90 + insets.bottom;

  const filtered = activities.filter((a) => {
    const matchSearch = a.title.includes(search) || a.description.includes(search) || a.topic.includes(search);
    const matchFilter = topicFilter === "الكل" || a.topic === topicFilter;
    return matchSearch && matchFilter;
  });

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 16, backgroundColor: colors.card, borderBottomColor: colors.border }]}>
        <View style={styles.headerTop}>
          <View>
            <Text style={[styles.screenTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{appSettings.activitiesPageTitle}</Text>
            <Text style={[styles.screenSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{activities.length} نشاط متاح</Text>
          </View>
          {permissions.canAddActivities && (
            <TouchableOpacity style={[styles.addBtn, { backgroundColor: colors.primary }]} onPress={() => setShowAdd(true)} activeOpacity={0.8}>
              <Feather name="plus" size={18} color="#fff" />
              <Text style={[styles.addBtnText, { fontFamily: "Inter_600SemiBold" }]}>إضافة</Text>
            </TouchableOpacity>
          )}
        </View>
        <View style={[styles.searchBox, { backgroundColor: colors.background, borderColor: colors.border }]}>
          <Feather name="search" size={16} color={colors.mutedForeground} />
          <TextInput value={search} onChangeText={setSearch} placeholder="ابحث عن نشاط..." placeholderTextColor={colors.mutedForeground} style={[styles.searchInput, { color: colors.text, fontFamily: "Inter_400Regular" }]} />
          {search.length > 0 && <TouchableOpacity onPress={() => setSearch("")}><Feather name="x" size={14} color={colors.mutedForeground} /></TouchableOpacity>}
        </View>
        <FlatList
          horizontal showsHorizontalScrollIndicator={false}
          data={TOPICS} keyExtractor={(f) => f}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => setTopicFilter(item)} style={[styles.filterChip, { backgroundColor: topicFilter === item ? colors.primary : colors.secondary, borderColor: topicFilter === item ? colors.primary : colors.border }]}>
              <Text style={[styles.filterText, { color: topicFilter === item ? "#fff" : colors.text, fontFamily: "Inter_500Medium" }]}>{item}</Text>
            </TouchableOpacity>
          )}
          style={{ marginTop: 10 }}
        />
      </View>
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ActivityCard activity={item} canDelete={permissions.canDeleteActivities} onDelete={deleteActivity} />
        )}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPad }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="star-circle" size={48} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
              {search ? "لا توجد نتائج" : "لا توجد أنشطة بعد"}
            </Text>
          </View>
        }
      />
      <AddActivityModal visible={showAdd} onClose={() => setShowAdd(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 14, borderBottomWidth: 1, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 3 },
  headerTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 14 },
  screenTitle: { fontSize: 22 },
  screenSub: { fontSize: 12, marginTop: 2 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20 },
  addBtnText: { color: "#fff", fontSize: 14 },
  searchBox: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, height: 44 },
  searchInput: { flex: 1, fontSize: 14 },
  filterChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, marginRight: 8, borderWidth: 1 },
  filterText: { fontSize: 12 },
  empty: { alignItems: "center", justifyContent: "center", paddingTop: 80, gap: 12 },
  emptyText: { fontSize: 14 },
});

import React, { useState, useRef } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Platform, Alert, Modal, TextInput, FlatList, Dimensions,
} from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { useColors } from "@/hooks/useColors";
import { useApp, ROLE_LABELS, ROLE_PERMISSIONS, normalizePermissions } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import * as Haptics from "expo-haptics";

const { width: SCREEN_W } = Dimensions.get("window");

const ROLE_COLORS: Record<string, string> = {
  guest: "#95A5A6", student: "#3498DB", teacher: "#9B59B6",
  supervisor: "#E67E22", admin: "#E74C3C",
};

const SYMBOL_LINKS: Record<string, string> = {
  "نمو": "/(tabs)/topics", "تعاون": "/(tabs)/activities",
  "إبداع": "/(tabs)/topics", "أهداف": "/(tabs)/events",
  "مغامرة": "/(tabs)/events", "فنون": "/(tabs)/topics",
  "بحث": "search", "عالمية": "/(tabs)/topics",
};

const NON_FORMAL_SYMBOLS = [
  { icon: "🌱", label: "نمو" }, { icon: "🤝", label: "تعاون" },
  { icon: "💡", label: "إبداع" }, { icon: "🎯", label: "أهداف" },
  { icon: "🏕️", label: "مغامرة" }, { icon: "🎭", label: "فنون" },
  { icon: "🔬", label: "بحث" }, { icon: "🌍", label: "عالمية" },
];

const ANN_COLORS = { low: "#27AE60", medium: "#E67E22", high: "#E74C3C" };

function SearchModal({ visible, onClose, events, activities }: any) {
  const colors = useColors();
  const router = useRouter();
  const [query, setQuery] = useState("");

  const results = query.trim().length > 1 ? [
    ...events.filter((e: any) => e.title.includes(query) || e.description?.includes(query) || e.location?.includes(query)).map((e: any) => ({ ...e, type: "event" })),
    ...activities.filter((a: any) => a.title.includes(query) || a.description?.includes(query) || a.topic?.includes(query)).map((a: any) => ({ ...a, type: "activity" })),
  ] : [];

  return (
    <Modal visible={visible} animationType="fade" transparent presentationStyle="overFullScreen">
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)" }}>
        <View style={{ backgroundColor: colors.background, paddingTop: Platform.OS === "web" ? 20 : 60, flex: 1 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: colors.border }}>
            <View style={{ flex: 1, flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.card, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 10, borderWidth: 1, borderColor: colors.border }}>
              <Feather name="search" size={18} color={colors.primary} />
              <TextInput value={query} onChangeText={setQuery} placeholder="ابحث في الفعاليات والأنشطة..."
                placeholderTextColor={colors.mutedForeground}
                style={{ flex: 1, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular" }} autoFocus />
              {query ? <TouchableOpacity onPress={() => setQuery("")}><Feather name="x" size={16} color={colors.mutedForeground} /></TouchableOpacity> : null}
            </View>
            <TouchableOpacity onPress={onClose} style={{ paddingHorizontal: 8, paddingVertical: 6 }}>
              <Text style={{ fontSize: 14, color: colors.primary, fontFamily: "Inter_600SemiBold" }}>إلغاء</Text>
            </TouchableOpacity>
          </View>
          {query.trim().length > 0 && results.length === 0 ? (
            <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
              <Text style={{ fontSize: 40, marginBottom: 12 }}>🔍</Text>
              <Text style={{ fontSize: 16, color: colors.text, fontFamily: "Inter_600SemiBold", marginBottom: 6 }}>لا نتائج</Text>
              <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>جرّب كلمات أخرى</Text>
            </View>
          ) : (
            <FlatList data={results} keyExtractor={(item) => item.id} contentContainerStyle={{ padding: 16 }}
              ListHeaderComponent={results.length > 0 ? (
                <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 12 }}>{results.length} نتيجة</Text>
              ) : null}
              renderItem={({ item }) => (
                <TouchableOpacity onPress={() => { onClose(); router.push(item.type === "event" ? "/(tabs)/events" : "/(tabs)/activities"); }}
                  style={{ flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: colors.card, borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: colors.border }} activeOpacity={0.8}>
                  <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: (item.type === "event" ? "#3498DB" : "#9B59B6") + "20", alignItems: "center", justifyContent: "center" }}>
                    <Feather name={item.type === "event" ? "calendar" : "star"} size={18} color={item.type === "event" ? "#3498DB" : "#9B59B6"} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 14, color: colors.text, fontFamily: "Inter_600SemiBold", marginBottom: 2 }}>{item.title}</Text>
                    <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                      {item.type === "event" ? `📅 ${item.date} · ${item.location}` : `🏷 ${item.topic}`}
                    </Text>
                  </View>
                  <Feather name="arrow-left" size={14} color={colors.mutedForeground} />
                </TouchableOpacity>
              )}
              ListEmptyComponent={query.length === 0 ? (
                <View style={{ alignItems: "center", paddingTop: 40 }}>
                  <Text style={{ fontSize: 50, marginBottom: 12 }}>🔍</Text>
                  <Text style={{ fontSize: 15, color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>ابدأ الكتابة للبحث</Text>
                </View>
              ) : null}
            />
          )}
        </View>
      </View>
    </Modal>
  );
}

function AnnouncementModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const colors = useColors();
  const { addAnnouncement } = useApp();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [priority, setPriority] = useState<"low" | "medium" | "high">("medium");
  const [target, setTarget] = useState<"top" | "notifications" | "both">("both");

  const submit = () => {
    if (!title.trim() || !content.trim()) { Alert.alert("تنبيه", "يرجى ملء العنوان والمحتوى"); return; }
    addAnnouncement({ title: title.trim(), content: content.trim(), priority });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setTitle(""); setContent(""); setPriority("medium"); setTarget("both");
    onClose();
    Alert.alert("✅ تم", "تم إرسال الإعلان بنجاح");
  };

  return (
    <Modal visible={visible} animationType="slide" transparent presentationStyle="overFullScreen">
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
        <View style={{ backgroundColor: colors.card, borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingBottom: Platform.OS === "web" ? 24 : 48 }}>
          <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border, alignSelf: "center", marginTop: 12, marginBottom: 16 }} />
          <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 10 }} keyboardShouldPersistTaps="handled">
            <Text style={{ fontSize: 18, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 16 }}>📢 إعلان جديد</Text>
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 6 }}>عنوان الإعلان *</Text>
            <TextInput value={title} onChangeText={setTitle} placeholder="مثال: ورشة عمل جديدة..." placeholderTextColor={colors.mutedForeground}
              style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 14 }} />
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 6 }}>محتوى الإعلان *</Text>
            <TextInput value={content} onChangeText={setContent} placeholder="اكتب تفاصيل الإعلان هنا..." placeholderTextColor={colors.mutedForeground}
              multiline numberOfLines={4}
              style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 14, minHeight: 100, textAlignVertical: "top" }} />
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 8 }}>الأولوية</Text>
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 14 }}>
              {(["low", "medium", "high"] as const).map((p) => {
                const labels = { low: "عادي", medium: "متوسط", high: "عاجل" };
                const pColors = { low: "#27AE60", medium: "#E67E22", high: "#E74C3C" };
                const isSelected = priority === p;
                return (
                  <TouchableOpacity key={p} onPress={() => setPriority(p)}
                    style={{ flex: 1, paddingVertical: 9, borderRadius: 12, alignItems: "center", backgroundColor: isSelected ? pColors[p] : colors.background, borderWidth: 1, borderColor: isSelected ? pColors[p] : colors.border }}>
                    <Text style={{ fontSize: 12, color: isSelected ? "#fff" : colors.text, fontFamily: "Inter_600SemiBold" }}>{labels[p]}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 8 }}>مكان الظهور</Text>
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 20 }}>
              {(["top", "notifications", "both"] as const).map((t) => {
                const labels = { top: "أعلى الشاشة", notifications: "الإشعارات", both: "كلاهما" };
                const isSelected = target === t;
                return (
                  <TouchableOpacity key={t} onPress={() => setTarget(t)}
                    style={{ flex: 1, paddingVertical: 9, borderRadius: 12, alignItems: "center", backgroundColor: isSelected ? colors.primary : colors.background, borderWidth: 1, borderColor: isSelected ? colors.primary : colors.border }}>
                    <Text style={{ fontSize: 11, color: isSelected ? "#fff" : colors.text, fontFamily: "Inter_600SemiBold", textAlign: "center" }}>{labels[t]}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
            <TouchableOpacity onPress={submit} style={{ backgroundColor: colors.primary, borderRadius: 16, paddingVertical: 16, alignItems: "center", marginBottom: 10 }} activeOpacity={0.85}>
              <Text style={{ color: "#fff", fontSize: 16, fontFamily: "Inter_700Bold" }}>إرسال الإعلان</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={onClose} style={{ alignItems: "center", paddingVertical: 8 }}>
              <Text style={{ color: colors.mutedForeground, fontSize: 14, fontFamily: "Inter_400Regular" }}>إلغاء</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

function AnnouncementsCarousel({ announcements }: { announcements: any[] }) {
  const colors = useColors();
  const [activeIndex, setActiveIndex] = useState(0);
  const flatRef = useRef<FlatList>(null);

  if (announcements.length === 0) return null;

  const cardW = SCREEN_W - 40;

  return (
    <View style={{ marginBottom: 18 }}>
      <FlatList
        ref={flatRef}
        data={announcements}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id}
        snapToInterval={cardW + 12}
        decelerationRate="fast"
        contentContainerStyle={{ gap: 12 }}
        onMomentumScrollEnd={(e) => {
          const idx = Math.round(e.nativeEvent.contentOffset.x / (cardW + 12));
          setActiveIndex(Math.min(idx, announcements.length - 1));
        }}
        renderItem={({ item }) => {
          const ac = ANN_COLORS[item.priority as keyof typeof ANN_COLORS] || colors.primary;
          return (
            <LinearGradient colors={[ac + "20", ac + "08"]} style={[styles.annCard, { width: cardW, borderColor: ac + "40" }]}>
              <View style={styles.annHeader}>
                <MaterialCommunityIcons name="bullhorn" size={15} color={ac} />
                <Text style={[styles.annBadge, { color: ac, fontFamily: "Inter_700Bold" }]}>
                  {item.priority === "high" ? "🔴 عاجل" : item.priority === "medium" ? "🟡 إعلان" : "📢 إعلان"}
                </Text>
              </View>
              <Text style={[styles.annTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{item.title}</Text>
              <Text style={[styles.annBody, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]} numberOfLines={2}>{item.content}</Text>
            </LinearGradient>
          );
        }}
      />
      {announcements.length > 1 && (
        <View style={styles.dotsRow}>
          {announcements.map((_, i) => (
            <TouchableOpacity key={i} onPress={() => {
              flatRef.current?.scrollToIndex({ index: i, animated: true });
              setActiveIndex(i);
            }}>
              <View style={[styles.dot, { backgroundColor: i === activeIndex ? colors.primary : colors.border, width: i === activeIndex ? 18 : 6 }]} />
            </TouchableOpacity>
          ))}
        </View>
      )}
    </View>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { events, activities, announcements, getPermissions, appSettings } = useApp();
  const { user, allUsers } = useAuth();
  const [showSearch, setShowSearch] = useState(false);
  const [showAnnouncement, setShowAnnouncement] = useState(false);

  const role = user?.role ?? "guest";
  const permissions = getPermissions(role);
  const roleColor = ROLE_COLORS[role] || colors.primary;
  const topPad = insets.top + 16;
  const bottomPad = Platform.OS === "web" ? 84 + 16 : 90 + insets.bottom;
  const memberCount = allUsers.length;

  const handleSymbol = (label: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const link = SYMBOL_LINKS[label];
    if (link === "search") setShowSearch(true);
    else if (link) router.push(link as any);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: bottomPad }}>
        <LinearGradient colors={[colors.primary + "30", colors.primary + "10", colors.background]} style={{ paddingTop: topPad, paddingHorizontal: 20, paddingBottom: 24 }}>
          <View style={styles.headerRow}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.greeting, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                أهلاً، {user?.fullName ?? "زائر"} 👋
              </Text>
              <Text style={[styles.appTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{appSettings.appName}</Text>
              <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginTop: 2 }}>{appSettings.subtitle}</Text>
            </View>
            <View style={styles.headerActions}>
              <TouchableOpacity onPress={() => setShowSearch(true)} style={[styles.iconBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Feather name="search" size={18} color={colors.text} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => router.push("/(tabs)/account")} style={[styles.iconBtn, { backgroundColor: roleColor + "20", borderColor: roleColor + "40" }]}>
                <Feather name="user" size={18} color={roleColor} />
              </TouchableOpacity>
            </View>
          </View>

          <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginTop: 12 }}>
            <View style={[styles.roleBadge, { backgroundColor: roleColor + "20", borderColor: roleColor + "40" }]}>
              <Feather name="shield" size={12} color={roleColor} />
              <Text style={[styles.roleBadgeText, { color: roleColor, fontFamily: "Inter_600SemiBold" }]}>{ROLE_LABELS[role] || role}</Text>
            </View>
            {permissions.canViewAdminPanel && (
              <TouchableOpacity onPress={() => router.push("/(tabs)/admin")} style={[styles.roleBadge, { backgroundColor: "#E74C3C20", borderColor: "#E74C3C40" }]}>
                <MaterialCommunityIcons name="shield-crown" size={12} color="#E74C3C" />
                <Text style={{ fontSize: 11, color: "#E74C3C", fontFamily: "Inter_600SemiBold" }}>لوحة الإدارة</Text>
              </TouchableOpacity>
            )}
          </View>
        </LinearGradient>

        <View style={{ paddingHorizontal: 20 }}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.symbolsRow}>
            {NON_FORMAL_SYMBOLS.map((s, i) => (
              <TouchableOpacity key={i} onPress={() => handleSymbol(s.label)} style={[styles.symbolCard, { backgroundColor: colors.card, borderColor: colors.border }]} activeOpacity={0.8}>
                <Text style={styles.symbolIcon}>{s.icon}</Text>
                <Text style={[styles.symbolLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>{s.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <AnnouncementsCarousel announcements={announcements} />

          <View style={styles.statsRow}>
            <StatCard value={events.length.toString()} label="فعالية" icon="calendar" color="#3498DB" onPress={() => router.push("/(tabs)/events")} colors={colors} />
            <StatCard value={activities.length.toString()} label="نشاط" icon="star" color="#9B59B6" onPress={() => router.push("/(tabs)/activities")} colors={colors} />
            <StatCard value={memberCount.toString()} label="عضو" icon="users" color="#E67E22" onPress={() => router.push("/(tabs)/account")} colors={colors} />
          </View>

          <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>اختصارات سريعة</Text>
          <View style={styles.quickGrid}>
            {[
              { icon: "calendar", label: "الفعاليات", color: "#3498DB", route: "/(tabs)/events" },
              { icon: "activity", label: "الأنشطة", color: "#9B59B6", route: "/(tabs)/activities" },
              { icon: "cpu", label: "مساعد ذكي", color: colors.primary, route: "/(tabs)/ai" },
              { icon: "book-open", label: "المواضيع", color: "#E67E22", route: "/(tabs)/topics" },
              { icon: "heart", label: "ضد العنف", color: "#E74C3C", route: "/(tabs)/antivio" },
              { icon: "user", label: "حسابي", color: "#16A085", route: "/(tabs)/account" },
              ...(permissions.canAddAnnouncements ? [{ icon: "bell", label: "إعلان جديد", color: "#1ABC9C", route: "announce" }] : []),
              ...(permissions.canViewAdminPanel ? [{ icon: "shield", label: "الإدارة", color: "#E74C3C", route: "/(tabs)/admin" }] : []),
            ].map(({ icon, label, color, route }) => (
              <QuickBtn key={label} icon={icon} label={label} color={color}
                onPress={() => route === "announce" ? setShowAnnouncement(true) : router.push(route as any)}
                colors={colors} />
            ))}
          </View>

          {events.length > 0 && (
            <>
              <View style={styles.sectionHeader}>
                <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>أحدث الفعاليات</Text>
                <TouchableOpacity onPress={() => router.push("/(tabs)/events")}>
                  <Text style={[styles.seeAll, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>عرض الكل</Text>
                </TouchableOpacity>
              </View>
              {events.slice(0, 4).map((evt) => (
                <TouchableOpacity key={evt.id} style={[styles.miniCard, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => router.push("/(tabs)/events")} activeOpacity={0.8}>
                  <LinearGradient colors={[colors.primary + "20", colors.primary + "05"]} style={styles.miniDot}>
                    <Feather name="calendar" size={14} color={colors.primary} />
                  </LinearGradient>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.miniTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{evt.title}</Text>
                    <Text style={[styles.miniMeta, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>📅 {evt.date} · 📍 {evt.location}</Text>
                  </View>
                  <View style={{ backgroundColor: colors.primary + "15", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 }}>
                    <Text style={{ fontSize: 10, color: colors.primary, fontFamily: "Inter_600SemiBold" }}>{evt.category}</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </>
          )}

          <View style={styles.footer}>
            <Text style={[styles.footerProject, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>مشروع التخرج</Text>
            <Text style={[styles.footerName, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{appSettings.footerName}</Text>
            <Text style={[styles.footerSup, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>{appSettings.footerSupervisor}</Text>
          </View>
        </View>
      </ScrollView>
      <SearchModal visible={showSearch} onClose={() => setShowSearch(false)} events={events} activities={activities} />
      <AnnouncementModal visible={showAnnouncement} onClose={() => setShowAnnouncement(false)} />
    </View>
  );
}

function StatCard({ value, label, icon, color, onPress, colors }: any) {
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.8} style={{ flex: 1 }}>
      <LinearGradient colors={[color + "20", color + "08"]} style={[styles.statCard, { borderColor: color + "35" }]}>
        <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: color + "25", alignItems: "center", justifyContent: "center" }}>
          <Feather name={icon} size={18} color={color} />
        </View>
        <Text style={[styles.statValue, { color, fontFamily: "Inter_700Bold" }]}>{value}</Text>
        <Text style={[styles.statLabel, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{label}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
}

function QuickBtn({ icon, label, color, onPress, colors }: any) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.quickCard, { backgroundColor: colors.card, borderColor: colors.border }]} activeOpacity={0.8}>
      <View style={[styles.quickIcon, { backgroundColor: color + "20" }]}>
        <Feather name={icon} size={22} color={color} />
      </View>
      <Text style={[styles.quickLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerRow: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  greeting: { fontSize: 13, marginBottom: 2 },
  appTitle: { fontSize: 22 },
  headerActions: { alignItems: "flex-end", gap: 8, flexDirection: "row" },
  iconBtn: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  roleBadge: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1.5 },
  roleBadgeText: { fontSize: 11 },
  symbolsRow: { marginBottom: 18, marginTop: 4 },
  symbolCard: { alignItems: "center", paddingHorizontal: 14, paddingVertical: 10, borderRadius: 16, marginRight: 10, borderWidth: 1, minWidth: 64 },
  symbolIcon: { fontSize: 22, marginBottom: 4 },
  symbolLabel: { fontSize: 10 },
  annCard: { borderRadius: 18, padding: 14, borderWidth: 1 },
  annHeader: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 6 },
  annBadge: { fontSize: 12 },
  annTitle: { fontSize: 14, marginBottom: 4 },
  annBody: { fontSize: 12, lineHeight: 18 },
  dotsRow: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 5, marginTop: 10 },
  dot: { height: 6, borderRadius: 3 },
  statsRow: { flexDirection: "row", gap: 10, marginBottom: 24 },
  statCard: { alignItems: "center", padding: 14, borderRadius: 18, borderWidth: 1, gap: 6 },
  statValue: { fontSize: 22 },
  statLabel: { fontSize: 11 },
  sectionTitle: { fontSize: 17, marginBottom: 14 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  seeAll: { fontSize: 13 },
  quickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12, marginBottom: 24 },
  quickCard: { width: "46%", borderRadius: 18, padding: 16, alignItems: "center", gap: 10, borderWidth: 1, shadowColor: "#000", shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.07, shadowRadius: 10, elevation: 3 },
  quickIcon: { width: 52, height: 52, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  quickLabel: { fontSize: 13, textAlign: "center" },
  miniCard: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 16, padding: 12, marginBottom: 10, borderWidth: 1 },
  miniDot: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  miniTitle: { fontSize: 13, marginBottom: 3 },
  miniMeta: { fontSize: 11 },
  footer: { alignItems: "center", marginTop: 32, paddingBottom: 12 },
  footerProject: { fontSize: 12, marginBottom: 4 },
  footerName: { fontSize: 18, marginBottom: 4 },
  footerSup: { fontSize: 14 },
});

import React, { useState } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Platform,
  Alert, Modal, TextInput, FlatList, Image,
} from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { useColors } from "@/hooks/useColors";
import { useApp, AntiViolencePost } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";

const ACCENT = "#E74C3C";
const ACCENT2 = "#C0392B";

function AddPostModal({ visible, onClose, authorName }: { visible: boolean; onClose: () => void; authorName: string }) {
  const colors = useColors();
  const { addAntiViolencePost } = useApp();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [mediaType, setMediaType] = useState<"text" | "image" | "video">("text");
  const [mediaUrl, setMediaUrl] = useState("");
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);

  const pickMedia = async (type: "image" | "video") => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: type === "image" ? ImagePicker.MediaTypeOptions.Images : ImagePicker.MediaTypeOptions.Videos,
        allowsEditing: type === "image",
        quality: 0.7,
        base64: type === "image",
      });
      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        const uri = type === "image" && asset.base64
          ? `data:image/jpeg;base64,${asset.base64}`
          : asset.uri;
        setMediaUrl(uri);
        setMediaPreview(uri);
      }
    } catch {
    }
  };

  const submit = () => {
    if (!title.trim() || !content.trim()) {
      if (Platform.OS === "web") window.alert("العنوان والمحتوى مطلوبان");
      else Alert.alert("تنبيه", "العنوان والمحتوى مطلوبان");
      return;
    }
    addAntiViolencePost({
      title: title.trim(), content: content.trim(), mediaType,
      mediaUrl: mediaUrl.trim() || undefined, author: authorName, date,
    });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setTitle(""); setContent(""); setMediaType("text"); setMediaUrl(""); setMediaPreview(null); setDate(new Date().toISOString().split("T")[0]);
    onClose();
  };

  const mediaTypes = [
    { id: "text" as const, label: "نص", icon: "file-text" },
    { id: "image" as const, label: "صورة", icon: "image" },
    { id: "video" as const, label: "فيديو", icon: "video" },
  ];

  return (
    <Modal visible={visible} animationType="slide" transparent presentationStyle="overFullScreen">
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.55)", justifyContent: "flex-end" }}>
        <View style={{ backgroundColor: colors.card, borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingBottom: Platform.OS === "web" ? 24 : 48, maxHeight: "92%" }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: colors.border }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
              <LinearGradient colors={[ACCENT, ACCENT2]} style={{ width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" }}>
                <MaterialCommunityIcons name="hand-peace" size={18} color="#fff" />
              </LinearGradient>
              <Text style={{ fontSize: 17, color: colors.text, fontFamily: "Inter_700Bold" }}>إضافة لقاء جديد</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.background, alignItems: "center", justifyContent: "center" }}>
              <Feather name="x" size={18} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 10 }} keyboardShouldPersistTaps="handled">
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 6 }}>عنوان اللقاء *</Text>
            <TextInput value={title} onChangeText={setTitle} placeholder="مثال: لقاء توعوي ضد العنف المدرسي" placeholderTextColor={colors.mutedForeground}
              style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 14 }} />

            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 6 }}>وصف اللقاء *</Text>
            <TextInput value={content} onChangeText={setContent} placeholder="اكتب تفاصيل اللقاء والأنشطة التي تمت..." placeholderTextColor={colors.mutedForeground}
              multiline numberOfLines={4}
              style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 14, minHeight: 100, textAlignVertical: "top" }} />

            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 8 }}>نوع المحتوى</Text>
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 14 }}>
              {mediaTypes.map(({ id, label, icon }) => {
                const isSelected = mediaType === id;
                return (
                  <TouchableOpacity key={id} onPress={() => { setMediaType(id); setMediaUrl(""); setMediaPreview(null); }}
                    style={{ flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, paddingVertical: 10, borderRadius: 12, backgroundColor: isSelected ? ACCENT : colors.background, borderWidth: 1, borderColor: isSelected ? ACCENT : colors.border }}>
                    <Feather name={icon as any} size={14} color={isSelected ? "#fff" : colors.mutedForeground} />
                    <Text style={{ fontSize: 12, color: isSelected ? "#fff" : colors.text, fontFamily: "Inter_600SemiBold" }}>{label}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {mediaType === "image" && (
              <>
                {mediaPreview ? (
                  <View style={{ borderRadius: 14, overflow: "hidden", marginBottom: 10, position: "relative" }}>
                    <Image source={{ uri: mediaPreview }} style={{ width: "100%", height: 180 }} resizeMode="cover" />
                    <TouchableOpacity onPress={() => { setMediaUrl(""); setMediaPreview(null); }}
                      style={{ position: "absolute", top: 8, right: 8, width: 32, height: 32, borderRadius: 8, backgroundColor: "rgba(0,0,0,0.6)", alignItems: "center", justifyContent: "center" }}>
                      <Feather name="x" size={16} color="#fff" />
                    </TouchableOpacity>
                  </View>
                ) : (
                  <TouchableOpacity onPress={() => pickMedia("image")} activeOpacity={0.8}
                    style={{ backgroundColor: ACCENT + "15", borderRadius: 14, padding: 18, alignItems: "center", gap: 8, borderWidth: 1.5, borderColor: ACCENT + "40", borderStyle: "dashed", marginBottom: 14 }}>
                    <Feather name="image" size={28} color={ACCENT} />
                    <Text style={{ fontSize: 14, color: ACCENT, fontFamily: "Inter_600SemiBold" }}>اختر صورة من الجهاز</Text>
                    <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>JPG, PNG, WEBP</Text>
                  </TouchableOpacity>
                )}
                <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginBottom: 6 }}>أو أدخل رابط الصورة مباشرةً</Text>
                <TextInput value={mediaPreview ? "" : mediaUrl} onChangeText={v => { setMediaUrl(v); setMediaPreview(null); }}
                  placeholder="https://example.com/image.jpg" placeholderTextColor={colors.mutedForeground} autoCapitalize="none"
                  style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 13, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 14 }} />
              </>
            )}

            {mediaType === "video" && (
              <>
                {mediaPreview ? (
                  <View style={{ backgroundColor: "#9B59B620", borderRadius: 14, padding: 14, marginBottom: 10, flexDirection: "row", alignItems: "center", gap: 12 }}>
                    <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: "#9B59B6", alignItems: "center", justifyContent: "center" }}>
                      <Feather name="video" size={18} color="#fff" />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_600SemiBold" }}>تم اختيار الفيديو ✓</Text>
                      <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }} numberOfLines={1}>{mediaUrl}</Text>
                    </View>
                    <TouchableOpacity onPress={() => { setMediaUrl(""); setMediaPreview(null); }}>
                      <Feather name="x" size={16} color={colors.mutedForeground} />
                    </TouchableOpacity>
                  </View>
                ) : (
                  <TouchableOpacity onPress={() => pickMedia("video")} activeOpacity={0.8}
                    style={{ backgroundColor: "#9B59B615", borderRadius: 14, padding: 18, alignItems: "center", gap: 8, borderWidth: 1.5, borderColor: "#9B59B640", borderStyle: "dashed", marginBottom: 10 }}>
                    <Feather name="video" size={28} color="#9B59B6" />
                    <Text style={{ fontSize: 14, color: "#9B59B6", fontFamily: "Inter_600SemiBold" }}>اختر فيديو من الجهاز</Text>
                    <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>MP4, MOV</Text>
                  </TouchableOpacity>
                )}
                <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginBottom: 6 }}>أو أدخل رابط فيديو (YouTube...)</Text>
                <TextInput value={mediaPreview ? "" : mediaUrl} onChangeText={v => { setMediaUrl(v); setMediaPreview(null); }}
                  placeholder="https://youtube.com/watch?v=..." placeholderTextColor={colors.mutedForeground} autoCapitalize="none"
                  style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 13, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 14 }} />
              </>
            )}

            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginBottom: 6 }}>تاريخ اللقاء</Text>
            <TextInput value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" placeholderTextColor={colors.mutedForeground}
              style={{ backgroundColor: colors.background, borderRadius: 12, borderWidth: 1, borderColor: colors.border, padding: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", marginBottom: 20 }} />

            <TouchableOpacity onPress={submit} style={{ backgroundColor: ACCENT, borderRadius: 16, paddingVertical: 16, alignItems: "center", marginBottom: 10 }} activeOpacity={0.85}>
              <Text style={{ color: "#fff", fontSize: 16, fontFamily: "Inter_700Bold" }}>نشر اللقاء</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

function PostCard({ post, canDelete, onDelete }: { post: AntiViolencePost; canDelete: boolean; onDelete: () => void }) {
  const colors = useColors();
  const [showFull, setShowFull] = useState(false);
  const isLong = post.content.length > 200;

  const mediaIcon = post.mediaType === "image" ? "image" : post.mediaType === "video" ? "video" : "file-text";
  const mediaColor = post.mediaType === "image" ? "#3498DB" : post.mediaType === "video" ? "#9B59B6" : ACCENT;

  return (
    <View style={[styles.postCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <LinearGradient colors={[ACCENT + "18", ACCENT + "05"]} style={styles.postGrad}>
        <View style={styles.postHeader}>
          <View style={[styles.mediaIcon, { backgroundColor: mediaColor + "20" }]}>
            <Feather name={mediaIcon as any} size={16} color={mediaColor} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.postTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{post.title}</Text>
            <View style={{ flexDirection: "row", gap: 10, marginTop: 3 }}>
              <Text style={[styles.postMeta, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                ✍️ {post.author}
              </Text>
              <Text style={[styles.postMeta, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                📅 {post.date}
              </Text>
            </View>
          </View>
          {canDelete && (
            <TouchableOpacity onPress={onDelete} style={[styles.deleteBtn, { backgroundColor: "#E74C3C20" }]}>
              <Feather name="trash-2" size={14} color="#E74C3C" />
            </TouchableOpacity>
          )}
        </View>

        {post.mediaType === "image" && post.mediaUrl ? (
          <View style={{ borderRadius: 14, overflow: "hidden", marginBottom: 10 }}>
            <Image source={{ uri: post.mediaUrl }} style={{ width: "100%", height: 200 }} resizeMode="cover"
              onError={() => {}} />
          </View>
        ) : post.mediaType === "video" && post.mediaUrl ? (
          <TouchableOpacity
            onPress={() => Alert.alert("فيديو", `رابط الفيديو:\n${post.mediaUrl}`)}
            style={{ backgroundColor: "#9B59B620", borderRadius: 14, padding: 14, marginBottom: 10, flexDirection: "row", alignItems: "center", gap: 10 }}>
            <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: "#9B59B6", alignItems: "center", justifyContent: "center" }}>
              <Feather name="play" size={18} color="#fff" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_600SemiBold" }}>مشاهدة الفيديو</Text>
              <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }} numberOfLines={1}>{post.mediaUrl}</Text>
            </View>
          </TouchableOpacity>
        ) : null}

        <Text style={[styles.postContent, { color: colors.text, fontFamily: "Inter_400Regular" }]} numberOfLines={showFull ? undefined : 4}>
          {post.content}
        </Text>
        {isLong && (
          <TouchableOpacity onPress={() => setShowFull(!showFull)} style={{ marginTop: 6 }}>
            <Text style={{ fontSize: 12, color: ACCENT, fontFamily: "Inter_600SemiBold" }}>
              {showFull ? "▲ اقرأ أقل" : "▼ اقرأ المزيد"}
            </Text>
          </TouchableOpacity>
        )}
      </LinearGradient>
    </View>
  );
}

export default function AntiVioScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { antiViolencePosts, deleteAntiViolencePost, getPermissions, appSettings } = useApp();
  const { user } = useAuth();
  const [showAdd, setShowAdd] = useState(false);

  const topPad = insets.top;
  const bottomPad = Platform.OS === "web" ? 84 + 16 : 90 + insets.bottom;
  const perms = getPermissions(user?.role ?? "student");
  const canAdd = perms.canAddAnnouncements || perms.canViewAdminPanel || perms.canManageContent;
  const canDelete = perms.canDeleteAnnouncements || perms.canViewAdminPanel;

  const handleDelete = (post: AntiViolencePost) => {
    if (Platform.OS === "web") {
      if (window.confirm(`هل تريد حذف "${post.title}"؟`)) {
        deleteAntiViolencePost(post.id);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      }
      return;
    }
    Alert.alert("حذف اللقاء", `هل تريد حذف "${post.title}"؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => { deleteAntiViolencePost(post.id); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning); } },
    ]);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient colors={[ACCENT + "25", ACCENT + "08", colors.background]} style={[styles.header, { paddingTop: topPad + 16 }]}>
        <View style={styles.headerRow}>
          <LinearGradient colors={[ACCENT, ACCENT2]} style={styles.headerIcon}>
            <MaterialCommunityIcons name="hand-peace" size={26} color="#fff" />
          </LinearGradient>
          <View style={{ flex: 1 }}>
            <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{appSettings.antivioPageTitle}</Text>
            <Text style={[styles.headerSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
              {appSettings.antivioPageDesc}
            </Text>
          </View>
          {canAdd && (
            <TouchableOpacity onPress={() => setShowAdd(true)}
              style={[styles.addBtn, { backgroundColor: ACCENT }]} activeOpacity={0.85}>
              <Feather name="plus" size={20} color="#fff" />
            </TouchableOpacity>
          )}
        </View>

        <View style={[styles.statsBanner, { backgroundColor: ACCENT + "15", borderColor: ACCENT + "30" }]}>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: ACCENT, fontFamily: "Inter_700Bold" }]}>{antiViolencePosts.length}</Text>
            <Text style={[styles.statLabel, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>لقاء منشور</Text>
          </View>
          <View style={[styles.statDivider, { backgroundColor: ACCENT + "30" }]} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: ACCENT, fontFamily: "Inter_700Bold" }]}>
              {antiViolencePosts.filter(p => p.mediaType === "image").length}
            </Text>
            <Text style={[styles.statLabel, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>صورة</Text>
          </View>
          <View style={[styles.statDivider, { backgroundColor: ACCENT + "30" }]} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: ACCENT, fontFamily: "Inter_700Bold" }]}>
              {antiViolencePosts.filter(p => p.mediaType === "video").length}
            </Text>
            <Text style={[styles.statLabel, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>فيديو</Text>
          </View>
        </View>
      </LinearGradient>

      <FlatList
        data={antiViolencePosts}
        keyExtractor={(p) => p.id}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPad }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <PostCard post={item} canDelete={canDelete} onDelete={() => handleDelete(item)} />
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="hand-peace" size={64} color={ACCENT + "50"} />
            <Text style={[styles.emptyTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>لا يوجد لقاءات بعد</Text>
            <Text style={[styles.emptyDesc, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
              {canAdd ? "اضغط + لإضافة أول لقاء توعوي ضد العنف" : "ستظهر هنا لقاءات التوعية ضد العنف عند إضافتها"}
            </Text>
          </View>
        }
        ListHeaderComponent={antiViolencePosts.length > 0 ? (
          <View style={[styles.messageBox, { backgroundColor: ACCENT + "10", borderColor: ACCENT + "25" }]}>
            <MaterialCommunityIcons name="shield-check" size={18} color={ACCENT} />
            <Text style={[styles.messageText, { color: ACCENT, fontFamily: "Inter_500Medium" }]}>
              معاً ضد العنف — كل لقاء خطوة نحو مجتمع أكثر أماناً وتسامحاً
            </Text>
          </View>
        ) : null}
      />

      <AddPostModal visible={showAdd} onClose={() => setShowAdd(false)} authorName={user?.fullName ?? "مشارك"} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 14 },
  headerIcon: { width: 52, height: 52, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 20 },
  headerSub: { fontSize: 12, marginTop: 2 },
  addBtn: { width: 44, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  statsBanner: { flexDirection: "row", borderRadius: 16, padding: 14, borderWidth: 1 },
  statItem: { flex: 1, alignItems: "center" },
  statValue: { fontSize: 22 },
  statLabel: { fontSize: 11, marginTop: 2 },
  statDivider: { width: 1, marginHorizontal: 8 },
  postCard: { borderRadius: 18, marginBottom: 14, overflow: "hidden", borderWidth: 1, shadowColor: "#000", shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.08, shadowRadius: 10, elevation: 4 },
  postGrad: { padding: 16 },
  postHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginBottom: 12 },
  mediaIcon: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  postTitle: { fontSize: 15, lineHeight: 22 },
  postMeta: { fontSize: 11 },
  deleteBtn: { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  postContent: { fontSize: 14, lineHeight: 22 },
  messageBox: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 12, marginBottom: 14, borderWidth: 1 },
  messageText: { flex: 1, fontSize: 12, lineHeight: 18 },
  empty: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyTitle: { fontSize: 18 },
  emptyDesc: { fontSize: 13, textAlign: "center", paddingHorizontal: 40, lineHeight: 20 },
});

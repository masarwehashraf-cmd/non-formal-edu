import React, { useState, useEffect, useRef } from "react";
import {
  View, Text, FlatList, TouchableOpacity, TextInput, Modal, StyleSheet,
  Platform, KeyboardAvoidingView, ScrollView,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/context/AuthContext";
import { useApp, ROLE_LABELS } from "@/context/AppContext";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";

interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  createdAt: string;
}

const ROLE_COLORS: Record<string, string> = {
  guest: "#95A5A6", student: "#3498DB", teacher: "#9B59B6",
  supervisor: "#E67E22", admin: "#E74C3C",
};

function getChatKey(id1: string, id2: string) {
  return `chat_${[id1, id2].sort().join("_")}`;
}

function formatTime(iso: string) {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" });
  } catch { return ""; }
}

function formatDate(iso: string) {
  try {
    const d = new Date(iso);
    const today = new Date();
    const diff = today.getDate() - d.getDate();
    if (diff === 0 && today.getMonth() === d.getMonth()) return "اليوم";
    if (diff === 1 && today.getMonth() === d.getMonth()) return "أمس";
    return d.toLocaleDateString("ar");
  } catch { return ""; }
}

function ConversationModal({ currentUser, otherUser, onClose, colors, customRoles }: {
  currentUser: { id: string; fullName: string };
  otherUser: { id: string; fullName: string; role: string };
  onClose: () => void;
  colors: ReturnType<typeof useColors>;
  customRoles: { id: string; name: string }[];
}) {
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState("");
  const flatRef = useRef<FlatList>(null);
  const roleColor = ROLE_COLORS[otherUser.role] || "#9B59B6";
  const roleLabel = ROLE_LABELS[otherUser.role] || customRoles.find(r => r.id === otherUser.role)?.name || otherUser.role;

  const loadMessages = async () => {
    try {
      const key = getChatKey(currentUser.id, otherUser.id);
      const raw = await AsyncStorage.getItem(key);
      if (raw) setMessages(JSON.parse(raw));
    } catch {}
  };

  useEffect(() => {
    loadMessages();
    const interval = setInterval(loadMessages, 2000);
    return () => clearInterval(interval);
  }, []);

  const sendMessage = async () => {
    if (!text.trim()) return;
    const key = getChatKey(currentUser.id, otherUser.id);
    const msg: ChatMessage = {
      id: Date.now().toString(),
      senderId: currentUser.id,
      senderName: currentUser.fullName,
      text: text.trim(),
      createdAt: new Date().toISOString(),
    };
    const updated = [...messages, msg];
    await AsyncStorage.setItem(key, JSON.stringify(updated));
    setMessages(updated);
    setText("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
  };

  const clearChat = async () => {
    const key = getChatKey(currentUser.id, otherUser.id);
    await AsyncStorage.removeItem(key);
    setMessages([]);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
  };

  return (
    <Modal visible animationType="slide" presentationStyle={Platform.OS === "ios" ? "pageSheet" : "fullScreen"}>
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <LinearGradient colors={[roleColor + "25", roleColor + "08", colors.background]}
          style={{ paddingTop: insets.top + 12, paddingBottom: 14, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: colors.border }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
            <TouchableOpacity onPress={onClose} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: colors.card, alignItems: "center", justifyContent: "center" }}>
              <Feather name="arrow-right" size={18} color={colors.text} />
            </TouchableOpacity>
            <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: roleColor + "25", alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: roleColor + "50" }}>
              <Text style={{ fontSize: 20 }}>
                {otherUser.role === "admin" ? "👑" : otherUser.role === "supervisor" ? "🎓" : otherUser.role === "teacher" ? "📚" : "🙋"}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 16, color: colors.text, fontFamily: "Inter_700Bold" }}>{otherUser.fullName}</Text>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 }}>
                <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: roleColor }} />
                <Text style={{ fontSize: 11, color: roleColor, fontFamily: "Inter_500Medium" }}>{roleLabel}</Text>
              </View>
            </View>
            {messages.length > 0 && (
              <TouchableOpacity onPress={clearChat} style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: "#E74C3C15", alignItems: "center", justifyContent: "center" }}>
                <Feather name="trash-2" size={15} color="#E74C3C" />
              </TouchableOpacity>
            )}
          </View>
        </LinearGradient>

        <FlatList
          ref={flatRef}
          data={messages}
          keyExtractor={(m) => m.id}
          contentContainerStyle={{ padding: 16, paddingBottom: 8, flexGrow: 1 }}
          onLayout={() => flatRef.current?.scrollToEnd({ animated: false })}
          ListEmptyComponent={
            <View style={{ flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 60 }}>
              <Text style={{ fontSize: 40, marginBottom: 12 }}>💬</Text>
              <Text style={{ fontSize: 16, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 6 }}>ابدأ المحادثة</Text>
              <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular", textAlign: "center", paddingHorizontal: 40 }}>
                أرسل رسالة لـ {otherUser.fullName}
              </Text>
            </View>
          }
          renderItem={({ item, index }) => {
            const isMine = item.senderId === currentUser.id;
            const prevMsg = messages[index - 1];
            const showDate = !prevMsg || formatDate(item.createdAt) !== formatDate(prevMsg.createdAt);
            return (
              <View>
                {showDate && (
                  <View style={{ alignItems: "center", marginVertical: 12 }}>
                    <View style={{ backgroundColor: colors.secondary, paddingHorizontal: 12, paddingVertical: 4, borderRadius: 20 }}>
                      <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_500Medium" }}>{formatDate(item.createdAt)}</Text>
                    </View>
                  </View>
                )}
                <View style={{ alignItems: isMine ? "flex-end" : "flex-start", marginBottom: 8 }}>
                  <View style={{
                    maxWidth: "78%", backgroundColor: isMine ? colors.primary : colors.card,
                    borderRadius: 18, borderBottomRightRadius: isMine ? 4 : 18, borderBottomLeftRadius: isMine ? 18 : 4,
                    padding: 12, paddingHorizontal: 14, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2,
                  }}>
                    <Text style={{ fontSize: 14, color: isMine ? "#fff" : colors.text, fontFamily: "Inter_400Regular", lineHeight: 21 }}>{item.text}</Text>
                    <Text style={{ fontSize: 10, color: isMine ? "rgba(255,255,255,0.65)" : colors.mutedForeground, fontFamily: "Inter_400Regular", marginTop: 4, textAlign: "right" }}>
                      {formatTime(item.createdAt)}
                    </Text>
                  </View>
                </View>
              </View>
            );
          }}
        />

        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} keyboardVerticalOffset={0}>
          <View style={{ flexDirection: "row", alignItems: "flex-end", gap: 10, padding: 12, paddingBottom: insets.bottom > 0 ? insets.bottom : 16, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: colors.card }}>
            <TextInput
              value={text}
              onChangeText={setText}
              placeholder={`رسالة إلى ${otherUser.fullName}...`}
              placeholderTextColor={colors.mutedForeground}
              multiline
              style={{ flex: 1, backgroundColor: colors.background, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", maxHeight: 120, minHeight: 42, borderWidth: 1, borderColor: colors.border }}
              onSubmitEditing={sendMessage}
            />
            <TouchableOpacity onPress={sendMessage} activeOpacity={0.8}
              style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: text.trim() ? colors.primary : colors.secondary, alignItems: "center", justifyContent: "center" }}>
              <Feather name="send" size={18} color={text.trim() ? "#fff" : colors.mutedForeground} style={{ transform: [{ rotate: "180deg" }] }} />
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  );
}

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, allUsers } = useAuth();
  const { customRoles } = useApp();
  const [chatWith, setChatWith] = useState<typeof allUsers[0] | null>(null);
  const [lastMessages, setLastMessages] = useState<Record<string, ChatMessage | null>>({});
  const [search, setSearch] = useState("");

  const topPad = insets.top;
  const bottomPad = Platform.OS === "web" ? 84 + 16 : 90 + insets.bottom;

  const otherUsers = allUsers.filter(u => u.id !== user?.id);
  const filtered = otherUsers.filter(u =>
    u.fullName.includes(search) || u.username.includes(search)
  );

  const loadLastMessages = async () => {
    if (!user) return;
    const result: Record<string, ChatMessage | null> = {};
    for (const u of otherUsers) {
      try {
        const key = getChatKey(user.id, u.id);
        const raw = await AsyncStorage.getItem(key);
        if (raw) {
          const msgs: ChatMessage[] = JSON.parse(raw);
          result[u.id] = msgs[msgs.length - 1] || null;
        } else {
          result[u.id] = null;
        }
      } catch {
        result[u.id] = null;
      }
    }
    setLastMessages(result);
  };

  useEffect(() => {
    loadLastMessages();
    const interval = setInterval(loadLastMessages, 3000);
    return () => clearInterval(interval);
  }, [allUsers]);

  if (!user) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, justifyContent: "center", alignItems: "center" }]}>
        <Text style={{ color: colors.text, fontFamily: "Inter_500Medium" }}>الرجاء تسجيل الدخول أولاً</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient colors={[colors.primary + "20", colors.primary + "06", colors.background]}
        style={{ paddingTop: topPad + 16, paddingHorizontal: 20, paddingBottom: 16 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 16 }}>
          <LinearGradient colors={[colors.primary, colors.primary + "CC"]}
            style={{ width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" }}>
            <Feather name="message-circle" size={22} color="#fff" />
          </LinearGradient>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 22, color: colors.text, fontFamily: "Inter_700Bold" }}>الدردشة</Text>
            <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginTop: 2 }}>
              {otherUsers.length} عضو متاح للتواصل
            </Text>
          </View>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: colors.card, borderRadius: 14, paddingHorizontal: 14, borderWidth: 1, borderColor: colors.border }}>
          <Feather name="search" size={16} color={colors.mutedForeground} />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="البحث عن عضو..."
            placeholderTextColor={colors.mutedForeground}
            style={{ flex: 1, paddingVertical: 12, fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular" }}
          />
        </View>
      </LinearGradient>

      <FlatList
        data={filtered}
        keyExtractor={(u) => u.id}
        contentContainerStyle={{ padding: 16, paddingBottom: bottomPad }}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={{ height: 1, backgroundColor: colors.border, marginHorizontal: 4 }} />}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingTop: 60, gap: 12 }}>
            <Text style={{ fontSize: 48 }}>💬</Text>
            <Text style={{ fontSize: 16, color: colors.text, fontFamily: "Inter_700Bold" }}>
              {search ? "لا نتائج" : "لا يوجد أعضاء بعد"}
            </Text>
            <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular", textAlign: "center", paddingHorizontal: 40 }}>
              {search ? "جرب كلمة بحث مختلفة" : "سيظهر الأعضاء المسجلون هنا للتواصل معهم"}
            </Text>
          </View>
        }
        renderItem={({ item }) => {
          const roleColor = ROLE_COLORS[item.role] || "#9B59B6";
          const roleLabel = ROLE_LABELS[item.role] || customRoles.find(r => r.id === item.role)?.name || item.role;
          const lastMsg = lastMessages[item.id];
          const roleEmoji = item.role === "admin" ? "👑" : item.role === "supervisor" ? "🎓" : item.role === "teacher" ? "📚" : "🙋";
          return (
            <TouchableOpacity onPress={() => { setChatWith(item); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }} activeOpacity={0.7}
              style={{ flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 14, paddingHorizontal: 4 }}>
              <View style={{ width: 50, height: 50, borderRadius: 16, backgroundColor: roleColor + "20", alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: roleColor + "40" }}>
                <Text style={{ fontSize: 22 }}>{roleEmoji}</Text>
              </View>
              <View style={{ flex: 1, gap: 3 }}>
                <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                  <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold" }}>{item.fullName}</Text>
                  {lastMsg && (
                    <Text style={{ fontSize: 10, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                      {formatTime(lastMsg.createdAt)}
                    </Text>
                  )}
                </View>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                  <View style={{ backgroundColor: roleColor + "20", paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8 }}>
                    <Text style={{ fontSize: 10, color: roleColor, fontFamily: "Inter_600SemiBold" }}>{roleLabel}</Text>
                  </View>
                  {lastMsg ? (
                    <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }} numberOfLines={1}>
                      {lastMsg.senderId === user.id ? "أنت: " : ""}{lastMsg.text}
                    </Text>
                  ) : (
                    <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", fontStyle: "italic" }}>
                      ابدأ المحادثة...
                    </Text>
                  )}
                </View>
              </View>
              <Feather name="chevron-left" size={16} color={colors.mutedForeground} />
            </TouchableOpacity>
          );
        }}
      />

      {chatWith && user && (
        <ConversationModal
          currentUser={{ id: user.id, fullName: user.fullName }}
          otherUser={chatWith}
          onClose={() => { setChatWith(null); loadLastMessages(); }}
          colors={colors}
          customRoles={customRoles}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
});

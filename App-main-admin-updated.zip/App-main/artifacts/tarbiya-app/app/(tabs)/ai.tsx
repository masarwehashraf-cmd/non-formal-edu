import React, { useState, useRef, useCallback } from "react";
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet, Platform,
  TextInput, ActivityIndicator, ScrollView,
} from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAvoidingView as KAVController } from "react-native-keyboard-controller";
import { LinearGradient } from "expo-linear-gradient";
import { useColors } from "@/hooks/useColors";
import { useApp } from "@/context/AppContext";
import * as Haptics from "expo-haptics";

interface Message {
  id: string; role: "user" | "assistant"; content: string; timestamp: Date;
}

type Mode = "general" | "activities" | "leadership" | "planning" | "evaluation";

const MODES: { id: Mode; label: string; icon: string; color: string; desc: string; emoji: string }[] = [
  { id: "general", label: "عام", icon: "message-circle", color: "#1B8A5A", desc: "أسئلة عامة في التربية غير المنهجية", emoji: "🌱" },
  { id: "activities", label: "أنشطة", icon: "star", color: "#9B59B6", desc: "تصميم أنشطة تربوية كاملة مع الأدوات والخطوات", emoji: "🎯" },
  { id: "leadership", label: "قيادة", icon: "award", color: "#E67E22", desc: "مهارات القيادة وبناء الشخصية", emoji: "🏆" },
  { id: "planning", label: "تخطيط", icon: "calendar", color: "#3498DB", desc: "تخطيط الفعاليات والبرامج التربوية", emoji: "📋" },
  { id: "evaluation", label: "تقييم", icon: "check-circle", color: "#E74C3C", desc: "تقييم الأنشطة وقياس الأثر", emoji: "📊" },
];

const MODE_QUESTIONS: Record<Mode, string[]> = {
  general: [
    "ما هي التربية غير المنهجية وما أهميتها للطلاب؟",
    "ما الفرق بين التعليم الرسمي وغير الرسمي؟",
    "كيف أبني برنامجاً تربوياً متكاملاً للمدرسة؟",
    "ما هي أبرز نظريات التعلم في التربية غير المنهجية؟",
  ],
  activities: [
    "اقترح لي فعالية جديدة لبناء الفريق خلال ساعة واحدة",
    "صمّم ورشة عمل إبداعية للطلاب في سن 14-16 سنة",
    "أعطني نشاطاً يناسب الأطفال من 8 إلى 12 سنة",
    "ما أفضل نشاط لتعزيز الثقة بالنفس؟",
  ],
  leadership: [
    "كيف أطور مهارات القيادة لدى طلاب المرحلة الثانوية؟",
    "اقترح تمريناً عملياً لتعزيز صنع القرار",
    "كيف أدرّب الطلاب على إدارة المجموعات بفاعلية؟",
    "ما هي صفات القائد الناجح في السياق التربوي؟",
  ],
  planning: [
    "كيف أخطط لفعالية تربوية ناجحة من الصفر؟",
    "ما هي الخطوات الأساسية لتنظيم ورشة عمل احترافية؟",
    "كيف أوزع المهام على أعضاء الفريق بفاعلية؟",
    "ما الجدول الزمني المثالي لبرنامج تربوي مدته يوم كامل؟",
  ],
  evaluation: [
    "كيف أقيّم نجاح فعالية تربوية بمعايير موضوعية؟",
    "ما أدوات التقييم المناسبة للأنشطة غير المنهجية؟",
    "كيف أقيس الأثر الحقيقي للبرامج على الطلاب؟",
    "ما الفرق بين التقييم التكويني والختامي في التربية؟",
  ],
};

const MODE_SYSTEM_PROMPTS: Record<Mode, string> = {
  general: "أنت مساعد ذكي متخصص في التربية غير المنهجية. أجب بشكل واضح وعملي باللغة العربية. رتّب إجابتك في نقاط أو فقرات منظمة.",
  activities: `أنت خبير متخصص في تصميم فعاليات وأنشطة التربية غير المنهجية. عند طلب فعالية أو نشاط، قدّم دائماً:
**اسم الفعالية**: [اسم مبدع ومعبّر]
**الهدف**: [ما نريد تحقيقه]
**الفئة المستهدفة**: [الأعمار المناسبة]
**المدة**: [الوقت المقترح]
**المواد والأدوات اللازمة**:
1. [أداة أولى]
2. [أداة ثانية]
**خطوات التنفيذ**:
1. [الخطوة الأولى]
2. [الخطوة الثانية]
3. [الخطوة الثالثة]
**طريقة التقديم**: [كيف يقدم المرشد الفعالية]
**التقييم والمتابعة**: [كيف نقيس النجاح]
قدّم فعالية جديدة ومختلفة في كل مرة. أجب باللغة العربية.`,
  leadership: "أنت مدرب قيادي متخصص في تنمية مهارات القيادة لدى الشباب. قدم نصائح عملية مع أمثلة وتمارين قابلة للتطبيق. رتّب إجابتك في نقاط منظمة. أجب باللغة العربية.",
  planning: "أنت منسق فعاليات تربوية محترف. ساعد في التخطيط التفصيلي مع خطوات عملية وجداول زمنية. رتّب إجابتك في خطوات مرقمة. أجب باللغة العربية.",
  evaluation: "أنت خبير تقييم في التربية غير المنهجية. قدم أدوات وأساليب قياس فعّالة ومعايير موضوعية. رتّب إجابتك في نقاط واضحة. أجب باللغة العربية.",
};

const MODE_WELCOME: Record<Mode, string> = {
  general: "مرحباً! أنا مساعدك الذكي المتخصص في التربية غير المنهجية 🌱\n\nيمكنني مساعدتك في:\n1. تصميم الأنشطة التربوية\n2. تطوير مهارات القيادة\n3. التخطيط للفعاليات\n4. معرفة مفاهيم التربية غير المنهجية\n\nاسألني أي سؤال وسأجيبك بوضوح وتفصيل!",
  activities: "أهلاً! أنا متخصص في تصميم الفعاليات والأنشطة التربوية 🎯\n\nاطلب مني:\n1. فعالية لأي فئة عمرية\n2. نشاط لموضوع محدد\n3. تصميم ورشة عمل متكاملة\n\n**كل مرة ستحصل على فعالية جديدة ومختلفة مع الأدوات والخطوات التفصيلية!**",
  leadership: "يسعدني مساعدتك في تطوير مهارات القيادة 🏆\n\nيمكنني تقديم:\n1. تمارين عملية لتنمية القيادة\n2. تقنيات صنع القرار\n3. استراتيجيات إدارة الفريق\n4. أساليب بناء الشخصية القيادية",
  planning: "جاهز لمساعدتك في التخطيط الاحترافي 📋\n\nنقاط القوة:\n1. تخطيط الفعاليات من الفكرة للتنفيذ\n2. توزيع المهام والجداول الزمنية\n3. إدارة الموارد والميزانية\n4. التعامل مع الطوارئ",
  evaluation: "سأساعدك في تقييم برامجك بدقة وموضوعية 📊\n\nأقدم لك:\n1. أدوات التقييم المناسبة\n2. معايير قياس الأثر\n3. الفرق بين أساليب التقييم\n4. تقارير الأداء والتغذية الراجعة",
};

const API_BASE = process.env.EXPO_PUBLIC_DOMAIN ? `https://${process.env.EXPO_PUBLIC_DOMAIN}` : "";

function FormattedText({ text, isUser, color }: { text: string; isUser: boolean; color: string }) {
  const colors = useColors();
  const textColor = isUser ? "#fff" : colors.text;
  const mutedColor = isUser ? "rgba(255,255,255,0.8)" : colors.mutedForeground;

  const lines = text.split("\n");

  return (
    <View>
      {lines.map((line, i) => {
        const trimmed = line.trim();
        if (!trimmed) {
          return <View key={i} style={{ height: 6 }} />;
        }

        // Numbered list item: "1. ...", "2. ..."
        const numberedMatch = trimmed.match(/^(\d+)\.\s+(.+)$/);
        if (numberedMatch) {
          const parts = parseBold(numberedMatch[2], textColor, color, isUser);
          return (
            <View key={i} style={{ flexDirection: "row", alignItems: "flex-start", gap: 8, marginBottom: 5 }}>
              <View style={{ minWidth: 22, height: 22, borderRadius: 7, backgroundColor: isUser ? "rgba(255,255,255,0.25)" : color + "25", alignItems: "center", justifyContent: "center", marginTop: 1 }}>
                <Text style={{ fontSize: 11, color: isUser ? "#fff" : color, fontFamily: "Inter_700Bold" }}>{numberedMatch[1]}</Text>
              </View>
              <Text style={{ flex: 1, fontSize: 13.5, lineHeight: 21, color: textColor, fontFamily: "Inter_400Regular" }}>{parts}</Text>
            </View>
          );
        }

        // Bullet list: "- ...", "• ..."
        const bulletMatch = trimmed.match(/^[-•]\s+(.+)$/);
        if (bulletMatch) {
          const parts = parseBold(bulletMatch[1], textColor, color, isUser);
          return (
            <View key={i} style={{ flexDirection: "row", alignItems: "flex-start", gap: 8, marginBottom: 4 }}>
              <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: isUser ? "rgba(255,255,255,0.7)" : color, marginTop: 7, flexShrink: 0 }} />
              <Text style={{ flex: 1, fontSize: 13.5, lineHeight: 21, color: textColor, fontFamily: "Inter_400Regular" }}>{parts}</Text>
            </View>
          );
        }

        // Bold header line: starts with **...**: or **...**
        if (trimmed.startsWith("**") && (trimmed.endsWith("**") || trimmed.includes("**:"))) {
          const cleanText = trimmed.replace(/\*\*/g, "").replace(/:$/, "");
          return (
            <View key={i} style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: i > 0 ? 10 : 0, marginBottom: 5 }}>
              <View style={{ width: 3, height: 18, borderRadius: 2, backgroundColor: isUser ? "rgba(255,255,255,0.7)" : color }} />
              <Text style={{ fontSize: 14, color: isUser ? "#fff" : color, fontFamily: "Inter_700Bold" }}>{cleanText}</Text>
            </View>
          );
        }

        // Regular text
        const parts = parseBold(trimmed, textColor, color, isUser);
        return (
          <Text key={i} style={{ fontSize: 13.5, lineHeight: 21, color: textColor, fontFamily: "Inter_400Regular", marginBottom: 3 }}>
            {parts}
          </Text>
        );
      })}
    </View>
  );
}

function parseBold(text: string, textColor: string, accent: string, isUser: boolean): React.ReactNode[] {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <Text key={i} style={{ fontFamily: "Inter_700Bold", color: isUser ? "#fff" : accent }}>{part.slice(2, -2)}</Text>;
    }
    return <Text key={i} style={{ fontFamily: "Inter_400Regular", color: textColor }}>{part}</Text>;
  });
}

export default function AIScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { appSettings } = useApp();
  const [messages, setMessages] = useState<Message[]>([
    { id: "welcome", role: "assistant", content: MODE_WELCOME["general"], timestamp: new Date() },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedMode, setSelectedMode] = useState<Mode>("general");
  const flatListRef = useRef<FlatList>(null);

  const topPad = insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const handleModeChange = (mode: Mode) => {
    setSelectedMode(mode);
    setMessages([{ id: Date.now().toString(), role: "assistant", content: MODE_WELCOME[mode], timestamp: new Date() }]);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const sendMessage = useCallback(async (text?: string) => {
    const messageText = text || input.trim();
    if (!messageText || loading) return;
    setInput("");

    const userMsg: Message = { id: Date.now().toString(), role: "user", content: messageText, timestamp: new Date() };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    const assistantId = `${Date.now() + 1}`;

    try {
      const history = messages.filter((m) => m.id !== "welcome").map((m) => ({ role: m.role, content: m.content }));
      const uniquenessHint = `[طلب رقم ${Date.now()}] قدّم فعالية/نشاطاً مختلفاً تماماً عن أي إجابات سابقة.`;

      const response = await fetch(`${API_BASE}/api/ai/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...history, { role: "user", content: selectedMode === "activities" ? `${messageText}\n\n${uniquenessHint}` : messageText }],
          systemPrompt: MODE_SYSTEM_PROMPTS[selectedMode],
        }),
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      setMessages((prev) => [...prev, { id: assistantId, role: "assistant", content: "", timestamp: new Date() }]);
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 80);

      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const raw = line.slice(6).trim();
          if (raw === "[DONE]") break;
          try {
            const { delta } = JSON.parse(raw);
            if (delta) {
              setMessages((prev) => prev.map((m) =>
                m.id === assistantId ? { ...m, content: m.content + delta } : m
              ));
              flatListRef.current?.scrollToEnd({ animated: false });
            }
          } catch {}
        }
      }

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e) {
      setMessages((prev) => {
        const withoutEmpty = prev.filter((m) => !(m.id === assistantId && m.content === ""));
        return [...withoutEmpty, {
          id: assistantId, role: "assistant",
          content: "عذراً، حدث خطأ في الاتصال. تأكد من الاتصال بالإنترنت وحاول مجدداً.",
          timestamp: new Date(),
        }];
      });
    }
    setLoading(false);
    setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 200);
  }, [input, loading, messages, selectedMode]);

  const currentMode = MODES.find((m) => m.id === selectedMode)!;
  const quickQuestions = MODE_QUESTIONS[selectedMode];

  return (
    <KAVController style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient colors={[currentMode.color + "20", currentMode.color + "05", colors.background]} style={[styles.header, { paddingTop: topPad + 16, borderBottomColor: colors.border }]}>
        <View style={styles.headerTop}>
          <LinearGradient colors={[currentMode.color, currentMode.color + "CC"]} style={styles.aiIconBg}>
            <MaterialCommunityIcons name="robot" size={22} color="#fff" />
          </LinearGradient>
          <View style={{ flex: 1 }}>
            <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{appSettings.aiPageTitle}</Text>
            <Text style={[styles.headerSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
              {currentMode.emoji} {currentMode.desc}
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => { setMessages([{ id: "welcome", role: "assistant", content: MODE_WELCOME[selectedMode], timestamp: new Date() }]); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); }}
            style={[styles.clearBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
          >
            <Feather name="refresh-cw" size={15} color={currentMode.color} />
          </TouchableOpacity>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingVertical: 10 }}>
          {MODES.map((item) => {
            const isActive = selectedMode === item.id;
            return (
              <TouchableOpacity key={item.id} onPress={() => handleModeChange(item.id)}
                style={[styles.modeChip, { backgroundColor: isActive ? item.color : colors.card, borderColor: isActive ? item.color : colors.border }]}
                activeOpacity={0.8}
              >
                <Text style={{ fontSize: 14 }}>{item.emoji}</Text>
                <Text style={[styles.modeText, { color: isActive ? "#fff" : colors.mutedForeground, fontFamily: isActive ? "Inter_700Bold" : "Inter_400Regular" }]}>{item.label}</Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </LinearGradient>

      <FlatList
        ref={flatListRef}
        data={messages}
        keyExtractor={(m) => m.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 8 }}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
        renderItem={({ item }) => {
          const isUser = item.role === "user";
          return (
            <View style={[styles.msgRow, isUser ? styles.msgRowUser : styles.msgRowBot]}>
              {!isUser && (
                <LinearGradient colors={[currentMode.color + "30", currentMode.color + "10"]} style={styles.botAvatar}>
                  <MaterialCommunityIcons name="robot" size={15} color={currentMode.color} />
                </LinearGradient>
              )}
              <View style={[
                styles.bubble,
                isUser
                  ? { backgroundColor: currentMode.color, borderBottomRightRadius: 4 }
                  : { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1, borderBottomLeftRadius: 4 }
              ]}>
                <FormattedText text={item.content} isUser={isUser} color={currentMode.color} />
                <Text style={[styles.bubbleTime, { color: isUser ? "rgba(255,255,255,0.6)" : colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                  {item.timestamp.toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" })}
                </Text>
              </View>
            </View>
          );
        }}
        ListFooterComponent={loading && messages[messages.length - 1]?.role === "user" ? (
          <View style={[styles.msgRow, styles.msgRowBot]}>
            <LinearGradient colors={[currentMode.color + "30", currentMode.color + "10"]} style={styles.botAvatar}>
              <MaterialCommunityIcons name="robot" size={15} color={currentMode.color} />
            </LinearGradient>
            <View style={[styles.bubble, { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1, flexDirection: "row", alignItems: "center", gap: 10 }]}>
              <ActivityIndicator size="small" color={currentMode.color} />
              <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>يكتب المساعد...</Text>
            </View>
          </View>
        ) : null}
      />

      {messages.length <= 1 && (
        <View style={{ paddingHorizontal: 16, paddingBottom: 8 }}>
          <Text style={[styles.quickTitle, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>💡 أسئلة مقترحة:</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {quickQuestions.map((q) => (
              <TouchableOpacity key={q} onPress={() => sendMessage(q)}
                style={[styles.quickChip, { backgroundColor: currentMode.color + "15", borderColor: currentMode.color + "30" }]}
                activeOpacity={0.8}
              >
                <Text style={[styles.quickChipText, { color: currentMode.color, fontFamily: "Inter_500Medium" }]} numberOfLines={2}>{q}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}

      <View style={[styles.inputArea, { backgroundColor: colors.card, borderTopColor: colors.border, paddingBottom: Platform.OS === "web" ? 20 : bottomPad + 84 }]}>
        <View style={[styles.inputRow, { backgroundColor: colors.background, borderColor: currentMode.color + "40" }]}>
          <TextInput
            value={input} onChangeText={setInput}
            placeholder={`اسأل في ${currentMode.label}...`}
            placeholderTextColor={colors.mutedForeground} multiline
            style={[styles.input, { color: colors.text, fontFamily: "Inter_400Regular" }]}
            onSubmitEditing={() => sendMessage()}
          />
          <TouchableOpacity onPress={() => sendMessage()} disabled={!input.trim() || loading}
            style={[styles.sendBtn, { backgroundColor: input.trim() ? currentMode.color : colors.secondary }]}
            activeOpacity={0.8}
          >
            <Feather name={loading ? "loader" : "send"} size={17} color={input.trim() ? "#fff" : colors.mutedForeground} />
          </TouchableOpacity>
        </View>
      </View>
    </KAVController>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 16, borderBottomWidth: 1 },
  headerTop: { flexDirection: "row", alignItems: "center", gap: 10, paddingBottom: 2 },
  aiIconBg: { width: 42, height: 42, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 17 },
  headerSub: { fontSize: 11, marginTop: 1 },
  clearBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  modeChip: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, borderWidth: 1 },
  modeText: { fontSize: 12 },
  msgRow: { flexDirection: "row", marginBottom: 12, gap: 8 },
  msgRowUser: { justifyContent: "flex-end" },
  msgRowBot: { justifyContent: "flex-start" },
  botAvatar: { width: 30, height: 30, borderRadius: 10, alignItems: "center", justifyContent: "center", marginTop: 4, flexShrink: 0 },
  bubble: { maxWidth: "82%", borderRadius: 18, padding: 14 },
  bubbleTime: { fontSize: 10, marginTop: 6, textAlign: "right" },
  quickTitle: { fontSize: 12, marginBottom: 8 },
  quickChip: { borderRadius: 14, padding: 10, borderWidth: 1, maxWidth: 210 },
  quickChipText: { fontSize: 12, lineHeight: 18 },
  inputArea: { borderTopWidth: 1, paddingHorizontal: 16, paddingTop: 10 },
  inputRow: { flexDirection: "row", alignItems: "flex-end", gap: 10, borderRadius: 18, borderWidth: 2, paddingHorizontal: 14, paddingVertical: 8 },
  input: { flex: 1, fontSize: 14, maxHeight: 100 },
  sendBtn: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center" },
});

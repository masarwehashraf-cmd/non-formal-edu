import React, { useState } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Platform, Alert, Image,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/context/AuthContext";
import { useApp, ROLE_LABELS, ROLE_PERMISSIONS, normalizePermissions } from "@/context/AppContext";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";

const ROLE_COLORS: Record<string, string> = {
  guest: "#95A5A6", student: "#3498DB", teacher: "#9B59B6",
  supervisor: "#E67E22", admin: "#E74C3C",
};

export default function AccountScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user, allUsers, logout, updateProfilePicture } = useAuth();
  const { events, activities, appSettings, customRoles } = useApp();
  const [pickingPhoto, setPickingPhoto] = useState(false);

  const topPad = insets.top;
  const bottomPad = Platform.OS === "web" ? 84 + 16 : 90 + insets.bottom;

  const role = user?.role ?? "guest";
  const roleColor = ROLE_COLORS[role] || "#9B59B6";
  const permissions = normalizePermissions(ROLE_PERMISSIONS[role] || ROLE_PERMISSIONS.student);
  const roleLabel = ROLE_LABELS[role] || customRoles.find(r => r.id === role)?.name || role;

  const handleLogout = () => {
    if (Platform.OS === "web") {
      const confirmed = window.confirm("هل تريد تسجيل الخروج من التطبيق؟");
      if (confirmed) { logout(); router.replace("/login" as any); }
      return;
    }
    Alert.alert("تسجيل الخروج", "هل تريد تسجيل الخروج من التطبيق؟", [
      { text: "إلغاء", style: "cancel" },
      { text: "خروج", style: "destructive", onPress: async () => {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        await logout();
      }},
    ]);
  };

  const handlePickPicture = async () => {
    if (pickingPhoto) return;
    setPickingPhoto(true);
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.7,
        base64: true,
      });
      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        const uri = asset.base64
          ? `data:image/jpeg;base64,${asset.base64}`
          : asset.uri;
        await updateProfilePicture(uri);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch {
    }
    setPickingPhoto(false);
  };

  if (!user) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, justifyContent: "center", alignItems: "center" }]}>
        <Text style={{ color: colors.text, fontFamily: "Inter_500Medium", fontSize: 16 }}>الرجاء تسجيل الدخول أولاً</Text>
      </View>
    );
  }

  const profilePic = user.profilePicture;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: topPad + 16, paddingBottom: bottomPad }}>
        <LinearGradient colors={[roleColor + "30", roleColor + "08", colors.background]} style={{ paddingHorizontal: 20, paddingBottom: 30 }}>
          <View style={{ alignItems: "center", paddingTop: 16 }}>
            <TouchableOpacity onPress={handlePickPicture} activeOpacity={0.85} style={{ marginBottom: 14, position: "relative" }}>
              <View style={{ width: 90, height: 90, borderRadius: 26, backgroundColor: roleColor + "25", alignItems: "center", justifyContent: "center", borderWidth: 3, borderColor: roleColor + "50", overflow: "hidden" }}>
                {profilePic ? (
                  <Image source={{ uri: profilePic }} style={{ width: 90, height: 90 }} resizeMode="cover" />
                ) : (
                  <Text style={{ fontSize: 42 }}>
                    {role === "admin" ? "👑" : role === "supervisor" ? "🎓" : role === "teacher" ? "📚" : "🙋"}
                  </Text>
                )}
              </View>
              <View style={{ position: "absolute", bottom: 0, right: -2, width: 28, height: 28, borderRadius: 8, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: colors.background }}>
                <Feather name="camera" size={12} color="#fff" />
              </View>
            </TouchableOpacity>
            <Text style={{ fontSize: 22, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 4 }}>{user.fullName}</Text>
            <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginBottom: 10 }}>@{user.username}</Text>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: roleColor + "20", paddingHorizontal: 16, paddingVertical: 7, borderRadius: 20, borderWidth: 1.5, borderColor: roleColor + "40" }}>
              <Feather name="shield" size={13} color={roleColor} />
              <Text style={{ fontSize: 13, color: roleColor, fontFamily: "Inter_700Bold" }}>{roleLabel}</Text>
            </View>
          </View>
        </LinearGradient>

        <View style={{ flexDirection: "row", gap: 10, paddingHorizontal: 20, marginTop: -16, marginBottom: 24 }}>
          {[
            { value: events.length.toString(), label: "فعالية", icon: "calendar", color: "#3498DB" },
            { value: activities.length.toString(), label: "نشاط", icon: "star", color: "#9B59B6" },
            { value: allUsers.length.toString(), label: "عضو", icon: "users", color: "#E67E22" },
          ].map(({ value, label, icon, color }) => (
            <View key={label} style={{ flex: 1, backgroundColor: colors.card, borderRadius: 16, padding: 12, alignItems: "center", gap: 4, borderWidth: 1, borderColor: color + "30", shadowColor: "#000", shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.08, shadowRadius: 8, elevation: 4 }}>
              <Feather name={icon as any} size={18} color={color} />
              <Text style={{ fontSize: 20, color, fontFamily: "Inter_700Bold" }}>{value}</Text>
              <Text style={{ fontSize: 10, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>{label}</Text>
            </View>
          ))}
        </View>

        <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 12 }}>معلومات الحساب</Text>
          <View style={{ backgroundColor: colors.card, borderRadius: 18, borderWidth: 1, borderColor: colors.border, overflow: "hidden" }}>
            {[
              { icon: "user", label: "الاسم الكامل", value: user.fullName },
              { icon: "at-sign", label: "اسم المستخدم", value: user.username },
              { icon: "mail", label: "البريد الإلكتروني", value: user.email || "لم يُضف" },
              { icon: "calendar", label: "تاريخ التسجيل", value: new Date(user.createdAt).toLocaleDateString("ar") },
            ].map(({ icon, label, value }, index, arr) => (
              <View key={label} style={[{ flexDirection: "row", alignItems: "center", gap: 12, padding: 14 }, index < arr.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}>
                <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.primary + "15", alignItems: "center", justifyContent: "center" }}>
                  <Feather name={icon as any} size={15} color={colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>{label}</Text>
                  <Text style={{ fontSize: 14, color: colors.text, fontFamily: "Inter_600SemiBold", marginTop: 2 }}>{value}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 12 }}>صلاحياتك</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {[
              { key: "canAddEvents", label: "إضافة فعاليات" },
              { key: "canDeleteEvents", label: "حذف فعاليات" },
              { key: "canAddActivities", label: "إضافة أنشطة" },
              { key: "canViewTotalMembers", label: "عرض الأعضاء" },
              { key: "canManageUsers", label: "إدارة المستخدمين" },
              { key: "canAddAnnouncements", label: "إضافة إعلانات" },
              { key: "canExportData", label: "تصدير البيانات" },
              { key: "canViewAdminPanel", label: "لوحة الإدارة" },
              { key: "canAccessAI", label: "المساعد الذكي" },
            ].map(({ key, label }) => {
              const has = (permissions as any)[key];
              return (
                <View key={key} style={{ flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: has ? "#27AE6015" : colors.secondary, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: has ? "#27AE6040" : colors.border }}>
                  <Feather name={has ? "check-circle" : "x-circle"} size={12} color={has ? "#27AE60" : colors.mutedForeground} />
                  <Text style={{ fontSize: 11, color: has ? "#27AE60" : colors.mutedForeground, fontFamily: "Inter_500Medium" }}>{label}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <View style={{ paddingHorizontal: 20, gap: 10, marginBottom: 20 }}>
          <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 4 }}>الإجراءات</Text>
          {permissions.canViewAdminPanel && (
            <ActionButton icon="shield" label="لوحة الإدارة" color="#E74C3C" onPress={() => router.push("/(tabs)/admin")} />
          )}
          {(permissions.canExportData || permissions.canViewAdminPanel) && (
            <ActionButton icon="download" label="تصدير البيانات" color="#16A085" onPress={() => router.push("/export" as any)} />
          )}
          <ActionButton icon="calendar" label="عرض الفعاليات" color="#3498DB" onPress={() => router.push("/(tabs)/events")} />
          <ActionButton icon="book-open" label="المواضيع التعليمية" color="#E67E22" onPress={() => router.push("/(tabs)/topics")} />
          <ActionButton icon="heart" label="ضد العنف" color="#E74C3C" onPress={() => router.push("/(tabs)/antivio")} />
          <ActionButton icon="cpu" label="المساعد الذكي" color={colors.primary} onPress={() => router.push("/(tabs)/ai")} />
          <ActionButton icon="log-out" label="تسجيل الخروج" color="#E74C3C" onPress={handleLogout} destructive />
        </View>

        <View style={{ alignItems: "center", paddingTop: 8, paddingBottom: 12 }}>
          <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>مشروع التخرج</Text>
          <Text style={{ fontSize: 16, color: colors.text, fontFamily: "Inter_700Bold", marginTop: 4 }}>{appSettings.footerName}</Text>
          <Text style={{ fontSize: 13, color: colors.mutedForeground, fontFamily: "Inter_500Medium", marginTop: 2 }}>{appSettings.footerSupervisor}</Text>
        </View>
      </ScrollView>
    </View>
  );
}

function ActionButton({ icon, label, color, onPress, destructive }: { icon: string; label: string; color: string; onPress: () => void; destructive?: boolean }) {
  const colors = useColors();
  return (
    <TouchableOpacity onPress={onPress}
      style={{ flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: destructive ? color + "10" : colors.card, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: destructive ? color + "30" : colors.border }}
      activeOpacity={0.8}>
      <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: color + "20", alignItems: "center", justifyContent: "center" }}>
        <Feather name={icon as any} size={18} color={color} />
      </View>
      <Text style={{ flex: 1, fontSize: 14, color: destructive ? color : colors.text, fontFamily: "Inter_600SemiBold" }}>{label}</Text>
      <Feather name="chevron-left" size={16} color={colors.mutedForeground} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
});

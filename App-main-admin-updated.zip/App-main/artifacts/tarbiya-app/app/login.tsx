import React, { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  Platform, ScrollView, ActivityIndicator, Alert, KeyboardAvoidingView,
} from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/context/AuthContext";
import * as Haptics from "expo-haptics";

export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const handleLogin = async () => {
    if (!username.trim() || !password.trim()) {
      setError("يرجى ملء جميع الحقول");
      return;
    }
    setLoading(true);
    setError("");
    const result = await login(username.trim(), password);
    setLoading(false);
    if (result.success) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace("/(tabs)");
    } else {
      setError(result.error || "خطأ في تسجيل الدخول");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  };

  return (
    <KeyboardAvoidingView style={[styles.container, { backgroundColor: colors.background }]} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView
        contentContainerStyle={{ paddingTop: topPad + 20, paddingBottom: bottomPad + 40, paddingHorizontal: 28 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Logo Section */}
        <View style={styles.logoSection}>
          <View style={[styles.logoCircle, { backgroundColor: colors.primary + "20" }]}>
            <MaterialCommunityIcons name="school" size={56} color={colors.primary} />
          </View>
          <Text style={[styles.appName, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
            التربية غير المنهجية
          </Text>
          <Text style={[styles.appTagline, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            منصة التعلم والتطوير خارج المنهج
          </Text>
        </View>

        {/* Card */}
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>تسجيل الدخول</Text>
          <Text style={[styles.cardSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            أدخل بياناتك للوصول إلى التطبيق
          </Text>

          {error ? (
            <View style={[styles.errorBox, { backgroundColor: colors.destructive + "15", borderColor: colors.destructive + "40" }]}>
              <Feather name="alert-circle" size={14} color={colors.destructive} />
              <Text style={[styles.errorText, { color: colors.destructive, fontFamily: "Inter_500Medium" }]}>{error}</Text>
            </View>
          ) : null}

          {/* Username */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>اسم المستخدم</Text>
            <View style={[styles.inputWrapper, { borderColor: colors.border, backgroundColor: colors.background }]}>
              <Feather name="user" size={18} color={colors.mutedForeground} style={styles.inputIcon} />
              <TextInput
                value={username}
                onChangeText={setUsername}
                placeholder="ادخل اسم المستخدم"
                placeholderTextColor={colors.mutedForeground}
                autoCapitalize="none"
                autoCorrect={false}
                style={[styles.input, { color: colors.text, fontFamily: "Inter_400Regular" }]}
              />
            </View>
          </View>

          {/* Password */}
          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>كلمة المرور</Text>
            <View style={[styles.inputWrapper, { borderColor: colors.border, backgroundColor: colors.background }]}>
              <Feather name="lock" size={18} color={colors.mutedForeground} style={styles.inputIcon} />
              <TextInput
                value={password}
                onChangeText={setPassword}
                placeholder="ادخل كلمة المرور"
                placeholderTextColor={colors.mutedForeground}
                secureTextEntry={!showPass}
                autoCapitalize="none"
                style={[styles.input, { color: colors.text, fontFamily: "Inter_400Regular" }]}
              />
              <TouchableOpacity onPress={() => setShowPass((v) => !v)} style={styles.eyeBtn}>
                <Feather name={showPass ? "eye-off" : "eye"} size={18} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Login Button */}
          <TouchableOpacity
            style={[styles.loginBtn, { backgroundColor: colors.primary }, loading && { opacity: 0.7 }]}
            onPress={handleLogin}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <>
                <Feather name="log-in" size={18} color="#fff" />
                <Text style={[styles.loginBtnText, { fontFamily: "Inter_700Bold" }]}>دخول</Text>
              </>
            )}
          </TouchableOpacity>
        </View>

        {/* Register Link */}
        <View style={styles.registerRow}>
          <Text style={[styles.registerPrompt, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            ليس لديك حساب؟
          </Text>
          <TouchableOpacity onPress={() => router.push("/register")} activeOpacity={0.8}>
            <Text style={[styles.registerLink, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>
              إنشاء حساب جديد
            </Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={[styles.footerProject, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>مشروع التخرج</Text>
          <Text style={[styles.footerName, { color: colors.text, fontFamily: "Inter_700Bold" }]}>دعاء مقاري</Text>
          <Text style={[styles.footerSupervisor, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>أشرف مصاروة</Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  logoSection: { alignItems: "center", marginBottom: 36 },
  logoCircle: { width: 100, height: 100, borderRadius: 28, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  appName: { fontSize: 26, textAlign: "center", marginBottom: 8 },
  appTagline: { fontSize: 14, textAlign: "center", lineHeight: 20 },
  card: { borderRadius: 24, padding: 24, borderWidth: 1, marginBottom: 24, shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08, shadowRadius: 16, elevation: 6 },
  cardTitle: { fontSize: 22, marginBottom: 6 },
  cardSub: { fontSize: 13, marginBottom: 20 },
  errorBox: { flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 12, padding: 12, marginBottom: 16, borderWidth: 1 },
  errorText: { fontSize: 13, flex: 1 },
  fieldGroup: { marginBottom: 16 },
  fieldLabel: { fontSize: 13, marginBottom: 8 },
  inputWrapper: { flexDirection: "row", alignItems: "center", borderWidth: 1.5, borderRadius: 14, paddingHorizontal: 14, height: 52 },
  inputIcon: { marginRight: 10 },
  input: { flex: 1, fontSize: 15 },
  eyeBtn: { padding: 4 },
  loginBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, borderRadius: 16, paddingVertical: 16, marginTop: 8 },
  loginBtnText: { color: "#fff", fontSize: 17 },
  registerRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginBottom: 20 },
  registerPrompt: { fontSize: 14 },
  registerLink: { fontSize: 14 },
  footer: { alignItems: "center", paddingTop: 8 },
  footerProject: { fontSize: 12, marginBottom: 4 },
  footerName: { fontSize: 17, marginBottom: 4 },
  footerSupervisor: { fontSize: 13 },
});

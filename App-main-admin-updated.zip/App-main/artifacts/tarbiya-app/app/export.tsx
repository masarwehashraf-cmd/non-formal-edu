import React, { useState } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Platform, Alert,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { useColors } from "@/hooks/useColors";
import { useApp, ROLE_LABELS } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

type ExportTab = "users" | "events" | "activities";

function downloadCSV(content: string, filename: string) {
  if (Platform.OS === "web") {
    try {
      const BOM = "\uFEFF";
      const blob = new Blob([BOM + content], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename + ".csv";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      Alert.alert("تم", "البيانات جاهزة للتصدير");
    }
  } else {
    Alert.alert("تصدير البيانات", "التصدير متاح عبر المتصفح. افتح التطبيق على الويب للتنزيل.");
  }
}

export default function ExportScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { events, activities } = useApp();
  const { allUsers, exportUsersData } = useAuth();
  const [activeTab, setActiveTab] = useState<ExportTab>("users");

  const topPad = insets.top;

  const TABS: { id: ExportTab; label: string; icon: string; color: string; count: number }[] = [
    { id: "users", label: "الأعضاء", icon: "users", color: "#3498DB", count: allUsers.length },
    { id: "events", label: "الفعاليات", icon: "calendar", color: "#E67E22", count: events.length },
    { id: "activities", label: "الأنشطة", icon: "star", color: "#9B59B6", count: activities.length },
  ];

  const handleExport = async () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    if (activeTab === "users") {
      const usersWithPasswords = await exportUsersData();
      const header = "الاسم الكامل,اسم المستخدم,البريد الإلكتروني,كلمة المرور,الدور,تاريخ التسجيل,الحالة";
      const rows = usersWithPasswords.map(u =>
        `"${u.fullName}","${u.username}","${u.email || "—"}","${u.password}","${ROLE_LABELS[u.role] || u.role}","${new Date(u.createdAt).toLocaleDateString("ar")}","${u.isActive ? "نشط" : "موقوف"}"`
      );
      downloadCSV([header, ...rows].join("\n"), "الأعضاء_المسجلون");
    } else if (activeTab === "events") {
      const header = "العنوان,الفئة,التاريخ,الوقت,المكان,الفئة المستهدفة,العمر,المدة,الطاقة,المنظم,التواصل";
      const rows = events.map(e =>
        `"${e.title}","${e.category}","${e.date}","${e.time}","${e.location}","${e.targetAudience}","${e.ageRange}","${e.duration}","${e.capacity}","${e.organizer}","${e.contact}"`
      );
      downloadCSV([header, ...rows].join("\n"), "الفعاليات");
    } else {
      const header = "العنوان,الموضوع,الفئة العمرية,المدة,المهارات,المواد,التقييم";
      const rows = activities.map(a =>
        `"${a.title}","${a.topic}","${a.targetAge}","${a.duration}","${(a.skills || []).join(" - ")}","${a.materials}","${a.evaluation}"`
      );
      downloadCSV([header, ...rows].join("\n"), "الأنشطة");
    }
  };

  const renderUsersTable = () => (
    <ScrollView horizontal showsHorizontalScrollIndicator>
      <View>
        <View style={[styles.tableRow, styles.tableHeader, { backgroundColor: "#3498DB20" }]}>
          {["الاسم", "المستخدم", "الدور", "الحالة", "التسجيل"].map(h => (
            <Text key={h} style={[styles.tableCell, styles.headerCell, { color: "#3498DB", fontFamily: "Inter_700Bold" }]}>{h}</Text>
          ))}
        </View>
        {allUsers.map((u, i) => (
          <View key={u.id} style={[styles.tableRow, { backgroundColor: i % 2 === 0 ? colors.card : colors.background, borderBottomColor: colors.border, borderBottomWidth: 1 }]}>
            <Text style={[styles.tableCell, { color: colors.text, fontFamily: "Inter_600SemiBold", minWidth: 130 }]}>{u.fullName}</Text>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>@{u.username}</Text>
            <View style={[styles.tableCell, { alignItems: "center" }]}>
              <View style={{ backgroundColor: "#3498DB20", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 }}>
                <Text style={{ fontSize: 11, color: "#3498DB", fontFamily: "Inter_600SemiBold" }}>{ROLE_LABELS[u.role] || u.role}</Text>
              </View>
            </View>
            <View style={[styles.tableCell, { alignItems: "center" }]}>
              <View style={{ backgroundColor: (u.isActive ? "#27AE60" : "#E74C3C") + "20", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 }}>
                <Text style={{ fontSize: 11, color: u.isActive ? "#27AE60" : "#E74C3C", fontFamily: "Inter_600SemiBold" }}>{u.isActive ? "نشط" : "موقوف"}</Text>
              </View>
            </View>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{new Date(u.createdAt).toLocaleDateString("ar")}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );

  const renderEventsTable = () => (
    <ScrollView horizontal showsHorizontalScrollIndicator>
      <View>
        <View style={[styles.tableRow, styles.tableHeader, { backgroundColor: "#E67E2220" }]}>
          {["العنوان", "الفئة", "التاريخ", "المكان", "الفئة العمرية", "المدة", "المنظم"].map(h => (
            <Text key={h} style={[styles.tableCell, styles.headerCell, { color: "#E67E22", fontFamily: "Inter_700Bold" }]}>{h}</Text>
          ))}
        </View>
        {events.map((e, i) => (
          <View key={e.id} style={[styles.tableRow, { backgroundColor: i % 2 === 0 ? colors.card : colors.background, borderBottomColor: colors.border, borderBottomWidth: 1 }]}>
            <Text style={[styles.tableCell, { color: colors.text, fontFamily: "Inter_600SemiBold", minWidth: 160 }]} numberOfLines={2}>{e.title}</Text>
            <View style={[styles.tableCell]}>
              <View style={{ backgroundColor: "#E67E2220", paddingHorizontal: 7, paddingVertical: 3, borderRadius: 8 }}>
                <Text style={{ fontSize: 10, color: "#E67E22", fontFamily: "Inter_600SemiBold" }}>{e.category}</Text>
              </View>
            </View>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{e.date}</Text>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]} numberOfLines={1}>{e.location}</Text>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{e.ageRange}</Text>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{e.duration}</Text>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]} numberOfLines={1}>{e.organizer}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );

  const renderActivitiesTable = () => (
    <ScrollView horizontal showsHorizontalScrollIndicator>
      <View>
        <View style={[styles.tableRow, styles.tableHeader, { backgroundColor: "#9B59B620" }]}>
          {["العنوان", "الموضوع", "الفئة العمرية", "المدة", "المهارات"].map(h => (
            <Text key={h} style={[styles.tableCell, styles.headerCell, { color: "#9B59B6", fontFamily: "Inter_700Bold" }]}>{h}</Text>
          ))}
        </View>
        {activities.map((a, i) => (
          <View key={a.id} style={[styles.tableRow, { backgroundColor: i % 2 === 0 ? colors.card : colors.background, borderBottomColor: colors.border, borderBottomWidth: 1 }]}>
            <Text style={[styles.tableCell, { color: colors.text, fontFamily: "Inter_600SemiBold", minWidth: 160 }]} numberOfLines={2}>{a.title}</Text>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{a.topic}</Text>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{a.targetAge}</Text>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{a.duration}</Text>
            <Text style={[styles.tableCell, { color: colors.mutedForeground, fontFamily: "Inter_400Regular", maxWidth: 180 }]} numberOfLines={2}>{(a.skills || []).join(" · ")}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );

  const activeTabData = TABS.find(t => t.id === activeTab)!;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient colors={[activeTabData.color + "20", activeTabData.color + "08", colors.background]} style={[styles.header, { paddingTop: topPad + 16, borderBottomColor: colors.border }]}>
        <View style={styles.headerRow}>
          <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="arrow-right" size={20} color={colors.text} />
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>تصدير البيانات</Text>
            <Text style={[styles.headerSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
              {activeTabData.count} سجل · قابل للتنزيل كـ Excel/CSV
            </Text>
          </View>
          <TouchableOpacity onPress={handleExport}
            style={[styles.downloadBtn, { backgroundColor: activeTabData.color }]} activeOpacity={0.85}>
            <Feather name="download" size={17} color="#fff" />
            <Text style={{ color: "#fff", fontSize: 12, fontFamily: "Inter_700Bold" }}>تنزيل</Text>
          </TouchableOpacity>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
          {TABS.map(tab => {
            const isActive = activeTab === tab.id;
            return (
              <TouchableOpacity key={tab.id} onPress={() => { setActiveTab(tab.id); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
                style={[styles.tabChip, { backgroundColor: isActive ? tab.color : colors.card, borderColor: isActive ? tab.color : colors.border }]}
                activeOpacity={0.8}>
                <Feather name={tab.icon as any} size={13} color={isActive ? "#fff" : colors.mutedForeground} />
                <Text style={[styles.tabText, { color: isActive ? "#fff" : colors.mutedForeground, fontFamily: isActive ? "Inter_700Bold" : "Inter_400Regular" }]}>
                  {tab.label} ({tab.count})
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </LinearGradient>

      <View style={[styles.infoBar, { backgroundColor: activeTabData.color + "12", borderColor: activeTabData.color + "25" }]}>
        <Feather name="info" size={13} color={activeTabData.color} />
        <Text style={[styles.infoText, { color: activeTabData.color, fontFamily: "Inter_400Regular" }]}>
          {Platform.OS === "web"
            ? "اضغط \"تنزيل\" لتحميل الملف مباشرة — يفتح في Excel تلقائياً"
            : "افتح التطبيق على المتصفح (الويب) لتنزيل الملفات"}
        </Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
        <View style={{ margin: 16, borderRadius: 16, overflow: "hidden", borderWidth: 1, borderColor: colors.border }}>
          {activeTab === "users" && renderUsersTable()}
          {activeTab === "events" && renderEventsTable()}
          {activeTab === "activities" && renderActivitiesTable()}
        </View>
      </ScrollView>
    </View>
  );
}

const CELL_W = 120;
const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 16, paddingBottom: 14, borderBottomWidth: 1 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 14 },
  backBtn: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  headerTitle: { fontSize: 18 },
  headerSub: { fontSize: 11, marginTop: 2 },
  downloadBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 14 },
  tabChip: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  tabText: { fontSize: 12 },
  infoBar: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 1 },
  infoText: { flex: 1, fontSize: 11, lineHeight: 16 },
  tableRow: { flexDirection: "row", alignItems: "center" },
  tableHeader: { paddingVertical: 12 },
  tableCell: { minWidth: CELL_W, paddingHorizontal: 12, paddingVertical: 10, fontSize: 12 },
  headerCell: { fontSize: 12 },
});

import React, { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  Platform, ScrollView, ActivityIndicator, KeyboardAvoidingView,
} from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useColors } from "@/hooks/useColors";
import { useAuth } from "@/context/AuthContext";
import * as Haptics from "expo-haptics";

export default function RegisterScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { register } = useAuth();
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const handleRegister = async () => {
    if (!fullName.trim() || !username.trim() || !password.trim()) {
      setError("يرجى ملء الحقول المطلوبة");
      return;
    }
    if (password !== confirmPassword) {
      setError("كلمتا المرور غير متطابقتين");
      return;
    }
    if (password.length < 6) {
      setError("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      return;
    }
    setLoading(true);
    setError("");
    const result = await register({ username: username.trim(), password, fullName: fullName.trim(), email: email.trim() });
    setLoading(false);
    if (result.success) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace("/(tabs)");
    } else {
      setError(result.error || "فشل إنشاء الحساب");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  };

  const fields = [
    { label: "الاسم الكامل *", value: fullName, set: setFullName, ph: "ادخل اسمك الكامل", icon: "user", auto: "words" as const },
    { label: "اسم المستخدم *", value: username, set: setUsername, ph: "اختر اسم مستخدم", icon: "at-sign", auto: "none" as const },
    { label: "البريد الإلكتروني", value: email, set: setEmail, ph: "example@email.com", icon: "mail", auto: "none" as const },
  ];

  return (
    <KeyboardAvoidingView style={[styles.container, { backgroundColor: colors.background }]} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView
        contentContainerStyle={{ paddingTop: topPad + 10, paddingBottom: bottomPad + 40, paddingHorizontal: 28 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header */}
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-right" size={22} color={colors.text} />
        </TouchableOpacity>
        <View style={styles.headerSection}>
          <View style={[styles.iconCircle, { backgroundColor: colors.primary + "20" }]}>
            <MaterialCommunityIcons name="account-plus" size={44} color={colors.primary} />
          </View>
          <Text style={[styles.title, { color: colors.text, fontFamily: "Inter_700Bold" }]}>إنشاء حساب جديد</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            انضم لمجتمع التربية غير المنهجية
          </Text>
        </View>

        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {error ? (
            <View style={[styles.errorBox, { backgroundColor: colors.destructive + "15", borderColor: colors.destructive + "40" }]}>
              <Feather name="alert-circle" size={14} color={colors.destructive} />
              <Text style={[styles.errorText, { color: colors.destructive, fontFamily: "Inter_500Medium" }]}>{error}</Text>
            </View>
          ) : null}

          {fields.map(({ label, value, set, ph, icon, auto }) => (
            <View key={label} style={styles.fieldGroup}>
              <Text style={[styles.fieldLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{label}</Text>
              <View style={[styles.inputWrapper, { borderColor: colors.border, backgroundColor: colors.background }]}>
                <Feather name={icon as any} size={17} color={colors.mutedForeground} style={styles.inputIcon} />
                <TextInput value={value} onChangeText={set} placeholder={ph} placeholderTextColor={colors.mutedForeground} autoCapitalize={auto} autoCorrect={false}
                  style={[styles.input, { color: colors.text, fontFamily: "Inter_400Regular" }]} />
              </View>
            </View>
          ))}

          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>كلمة المرور *</Text>
            <View style={[styles.inputWrapper, { borderColor: colors.border, backgroundColor: colors.background }]}>
              <Feather name="lock" size={17} color={colors.mutedForeground} style={styles.inputIcon} />
              <TextInput value={password} onChangeText={setPassword} placeholder="6 أحرف على الأقل" placeholderTextColor={colors.mutedForeground}
                secureTextEntry={!showPass} autoCapitalize="none"
                style={[styles.input, { color: colors.text, fontFamily: "Inter_400Regular" }]} />
              <TouchableOpacity onPress={() => setShowPass((v) => !v)} style={styles.eyeBtn}>
                <Feather name={showPass ? "eye-off" : "eye"} size={17} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>تأكيد كلمة المرور *</Text>
            <View style={[styles.inputWrapper, { borderColor: colors.border, backgroundColor: colors.background }]}>
              <Feather name="lock" size={17} color={colors.mutedForeground} style={styles.inputIcon} />
              <TextInput value={confirmPassword} onChangeText={setConfirmPassword} placeholder="أعد كتابة كلمة المرور" placeholderTextColor={colors.mutedForeground}
                secureTextEntry={!showPass} autoCapitalize="none"
                style={[styles.input, { color: colors.text, fontFamily: "Inter_400Regular" }]} />
            </View>
          </View>

          <TouchableOpacity
            style={[styles.registerBtn, { backgroundColor: colors.primary }, loading && { opacity: 0.7 }]}
            onPress={handleRegister}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading ? <ActivityIndicator color="#fff" size="small" /> : (
              <>
                <MaterialCommunityIcons name="account-plus" size={18} color="#fff" />
                <Text style={[styles.registerBtnText, { fontFamily: "Inter_700Bold" }]}>إنشاء الحساب</Text>
              </>
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.loginRow}>
          <Text style={[styles.loginPrompt, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>لديك حساب بالفعل؟</Text>
          <TouchableOpacity onPress={() => router.back()} activeOpacity={0.8}>
            <Text style={[styles.loginLink, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>تسجيل الدخول</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  backBtn: { marginBottom: 16, padding: 4, alignSelf: "flex-start" },
  headerSection: { alignItems: "center", marginBottom: 28 },
  iconCircle: { width: 84, height: 84, borderRadius: 24, alignItems: "center", justifyContent: "center", marginBottom: 14 },
  title: { fontSize: 24, textAlign: "center", marginBottom: 6 },
  subtitle: { fontSize: 13, textAlign: "center" },
  card: { borderRadius: 24, padding: 24, borderWidth: 1, marginBottom: 20, shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08, shadowRadius: 16, elevation: 6 },
  roleBadge: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 12, padding: 12, marginBottom: 20, borderWidth: 1 },
  roleBadgeText: { flex: 1, fontSize: 12, lineHeight: 18 },
  errorBox: { flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 12, padding: 12, marginBottom: 16, borderWidth: 1 },
  errorText: { fontSize: 13, flex: 1 },
  fieldGroup: { marginBottom: 16 },
  fieldLabel: { fontSize: 13, marginBottom: 8 },
  inputWrapper: { flexDirection: "row", alignItems: "center", borderWidth: 1.5, borderRadius: 14, paddingHorizontal: 14, height: 52 },
  inputIcon: { marginRight: 10 },
  input: { flex: 1, fontSize: 15 },
  eyeBtn: { padding: 4 },
  registerBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, borderRadius: 16, paddingVertical: 16, marginTop: 8 },
  registerBtnText: { color: "#fff", fontSize: 17 },
  loginRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  loginPrompt: { fontSize: 14 },
  loginLink: { fontSize: 14 },
});

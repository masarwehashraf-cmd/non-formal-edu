const { execSync } = require("child_process");
const path = require("path");
const fs = require("fs");

const projectRoot = path.resolve(__dirname, "..");

function getDeploymentDomain() {
  const domain =
    process.env.REPLIT_INTERNAL_APP_DOMAIN ||
    process.env.REPLIT_DEV_DOMAIN ||
    process.env.EXPO_PUBLIC_DOMAIN;

  if (!domain) {
    console.error("ERROR: No deployment domain found.");
    process.exit(1);
  }

  let urlString = domain.trim();
  if (!/^https?:\/\//i.test(urlString)) urlString = `https://${urlString}`;
  return new URL(urlString).host;
}

console.log("Building Expo web app for production...");

const domain = getDeploymentDomain();
console.log(`Domain: ${domain}`);

const distDir = path.join(projectRoot, "dist");
if (fs.existsSync(distDir)) {
  fs.rmSync(distDir, { recursive: true });
  console.log("Cleaned previous dist/");
}

try {
  execSync("pnpm exec expo export --platform web --output-dir dist", {
    stdio: "inherit",
    cwd: projectRoot,
    env: {
      ...process.env,
      EXPO_PUBLIC_DOMAIN: domain,
      NODE_ENV: "production",
    },
  });
  console.log("Web export complete → dist/");
} catch (err) {
  console.error("Build failed:", err.message);
  process.exit(1);
}

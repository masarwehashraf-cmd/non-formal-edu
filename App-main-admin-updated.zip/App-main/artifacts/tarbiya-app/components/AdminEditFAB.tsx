import React, { useState } from "react";
import {
  View, Text, TouchableOpacity, Modal, ScrollView, TextInput,
  StyleSheet, Platform, KeyboardAvoidingView, Alert,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useApp, AppSettings } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";

type FieldDef = { key: keyof AppSettings; label: string; multiline?: boolean };
type Section = { title: string; icon: keyof typeof Feather.glyphMap; color: string; fields: FieldDef[] };

const SECTIONS: Section[] = [
  {
    title: "معلومات التطبيق",
    icon: "info",
    color: "#1B8A5A",
    fields: [
      { key: "appName", label: "اسم التطبيق" },
      { key: "subtitle", label: "وصف التطبيق" },
      { key: "footerName", label: "اسم صاحب المشروع" },
      { key: "footerSupervisor", label: "اسم المشرف" },
    ],
  },
  {
    title: "صفحة تسجيل الدخول",
    icon: "log-in",
    color: "#2980B9",
    fields: [
      { key: "loginTitle", label: "عنوان الصفحة" },
      { key: "loginSubtitle", label: "وصف الصفحة" },
    ],
  },
  {
    title: "الصفحة الرئيسية",
    icon: "home",
    color: "#3498DB",
    fields: [
      { key: "homeWelcomeTitle", label: "العنوان الرئيسي" },
      { key: "homeWelcomeSubtitle", label: "الوصف" },
    ],
  },
  {
    title: "صفحة الفعاليات",
    icon: "calendar",
    color: "#E67E22",
    fields: [
      { key: "eventsPageTitle", label: "عنوان الصفحة" },
      { key: "eventsPageSubtitle", label: "وصف الصفحة" },
    ],
  },
  {
    title: "صفحة الأنشطة",
    icon: "star",
    color: "#9B59B6",
    fields: [
      { key: "activitiesPageTitle", label: "عنوان الصفحة" },
      { key: "activitiesPageSubtitle", label: "وصف الصفحة" },
    ],
  },
  {
    title: "صفحة ضد العنف",
    icon: "shield",
    color: "#E74C3C",
    fields: [
      { key: "antivioPageTitle", label: "عنوان الصفحة" },
      { key: "antivioPageDesc", label: "الوصف", multiline: true },
    ],
  },
  {
    title: "صفحة المواضيع",
    icon: "book-open",
    color: "#27AE60",
    fields: [
      { key: "topicsPageTitle", label: "عنوان الصفحة" },
      { key: "topicsPageSubtitle", label: "وصف الصفحة" },
    ],
  },
  {
    title: "المساعد الذكي",
    icon: "cpu",
    color: "#8E44AD",
    fields: [
      { key: "aiPageTitle", label: "عنوان الصفحة" },
    ],
  },
];

export default function AdminEditFAB() {
  const { user } = useAuth();
  const { appSettings, bulkUpdateAppSettings } = useApp();
  const colors = useColors();
  const [visible, setVisible] = useState(false);
  const [drafts, setDrafts] = useState<Partial<AppSettings>>({});
  const [saving, setSaving] = useState(false);

  const role = user?.role ?? "guest";
  if (role !== "admin") return null;

  const openEditor = () => {
    setDrafts({ ...appSettings });
    setVisible(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await bulkUpdateAppSettings(drafts);
      setVisible(false);
    } catch {
      if (Platform.OS === "web") {
        window.alert("حدث خطأ أثناء الحفظ. حاول مجدداً.");
      } else {
        Alert.alert("خطأ", "حدث خطأ أثناء الحفظ. حاول مجدداً.");
      }
    }
    setSaving(false);
  };

  const handleDiscard = () => {
    setDrafts({});
    setVisible(false);
  };

  return (
    <>
      <TouchableOpacity
        style={[styles.fab, { backgroundColor: "#1B8A5A" }]}
        onPress={openEditor}
        activeOpacity={0.85}
      >
        <Feather name="edit-2" size={20} color="#fff" />
      </TouchableOpacity>

      <Modal
        visible={visible}
        animationType="slide"
        presentationStyle="fullScreen"
        onRequestClose={handleDiscard}
      >
        <KeyboardAvoidingView
          style={[styles.modal, { backgroundColor: colors.background }]}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <View style={[styles.modalHeader, { backgroundColor: colors.card, borderBottomColor: colors.border }]}>
            <TouchableOpacity onPress={handleDiscard} style={styles.headerBtn}>
              <Feather name="x" size={20} color={colors.mutedForeground} />
            </TouchableOpacity>
            <View style={{ alignItems: "center" }}>
              <Text style={[styles.modalTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                ✏️ محرر محتوى التطبيق
              </Text>
              <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>
                مرئي لمدير النظام فقط
              </Text>
            </View>
            <TouchableOpacity
              onPress={handleSave}
              style={[styles.headerBtn, styles.saveBtn, { backgroundColor: "#1B8A5A" }]}
              disabled={saving}
            >
              <Feather name="check" size={18} color="#fff" />
              <Text style={{ color: "#fff", fontSize: 12, fontFamily: "Inter_700Bold" }}>
                {saving ? "..." : "حفظ"}
              </Text>
            </TouchableOpacity>
          </View>

          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={{ padding: 16, paddingBottom: 60 }}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {SECTIONS.map((section) => (
              <View key={section.title} style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={[styles.sectionHeader, { borderBottomColor: colors.border }]}>
                  <View style={[styles.sectionIcon, { backgroundColor: section.color + "20" }]}>
                    <Feather name={section.icon} size={15} color={section.color} />
                  </View>
                  <Text style={[styles.sectionTitle, { color: section.color, fontFamily: "Inter_700Bold" }]}>
                    {section.title}
                  </Text>
                </View>

                {section.fields.map((field, i) => (
                  <View
                    key={field.key}
                    style={[
                      styles.fieldRow,
                      i < section.fields.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border },
                    ]}
                  >
                    <Text style={[styles.fieldLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
                      {field.label}
                    </Text>
                    <TextInput
                      value={drafts[field.key] ?? appSettings[field.key]}
                      onChangeText={(v) => setDrafts((d) => ({ ...d, [field.key]: v }))}
                      style={[
                        styles.fieldInput,
                        {
                          color: colors.text,
                          backgroundColor: colors.background,
                          borderColor: colors.border,
                          fontFamily: "Inter_400Regular",
                          minHeight: field.multiline ? 72 : 42,
                        },
                      ]}
                      multiline={field.multiline}
                      textAlignVertical={field.multiline ? "top" : "center"}
                      placeholderTextColor={colors.mutedForeground}
                    />
                  </View>
                ))}
              </View>
            ))}
          </ScrollView>
        </KeyboardAvoidingView>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  fab: {
    position: "absolute",
    bottom: Platform.OS === "web" ? 100 : 96,
    right: 16,
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 8,
    zIndex: 999,
  },
  modal: { flex: 1 },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 14,
    paddingTop: Platform.OS === "ios" ? 54 : 14,
    borderBottomWidth: 1,
  },
  modalTitle: { fontSize: 16 },
  headerBtn: {
    padding: 8,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    minWidth: 44,
  },
  saveBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  section: {
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 16,
    overflow: "hidden",
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 14,
    borderBottomWidth: 1,
  },
  sectionIcon: {
    width: 30,
    height: 30,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  sectionTitle: { fontSize: 14 },
  fieldRow: {
    padding: 12,
  },
  fieldLabel: {
    fontSize: 11,
    marginBottom: 6,
    textAlign: "right",
  },
  fieldInput: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 14,
    textAlign: "right",
  },
});

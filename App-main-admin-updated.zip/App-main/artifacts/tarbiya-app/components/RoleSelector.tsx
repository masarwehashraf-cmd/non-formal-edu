// Role selection is now handled exclusively by the Admin panel.
// This component is kept as a placeholder stub to avoid import errors.
export default function RoleSelector(_props: { visible: boolean; onClose: () => void }) {
  return null;
}

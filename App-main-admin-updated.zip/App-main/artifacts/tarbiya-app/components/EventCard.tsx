import React, { useState } from "react";
import {
  View, Text, TouchableOpacity, StyleSheet, Alert, LayoutAnimation,
  Platform, UIManager, Modal, ScrollView,
} from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { Event } from "@/context/AppContext";

if (Platform.OS === "android" && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const CATEGORY_COLORS: Record<string, string> = {
  "ورشة عمل": "#9B59B6", "فعالية بيئية": "#27AE60", "مسابقة": "#E67E22",
  "رحلة": "#3498DB", "نشاط ترفيهي": "#E91E63", "تطوعي": "#1ABC9C",
  "ندوة": "#2C3E50", "مبادرة": "#F39C12",
};

interface Props { event: Event; canDelete: boolean; onDelete: (id: string) => void; }

function EventDetailModal({ event, onClose, catColor }: { event: Event; onClose: () => void; catColor: string }) {
  const colors = useColors();
  const sections = [
    { icon: "calendar", label: "التاريخ والوقت", value: `${event.date} · الساعة ${event.time}` },
    { icon: "map-pin", label: "الموقع", value: event.location },
    { icon: "navigation", label: "العنوان التفصيلي", value: event.address },
    { icon: "clock", label: "المدة", value: event.duration },
    { icon: "users", label: "الفئة المستهدفة", value: `${event.targetAudience} · ${event.ageRange}` },
    { icon: "user-check", label: "الطاقة الاستيعابية", value: event.capacity },
    { icon: "user", label: "المنظّم", value: event.organizer },
    { icon: "mail", label: "التواصل", value: event.contact },
  ];
  return (
    <Modal visible animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)" }}>
        <View style={{ flex: 1, marginTop: 60, backgroundColor: colors.background, borderTopLeftRadius: 28, borderTopRightRadius: 28 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border }}>
            <View style={{ flex: 1, marginRight: 12 }}>
              <View style={[{ backgroundColor: catColor + "20", alignSelf: "flex-start", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, marginBottom: 6 }]}>
                <Text style={[{ color: catColor, fontFamily: "Inter_600SemiBold", fontSize: 11 }]}>{event.category}</Text>
              </View>
              <Text style={[{ fontSize: 18, color: colors.text, fontFamily: "Inter_700Bold" }]}>{event.title}</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.secondary, alignItems: "center", justifyContent: "center" }}>
              <Feather name="x" size={20} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
            <Text style={[{ fontSize: 14, color: colors.mutedForeground, fontFamily: "Inter_400Regular", lineHeight: 22, marginBottom: 20 }]}>{event.description}</Text>
            <View style={[{ flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 24 }]}>
              {sections.map(({ icon, label, value }) => (
                value ? (
                  <View key={label} style={[{ backgroundColor: colors.card, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: colors.border, width: "47%" }]}>
                    <View style={[{ flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 4 }]}>
                      <Feather name={icon as any} size={13} color={catColor} />
                      <Text style={[{ fontSize: 10, color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>{label}</Text>
                    </View>
                    <Text style={[{ fontSize: 12, color: colors.text, fontFamily: "Inter_600SemiBold", lineHeight: 17 }]}>{value}</Text>
                  </View>
                ) : null
              ))}
            </View>
            {event.objectives && <Section title="الأهداف" content={event.objectives} color={catColor} icon="target" />}
            {event.presentationMethod && <Section title="طريقة تقديم الفعالية" content={event.presentationMethod} color={catColor} icon="layout" />}
            {event.steps && <Section title="خطوات التنفيذ" content={event.steps} color={catColor} icon="list" />}
            {event.expectedOutcomes && <Section title="النتائج المتوقعة" content={event.expectedOutcomes} color={catColor} icon="award" />}
            {event.materials && <Section title="المواد والأدوات اللازمة" content={event.materials} color={catColor} icon="package" />}
            {event.prerequisites && <Section title="المتطلبات المسبقة" content={event.prerequisites} color={catColor} icon="alert-circle" />}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

function Section({ title, content, color, icon }: { title: string; content: string; color: string; icon: string }) {
  const colors = useColors();
  return (
    <View style={{ marginBottom: 18 }}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 }}>
        <View style={{ width: 32, height: 32, borderRadius: 10, backgroundColor: color + "20", alignItems: "center", justifyContent: "center" }}>
          <Feather name={icon as any} size={15} color={color} />
        </View>
        <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold" }}>{title}</Text>
      </View>
      <View style={{ backgroundColor: colors.card, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.border }}>
        <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_400Regular", lineHeight: 22 }}>{content}</Text>
      </View>
    </View>
  );
}

export default function EventCard({ event, canDelete, onDelete }: Props) {
  const colors = useColors();
  const [showDetail, setShowDetail] = useState(false);
  const catColor = CATEGORY_COLORS[event.category] || "#1B8A5A";

  const handleDelete = () => {
    Alert.alert("حذف الفعالية", `هل تريد حذف "${event.title}"؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => onDelete(event.id) },
    ]);
  };

  return (
    <>
      <TouchableOpacity style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => setShowDetail(true)} activeOpacity={0.85}>
        <View style={[styles.catStripe, { backgroundColor: catColor }]} />
        <View style={styles.content}>
          <View style={styles.topRow}>
            <View style={[styles.catBadge, { backgroundColor: catColor + "20" }]}>
              <Text style={[styles.catText, { color: catColor, fontFamily: "Inter_600SemiBold" }]}>{event.category}</Text>
            </View>
            {canDelete && (
              <TouchableOpacity onPress={handleDelete} hitSlop={{ top: 10, right: 10, bottom: 10, left: 10 }}>
                <Feather name="trash-2" size={15} color={colors.destructive} />
              </TouchableOpacity>
            )}
          </View>
          <Text style={[styles.title, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{event.title}</Text>
          <Text style={[styles.desc, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]} numberOfLines={2}>{event.description}</Text>
          <View style={styles.metaRow}>
            <MetaItem icon="calendar" text={event.date} color={catColor} />
            <MetaItem icon="clock" text={event.time} color={catColor} />
            <MetaItem icon="map-pin" text={event.location} color={catColor} />
          </View>
          <View style={styles.metaRow}>
            <MetaItem icon="users" text={event.targetAudience} color={catColor} />
            <MetaItem icon="activity" text={event.duration} color={catColor} />
          </View>
          <View style={[styles.readMoreRow, { borderTopColor: colors.border }]}>
            <Text style={[styles.readMore, { color: catColor, fontFamily: "Inter_600SemiBold" }]}>عرض الشرح الكامل وطريقة التقديم</Text>
            <Feather name="arrow-left" size={13} color={catColor} />
          </View>
        </View>
      </TouchableOpacity>
      {showDetail && <EventDetailModal event={event} onClose={() => setShowDetail(false)} catColor={catColor} />}
    </>
  );
}

function MetaItem({ icon, text, color }: { icon: any; text: string; color: string }) {
  const colors = useColors();
  if (!text) return null;
  return (
    <View style={styles.metaItem}>
      <Feather name={icon} size={11} color={color} />
      <Text style={[styles.metaText, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: "row", borderRadius: 16, borderWidth: 1, marginBottom: 12, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 3 },
  catStripe: { width: 4 },
  content: { flex: 1, padding: 14 },
  topRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  catBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  catText: { fontSize: 11 },
  title: { fontSize: 15, marginBottom: 6 },
  desc: { fontSize: 13, lineHeight: 20, marginBottom: 10 },
  metaRow: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 6 },
  metaItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  metaText: { fontSize: 11 },
  readMoreRow: { flexDirection: "row", alignItems: "center", justifyContent: "flex-end", gap: 4, paddingTop: 10, marginTop: 8, borderTopWidth: 1 },
  readMore: { fontSize: 12 },
});

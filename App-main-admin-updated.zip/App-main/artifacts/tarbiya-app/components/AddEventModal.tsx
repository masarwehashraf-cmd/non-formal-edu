import React, { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, Platform,
  ScrollView, Modal, Alert,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useApp } from "@/context/AppContext";

const CATEGORIES = ["ورشة عمل", "فعالية بيئية", "مسابقة", "رحلة", "تطوعي", "ندوة", "مبادرة", "نشاط ترفيهي"];

interface Props { visible: boolean; onClose: () => void; }

function Field({ label, value, onChange, placeholder, multiline = false, hint }: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string; multiline?: boolean; hint?: string;
}) {
  const colors = useColors();
  return (
    <View style={{ marginBottom: 16 }}>
      <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_600SemiBold", marginBottom: 6 }}>{label}</Text>
      {hint && <Text style={{ fontSize: 11, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginBottom: 6 }}>{hint}</Text>}
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={placeholder ?? `أدخل ${label}`}
        placeholderTextColor={colors.mutedForeground}
        multiline={multiline}
        numberOfLines={multiline ? 4 : 1}
        style={{
          borderWidth: 1.5, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 14,
          paddingVertical: multiline ? 12 : 0, height: multiline ? 100 : 48, color: colors.text,
          fontFamily: "Inter_400Regular", fontSize: 14, backgroundColor: colors.background,
          textAlignVertical: multiline ? "top" : "center",
        }}
      />
    </View>
  );
}

export default function AddEventModal({ visible, onClose }: Props) {
  const colors = useColors();
  const { addEvent } = useApp();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [location, setLocation] = useState("");
  const [address, setAddress] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [targetAudience, setTargetAudience] = useState("");
  const [ageRange, setAgeRange] = useState("");
  const [duration, setDuration] = useState("");
  const [capacity, setCapacity] = useState("");
  const [materials, setMaterials] = useState("");
  const [objectives, setObjectives] = useState("");
  const [presentationMethod, setPresentationMethod] = useState("");
  const [steps, setSteps] = useState("");
  const [expectedOutcomes, setExpectedOutcomes] = useState("");
  const [prerequisites, setPrerequisites] = useState("");
  const [organizer, setOrganizer] = useState("");
  const [contact, setContact] = useState("");

  const [step, setStep] = useState<1 | 2 | 3>(1);

  const handleSave = async () => {
    if (!title.trim() || !description.trim() || !date.trim() || !location.trim()) {
      Alert.alert("تنبيه", "يرجى ملء الحقول الأساسية: العنوان، الوصف، التاريخ، الموقع");
      return;
    }
    await addEvent({ title, description, date, time, location, address, category, targetAudience, ageRange, duration, capacity, materials, objectives, presentationMethod, steps, expectedOutcomes, prerequisites, organizer, contact });
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)" }}>
        <View style={{ flex: 1, marginTop: 50, backgroundColor: colors.background, borderTopLeftRadius: 28, borderTopRightRadius: 28 }}>
          {/* Header */}
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border }}>
            <View>
              <Text style={{ fontSize: 18, color: colors.text, fontFamily: "Inter_700Bold" }}>إضافة فعالية جديدة</Text>
              <Text style={{ fontSize: 12, color: colors.mutedForeground, fontFamily: "Inter_400Regular", marginTop: 2 }}>
                الخطوة {step} من 3
              </Text>
            </View>
            <TouchableOpacity onPress={onClose} style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.secondary, alignItems: "center", justifyContent: "center" }}>
              <Feather name="x" size={20} color={colors.text} />
            </TouchableOpacity>
          </View>

          {/* Progress */}
          <View style={{ flexDirection: "row", padding: 20, paddingBottom: 0, gap: 6 }}>
            {[1, 2, 3].map((s) => (
              <View key={s} style={{ flex: 1, height: 4, borderRadius: 2, backgroundColor: s <= step ? colors.primary : colors.secondary }} />
            ))}
          </View>
          <View style={{ flexDirection: "row", paddingHorizontal: 20, paddingVertical: 10, gap: 6 }}>
            {["المعلومات الأساسية", "التنفيذ والشرح", "الجهة المنظِّمة"].map((label, i) => (
              <Text key={i} style={{ flex: 1, fontSize: 10, textAlign: "center", color: i + 1 <= step ? colors.primary : colors.mutedForeground, fontFamily: i + 1 <= step ? "Inter_600SemiBold" : "Inter_400Regular" }}>
                {label}
              </Text>
            ))}
          </View>

          <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
            {step === 1 && (
              <>
                <Field label="عنوان الفعالية *" value={title} onChange={setTitle} placeholder="مثال: ورشة القيادة والتواصل" />
                <Field label="وصف الفعالية *" value={description} onChange={setDescription} placeholder="اشرح الفعالية بالتفصيل..." multiline />
                <View style={{ flexDirection: "row", gap: 10 }}>
                  <View style={{ flex: 1 }}><Field label="التاريخ *" value={date} onChange={setDate} placeholder="2026-05-15" /></View>
                  <View style={{ flex: 1 }}><Field label="الوقت" value={time} onChange={setTime} placeholder="09:00" /></View>
                </View>
                <Field label="الموقع / القاعة *" value={location} onChange={setLocation} placeholder="مثال: مركز الشباب الثقافي" />
                <Field label="العنوان التفصيلي" value={address} onChange={setAddress} placeholder="الشارع، المبنى، الطابق..." />
                <View>
                  <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_600SemiBold", marginBottom: 8 }}>التصنيف</Text>
                  <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 16 }}>
                    {CATEGORIES.map((c) => (
                      <TouchableOpacity key={c} onPress={() => setCategory(c)} style={{ paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, borderWidth: 1.5, borderColor: category === c ? colors.primary : colors.border, backgroundColor: category === c ? colors.primary + "20" : colors.background }}>
                        <Text style={{ fontSize: 13, color: category === c ? colors.primary : colors.mutedForeground, fontFamily: category === c ? "Inter_600SemiBold" : "Inter_400Regular" }}>{c}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
                <View style={{ flexDirection: "row", gap: 10 }}>
                  <View style={{ flex: 1 }}><Field label="الفئة المستهدفة" value={targetAudience} onChange={setTargetAudience} placeholder="طلاب ثانوي" /></View>
                  <View style={{ flex: 1 }}><Field label="الفئة العمرية" value={ageRange} onChange={setAgeRange} placeholder="15-18 سنة" /></View>
                </View>
                <View style={{ flexDirection: "row", gap: 10 }}>
                  <View style={{ flex: 1 }}><Field label="المدة" value={duration} onChange={setDuration} placeholder="3 ساعات" /></View>
                  <View style={{ flex: 1 }}><Field label="الطاقة الاستيعابية" value={capacity} onChange={setCapacity} placeholder="30 مشارك" /></View>
                </View>
              </>
            )}
            {step === 2 && (
              <>
                <Field label="الأهداف" value={objectives} onChange={setObjectives} placeholder="ما الذي تريد تحقيقه من هذه الفعالية؟" multiline hint="اذكر الأهداف التعليمية والتنموية" />
                <Field label="طريقة تقديم الفعالية" value={presentationMethod} onChange={setPresentationMethod} placeholder="اشرح كيفية إدارة وتقديم الفعالية للمشاركين..." multiline hint="مثال: ابدأ بكسر الجليد، ثم اعمل بمجموعات..." />
                <Field label="خطوات التنفيذ" value={steps} onChange={setSteps} placeholder="1. الخطوة الأولى\n2. الخطوة الثانية\n..." multiline hint="اذكر الخطوات التفصيلية للتنفيذ" />
                <Field label="النتائج المتوقعة" value={expectedOutcomes} onChange={setExpectedOutcomes} placeholder="ماذا سيكتسب المشاركون من هذه الفعالية؟" multiline />
                <Field label="المواد والأدوات اللازمة" value={materials} onChange={setMaterials} placeholder="أوراق عمل، أقلام، لوح عرض..." multiline />
                <Field label="المتطلبات المسبقة" value={prerequisites} onChange={setPrerequisites} placeholder="ما الذي يجب أن يعرفه المشاركون مسبقاً؟" />
              </>
            )}
            {step === 3 && (
              <>
                <Field label="اسم المنظّم / الجهة" value={organizer} onChange={setOrganizer} placeholder="قسم التربية غير المنهجية" />
                <Field label="معلومات التواصل" value={contact} onChange={setContact} placeholder="البريد الإلكتروني أو رقم الهاتف" />
              </>
            )}
          </ScrollView>

          {/* Navigation Buttons */}
          <View style={{ flexDirection: "row", gap: 12, padding: 20, paddingBottom: Platform.OS === "web" ? 20 : 32, borderTopWidth: 1, borderTopColor: colors.border }}>
            {step > 1 && (
              <TouchableOpacity
                onPress={() => setStep((s) => (s === 3 ? 2 : 1) as 1 | 2)}
                style={{ flex: 1, borderRadius: 14, paddingVertical: 14, borderWidth: 1.5, borderColor: colors.border, alignItems: "center" }}
              >
                <Text style={{ color: colors.text, fontSize: 15, fontFamily: "Inter_600SemiBold" }}>السابق</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity
              onPress={() => {
                if (step < 3) setStep((s) => (s + 1) as 2 | 3);
                else handleSave();
              }}
              style={{ flex: 1, borderRadius: 14, paddingVertical: 14, backgroundColor: colors.primary, alignItems: "center" }}
              activeOpacity={0.85}
            >
              <Text style={{ color: "#fff", fontSize: 15, fontFamily: "Inter_700Bold" }}>
                {step === 3 ? "حفظ الفعالية" : "التالي"}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

import React, { useState } from "react";
import {
  View, Text, TouchableOpacity, StyleSheet, Alert, Platform, UIManager,
  Modal, ScrollView,
} from "react-native";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { Activity } from "@/context/AppContext";

if (Platform.OS === "android" && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const TOPIC_COLORS: Record<string, string> = {
  "التفكير الإبداعي": "#9B59B6",
  "القيادة والإدارة": "#E67E22",
  "بناء الفريق": "#3498DB",
  "التواصل": "#27AE60",
  "المواطنة": "#E91E63",
  "الصحة النفسية": "#1ABC9C",
  "البيئة": "#2ECC71",
  "الفنون": "#E74C3C",
  "المهارات الحياتية": "#F39C12",
  "الريادة": "#D35400",
};

const TOPIC_ICONS: Record<string, string> = {
  "التفكير الإبداعي": "zap",
  "القيادة والإدارة": "award",
  "بناء الفريق": "users",
  "التواصل": "message-circle",
  "المواطنة": "heart",
  "الصحة النفسية": "smile",
  "البيئة": "globe",
  "الفنون": "feather",
  "المهارات الحياتية": "star",
  "الريادة": "briefcase",
};

interface Props {
  activity: Activity;
  canDelete: boolean;
  onDelete: (id: string) => void;
}

function ActivityDetailModal({ activity, onClose, topicColor }: { activity: Activity; onClose: () => void; topicColor: string }) {
  const colors = useColors();
  const icon = TOPIC_ICONS[activity.topic] || "star";
  const steps = activity.steps?.split("\n").filter((s) => s.trim()) ?? [];
  return (
    <Modal visible animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.55)" }}>
        <View style={{ flex: 1, marginTop: 56, backgroundColor: colors.background, borderTopLeftRadius: 28, borderTopRightRadius: 28 }}>
          {/* Header */}
          <View style={[{ flexDirection: "row", alignItems: "center", gap: 12, padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border }]}>
            <View style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: topicColor + "25", alignItems: "center", justifyContent: "center" }}>
              <Feather name={icon as any} size={22} color={topicColor} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 17, color: colors.text, fontFamily: "Inter_700Bold", lineHeight: 22 }}>{activity.title}</Text>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 }}>
                <View style={{ backgroundColor: topicColor + "25", paddingHorizontal: 10, paddingVertical: 3, borderRadius: 20 }}>
                  <Text style={{ fontSize: 11, color: topicColor, fontFamily: "Inter_600SemiBold" }}>{activity.topic}</Text>
                </View>
              </View>
            </View>
            <TouchableOpacity onPress={onClose} style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.secondary, alignItems: "center", justifyContent: "center" }}>
              <Feather name="x" size={20} color={colors.text} />
            </TouchableOpacity>
          </View>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 20, paddingBottom: 48 }}>
            {/* Quick Info */}
            <View style={{ flexDirection: "row", gap: 10, marginBottom: 20 }}>
              {[
                { icon: "clock", label: "المدة", value: activity.duration },
                { icon: "users", label: "الفئة العمرية", value: activity.targetAge },
              ].map(({ icon: ic, label, value }) => (
                <View key={label} style={{ flex: 1, backgroundColor: topicColor + "15", borderRadius: 14, padding: 12, alignItems: "center", gap: 4 }}>
                  <Feather name={ic as any} size={18} color={topicColor} />
                  <Text style={{ fontSize: 10, color: topicColor, fontFamily: "Inter_500Medium" }}>{label}</Text>
                  <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_700Bold", textAlign: "center" }}>{value}</Text>
                </View>
              ))}
            </View>
            {/* Description */}
            <View style={{ marginBottom: 20 }}>
              <SectionHeader icon="info" title="وصف النشاط" color={topicColor} />
              <View style={[{ backgroundColor: colors.card, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.border }]}>
                <Text style={{ fontSize: 14, color: colors.text, fontFamily: "Inter_400Regular", lineHeight: 22 }}>{activity.description}</Text>
              </View>
            </View>
            {/* Materials */}
            {activity.materials && (
              <View style={{ marginBottom: 20 }}>
                <SectionHeader icon="package" title="المواد والأدوات اللازمة" color={topicColor} />
                <View style={{ backgroundColor: colors.card, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: colors.border }}>
                  {activity.materials.split("،").map((m, i) => (
                    <View key={i} style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: i < activity.materials.split("،").length - 1 ? 8 : 0 }}>
                      <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: topicColor }} />
                      <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_400Regular" }}>{m.trim()}</Text>
                    </View>
                  ))}
                </View>
              </View>
            )}
            {/* Steps */}
            {steps.length > 0 && (
              <View style={{ marginBottom: 20 }}>
                <SectionHeader icon="list" title="خطوات التنفيذ" color={topicColor} />
                <View style={{ gap: 8 }}>
                  {steps.map((step, i) => (
                    <View key={i} style={{ flexDirection: "row", alignItems: "flex-start", gap: 10, backgroundColor: colors.card, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: colors.border }}>
                      <View style={{ width: 26, height: 26, borderRadius: 8, backgroundColor: topicColor, alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                        <Text style={{ fontSize: 12, color: "#fff", fontFamily: "Inter_700Bold" }}>{i + 1}</Text>
                      </View>
                      <Text style={{ flex: 1, fontSize: 13, color: colors.text, fontFamily: "Inter_400Regular", lineHeight: 20, paddingTop: 3 }}>{step.replace(/^\d+\.\s*/, "")}</Text>
                    </View>
                  ))}
                </View>
              </View>
            )}
            {/* Skills */}
            {activity.skills?.length > 0 && (
              <View style={{ marginBottom: 20 }}>
                <SectionHeader icon="star" title="المهارات المكتسبة" color={topicColor} />
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                  {activity.skills.map((s, i) => (
                    <View key={i} style={{ backgroundColor: topicColor + "20", paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, flexDirection: "row", alignItems: "center", gap: 5 }}>
                      <Feather name="check" size={11} color={topicColor} />
                      <Text style={{ fontSize: 12, color: topicColor, fontFamily: "Inter_600SemiBold" }}>{s}</Text>
                    </View>
                  ))}
                </View>
              </View>
            )}
            {/* Evaluation */}
            {activity.evaluation && (
              <View>
                <SectionHeader icon="bar-chart-2" title="معايير التقييم" color={topicColor} />
                <View style={{ backgroundColor: topicColor + "15", borderRadius: 14, padding: 14, borderWidth: 1, borderColor: topicColor + "30" }}>
                  <Text style={{ fontSize: 13, color: colors.text, fontFamily: "Inter_400Regular", lineHeight: 20 }}>{activity.evaluation}</Text>
                </View>
              </View>
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

function SectionHeader({ icon, title, color }: { icon: string; title: string; color: string }) {
  const colors = useColors();
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 }}>
      <View style={{ width: 32, height: 32, borderRadius: 10, backgroundColor: color + "20", alignItems: "center", justifyContent: "center" }}>
        <Feather name={icon as any} size={15} color={color} />
      </View>
      <Text style={{ fontSize: 15, color: colors.text, fontFamily: "Inter_700Bold" }}>{title}</Text>
    </View>
  );
}

export default function ActivityCard({ activity, canDelete, onDelete }: Props) {
  const colors = useColors();
  const [showDetail, setShowDetail] = useState(false);
  const topicColor = TOPIC_COLORS[activity.topic] || "#1B8A5A";
  const icon = TOPIC_ICONS[activity.topic] || "star";

  const handleDelete = () => {
    Alert.alert("حذف النشاط", `هل تريد حذف "${activity.title}"؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => onDelete(activity.id) },
    ]);
  };

  return (
    <>
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {/* Gradient Header */}
        <View style={[styles.cardHeader, { backgroundColor: topicColor + "18" }]}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 10, flex: 1 }}>
            <View style={[styles.iconBg, { backgroundColor: topicColor + "30" }]}>
              <Feather name={icon as any} size={20} color={topicColor} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.title, { color: colors.text, fontFamily: "Inter_700Bold" }]} numberOfLines={2}>{activity.title}</Text>
              <View style={[styles.topicBadge, { backgroundColor: topicColor + "25" }]}>
                <Text style={[styles.topicText, { color: topicColor, fontFamily: "Inter_600SemiBold" }]}>{activity.topic}</Text>
              </View>
            </View>
          </View>
          {canDelete && (
            <TouchableOpacity onPress={handleDelete} style={[styles.deleteBtn, { backgroundColor: colors.destructive + "15" }]} hitSlop={{ top: 8, right: 8, bottom: 8, left: 8 }}>
              <Feather name="trash-2" size={14} color={colors.destructive} />
            </TouchableOpacity>
          )}
        </View>

        {/* Body */}
        <View style={styles.body}>
          <Text style={[styles.desc, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]} numberOfLines={3}>{activity.description}</Text>

          {/* Meta */}
          <View style={styles.metaRow}>
            <MetaChip icon="clock" text={activity.duration} color={topicColor} />
            <MetaChip icon="users" text={activity.targetAge} color={topicColor} />
            {activity.materials && <MetaChip icon="package" text="أدوات متاحة" color={topicColor} />}
          </View>

          {/* Skills Preview */}
          {activity.skills?.length > 0 && (
            <View style={styles.skillsRow}>
              {activity.skills.slice(0, 3).map((s, i) => (
                <View key={i} style={[styles.skillChip, { backgroundColor: topicColor + "15" }]}>
                  <Text style={[styles.skillText, { color: topicColor, fontFamily: "Inter_500Medium" }]}>{s}</Text>
                </View>
              ))}
              {activity.skills.length > 3 && (
                <View style={[styles.skillChip, { backgroundColor: topicColor + "15" }]}>
                  <Text style={[styles.skillText, { color: topicColor, fontFamily: "Inter_500Medium" }]}>+{activity.skills.length - 3}</Text>
                </View>
              )}
            </View>
          )}

          {/* View Button */}
          <TouchableOpacity
            onPress={() => setShowDetail(true)}
            style={[styles.detailBtn, { backgroundColor: topicColor }]}
            activeOpacity={0.85}
          >
            <MaterialCommunityIcons name="book-open-page-variant" size={15} color="#fff" />
            <Text style={[styles.detailBtnText, { fontFamily: "Inter_700Bold" }]}>عرض الشرح الكامل وطريقة التنفيذ</Text>
          </TouchableOpacity>
        </View>
      </View>
      {showDetail && <ActivityDetailModal activity={activity} onClose={() => setShowDetail(false)} topicColor={topicColor} />}
    </>
  );
}

function MetaChip({ icon, text, color }: { icon: any; text: string; color: string }) {
  const colors = useColors();
  if (!text) return null;
  return (
    <View style={[styles.metaChip, { backgroundColor: color + "15" }]}>
      <Feather name={icon} size={11} color={color} />
      <Text style={[styles.metaChipText, { color, fontFamily: "Inter_500Medium" }]}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 18, borderWidth: 1, marginBottom: 14, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.08, shadowRadius: 12, elevation: 4 },
  cardHeader: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", padding: 14, gap: 10 },
  iconBg: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  title: { fontSize: 14, lineHeight: 20, marginBottom: 6 },
  topicBadge: { alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 },
  topicText: { fontSize: 10 },
  deleteBtn: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  body: { padding: 14, paddingTop: 10 },
  desc: { fontSize: 13, lineHeight: 20, marginBottom: 12 },
  metaRow: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginBottom: 10 },
  metaChip: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  metaChipText: { fontSize: 11 },
  skillsRow: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginBottom: 14 },
  skillChip: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  skillText: { fontSize: 11 },
  detailBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, borderRadius: 12, paddingVertical: 12 },
  detailBtnText: { color: "#fff", fontSize: 13 },
});

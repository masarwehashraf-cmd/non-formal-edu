import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export type UserRole = "student" | "teacher" | "supervisor" | "admin" | "guest" | string;

export interface RolePermissions {
  canViewHome: boolean;
  canViewEvents: boolean; canAddEvents: boolean; canDeleteEvents: boolean; canEditEvents: boolean;
  canViewActivities: boolean; canAddActivities: boolean; canDeleteActivities: boolean; canEditActivities: boolean;
  canViewAntiViolence: boolean; canAddAntiViolencePosts: boolean; canDeleteAntiViolencePosts: boolean; canUploadMedia: boolean;
  canViewTopics: boolean; canManageTopics: boolean;
  canViewChat: boolean; canUsePersonalChat: boolean; canCreateGroups: boolean; canApproveChatRequests: boolean; canRequestHelp: boolean;
  canViewMembers: boolean; canViewTotalMembers: boolean; canManageUsers: boolean;
  canViewReports: boolean; canExportData: boolean; canAccessAI: boolean;
  canViewAnnouncements: boolean; canAddAnnouncements: boolean; canDeleteAnnouncements: boolean; canSendNotifications: boolean;
  canViewAdminPanel: boolean; canManageContent: boolean; canManageVisibility: boolean; canManageRoles: boolean; canManageSecurity: boolean; canManageSettings: boolean;
  canChangeOwnPassword: boolean; canChangeProfile: boolean;
}

export const ALL_PERMISSION_KEYS: Array<{ key: keyof RolePermissions; label: string; group: string }> = [
  { key: "canViewHome", label: "عرض الرئيسية", group: "التنقل والصفحات" },
  { key: "canViewEvents", label: "عرض الفعاليات", group: "الفعاليات" },
  { key: "canAddEvents", label: "إضافة فعاليات", group: "الفعاليات" },
  { key: "canDeleteEvents", label: "حذف فعاليات", group: "الفعاليات" },
  { key: "canEditEvents", label: "تعديل فعاليات", group: "الفعاليات" },
  { key: "canViewActivities", label: "عرض الأنشطة", group: "الأنشطة" },
  { key: "canAddActivities", label: "إضافة أنشطة", group: "الأنشطة" },
  { key: "canDeleteActivities", label: "حذف أنشطة", group: "الأنشطة" },
  { key: "canEditActivities", label: "تعديل أنشطة", group: "الأنشطة" },
  { key: "canViewAntiViolence", label: "عرض قسم ضد العنف", group: "معاً ضد العنف" },
  { key: "canAddAntiViolencePosts", label: "إضافة منشورات ضد العنف", group: "معاً ضد العنف" },
  { key: "canDeleteAntiViolencePosts", label: "حذف منشورات ضد العنف", group: "معاً ضد العنف" },
  { key: "canUploadMedia", label: "رفع صور وفيديوهات", group: "الوسائط" },
  { key: "canViewTopics", label: "عرض المواضيع", group: "المواضيع" },
  { key: "canManageTopics", label: "إدارة المواضيع", group: "المواضيع" },
  { key: "canViewChat", label: "عرض الدردشة", group: "الدردشة" },
  { key: "canUsePersonalChat", label: "دردشة شخصية", group: "الدردشة" },
  { key: "canCreateGroups", label: "إنشاء مجموعات", group: "الدردشة" },
  { key: "canApproveChatRequests", label: "قبول/رفض طلبات الدردشة", group: "الدردشة" },
  { key: "canRequestHelp", label: "ظهور ضمن طلب المساعدة", group: "الدردشة" },
  { key: "canViewMembers", label: "عرض الأعضاء", group: "الأعضاء" },
  { key: "canViewTotalMembers", label: "عدد الأعضاء الكلي", group: "الأعضاء" },
  { key: "canManageUsers", label: "إدارة المستخدمين", group: "الأعضاء" },
  { key: "canViewReports", label: "عرض التقارير", group: "البيانات" },
  { key: "canExportData", label: "تصدير البيانات", group: "البيانات" },
  { key: "canAccessAI", label: "المساعد الذكي", group: "الميزات" },
  { key: "canViewAnnouncements", label: "عرض الإعلانات", group: "الإعلانات" },
  { key: "canAddAnnouncements", label: "إضافة إعلانات", group: "الإعلانات" },
  { key: "canDeleteAnnouncements", label: "حذف إعلانات", group: "الإعلانات" },
  { key: "canSendNotifications", label: "إرسال تنبيهات", group: "الإعلانات" },
  { key: "canViewAdminPanel", label: "لوحة الإدارة", group: "الإدارة" },
  { key: "canManageContent", label: "إدارة المحتوى", group: "الإدارة" },
  { key: "canManageVisibility", label: "إخفاء وإظهار الأقسام", group: "الإدارة" },
  { key: "canManageRoles", label: "إدارة الرتب والصلاحيات", group: "الإدارة" },
  { key: "canManageSecurity", label: "إدارة الأمان", group: "الإدارة" },
  { key: "canManageSettings", label: "إعدادات التطبيق", group: "الإدارة" },
  { key: "canChangeOwnPassword", label: "تغيير كلمة المرور", group: "الحساب" },
  { key: "canChangeProfile", label: "تعديل الملف الشخصي", group: "الحساب" },
];

export const ROLE_PERMISSIONS: Record<string, Partial<RolePermissions>> = {
  guest: {
    canViewEvents: true, canAddEvents: false, canDeleteEvents: false, canEditEvents: false,
    canViewActivities: true, canAddActivities: false, canDeleteActivities: false,
    canViewMembers: false, canViewTotalMembers: false, canManageUsers: false,
    canViewReports: false, canExportData: false, canAccessAI: true,
    canViewAnnouncements: true, canAddAnnouncements: false, canDeleteAnnouncements: false,
    canViewAdminPanel: false, canManageContent: false,
  },
  student: {
    canViewEvents: true, canAddEvents: false, canDeleteEvents: false, canEditEvents: false,
    canViewActivities: true, canAddActivities: false, canDeleteActivities: false,
    canViewMembers: false, canViewTotalMembers: false, canManageUsers: false,
    canViewReports: false, canExportData: false, canAccessAI: true,
    canViewAnnouncements: true, canAddAnnouncements: false, canDeleteAnnouncements: false,
    canViewAdminPanel: false, canManageContent: false,
  },
  teacher: {
    canViewEvents: true, canAddEvents: true, canDeleteEvents: false, canEditEvents: true,
    canViewActivities: true, canAddActivities: true, canDeleteActivities: false,
    canViewMembers: true, canViewTotalMembers: false, canManageUsers: false,
    canViewReports: true, canExportData: false, canAccessAI: true,
    canViewAnnouncements: true, canAddAnnouncements: true, canDeleteAnnouncements: false,
    canViewAdminPanel: false, canManageContent: true,
  },
  supervisor: {
    canViewEvents: true, canAddEvents: true, canDeleteEvents: true, canEditEvents: true,
    canViewActivities: true, canAddActivities: true, canDeleteActivities: true,
    canViewMembers: true, canViewTotalMembers: true, canManageUsers: false,
    canViewReports: true, canExportData: true, canAccessAI: true,
    canViewAnnouncements: true, canAddAnnouncements: true, canDeleteAnnouncements: true,
    canViewAdminPanel: false, canManageContent: true,
  },
  admin: {
    canViewEvents: true, canAddEvents: true, canDeleteEvents: true, canEditEvents: true,
    canViewActivities: true, canAddActivities: true, canDeleteActivities: true,
    canViewMembers: true, canViewTotalMembers: true, canManageUsers: true,
    canViewReports: true, canExportData: true, canAccessAI: true,
    canViewAnnouncements: true, canAddAnnouncements: true, canDeleteAnnouncements: true,
    canViewAdminPanel: true, canManageContent: true,
  },
};


export const normalizePermissions = (perms: Partial<RolePermissions>): RolePermissions => ({
  ...ROLE_PERMISSIONS.student,
  ...perms,
});

export const ROLE_LABELS: Record<string, string> = {
  guest: "زائر", student: "طالب", teacher: "معلم", supervisor: "مشرف", admin: "مدير",
};

export const ROLE_DESCRIPTIONS: Record<string, string> = {
  guest: "مشاهدة الفعاليات والأنشطة فقط",
  student: "عرض الفعاليات والأنشطة والوصول للمساعد الذكي",
  teacher: "إضافة الفعاليات والأنشطة وعرض التقارير",
  supervisor: "صلاحيات إدارة كاملة للفعاليات والأنشطة",
  admin: "كامل الصلاحيات — وصول كامل لجميع أجزاء التطبيق",
};

export interface CustomRole {
  id: string; name: string; color: string; description: string; permissions: RolePermissions; createdAt: string;
}

export interface AppSettings {
  appName: string; subtitle: string; footerName: string; footerSupervisor: string;
  homeWelcomeTitle: string; homeWelcomeSubtitle: string;
  eventsPageTitle: string; eventsPageSubtitle: string;
  activitiesPageTitle: string; activitiesPageSubtitle: string;
  antivioPageTitle: string; antivioPageDesc: string;
  topicsPageTitle: string; topicsPageSubtitle: string;
  aiPageTitle: string; loginTitle: string; loginSubtitle: string;
  hiddenTabs: string; hiddenFeatures: string; maintenanceMessage: string;
}

export interface Event {
  id: string; title: string; description: string; date: string; time: string; location: string;
  address: string; category: string; targetAudience: string; ageRange: string; duration: string;
  capacity: string; materials: string; objectives: string; presentationMethod: string; steps: string;
  expectedOutcomes: string; prerequisites: string; organizer: string; contact: string; createdAt: string;
}

export interface Activity {
  id: string; title: string; description: string; topic: string; targetAge: string; duration: string;
  skills: string[]; steps: string; materials: string; evaluation: string; createdAt: string;
}

export interface Announcement {
  id: string; title: string; content: string; priority: "low" | "medium" | "high"; createdAt: string;
}

export interface AntiViolencePost {
  id: string; title: string; content: string; mediaType: "text" | "image" | "video";
  mediaUrl?: string; author: string; date: string; createdAt: string;
}

interface AppContextType {
  events: Event[]; addEvent: (event: Omit<Event, "id" | "createdAt">) => void; deleteEvent: (id: string) => void;
  activities: Activity[]; addActivity: (activity: Omit<Activity, "id" | "createdAt">) => void; deleteActivity: (id: string) => void;
  announcements: Announcement[]; addAnnouncement: (ann: Omit<Announcement, "id" | "createdAt">) => void; deleteAnnouncement: (id: string) => void;
  antiViolencePosts: AntiViolencePost[]; addAntiViolencePost: (post: Omit<AntiViolencePost, "id" | "createdAt">) => void; deleteAntiViolencePost: (id: string) => void;
  customRoles: CustomRole[]; addCustomRole: (role: Omit<CustomRole, "id" | "createdAt">) => void; deleteCustomRole: (id: string) => void; updateCustomRole: (id: string, role: Partial<CustomRole>) => void;
  appSettings: AppSettings; updateAppSetting: (key: keyof AppSettings, value: string) => void; bulkUpdateAppSettings: (updates: Partial<AppSettings>) => Promise<void>;
  totalMembers: number; getPermissions: (role: UserRole) => RolePermissions;
}

const AppContext = createContext<AppContextType | null>(null);
const NOW = new Date().toISOString();

const DEFAULT_APP_SETTINGS: AppSettings = {
  appName: "التربية غير المنهجية",
  subtitle: "منصة التعلم والتطوير خارج المنهج",
  footerName: "دعاء مقاري",
  footerSupervisor: "أشرف مصاروة",
  homeWelcomeTitle: "التربية غير المنهجية",
  homeWelcomeSubtitle: "منصة التعلم والتطوير خارج المنهج",
  eventsPageTitle: "الفعاليات التربوية",
  eventsPageSubtitle: "اكتشف الفعاليات والأنشطة القادمة",
  activitiesPageTitle: "الأنشطة التعليمية",
  activitiesPageSubtitle: "أنشطة تربوية متنوعة لتطوير المهارات",
  antivioPageTitle: "معاً ضد العنف",
  antivioPageDesc: "نبني مجتمعاً آمناً خالياً من العنف من خلال التوعية والحوار",
  topicsPageTitle: "المواضيع التربوية",
  topicsPageSubtitle: "اكتشف المواضيع الـ12 في التربية غير المنهجية",
  aiPageTitle: "المساعد الذكي",
  loginTitle: "تسجيل الدخول",
  loginSubtitle: "أدخل بياناتك للوصول إلى التطبيق",
  hiddenTabs: "",
  hiddenFeatures: "",
  maintenanceMessage: "",
};

const INITIAL_EVENTS: Event[] = [
  {
    id: "1001", title: "ورشة القيادة والتواصل الفعّال", description: "ورشة عمل متكاملة تهدف إلى تطوير مهارات القيادة والتواصل لدى الطلاب من خلال أنشطة تفاعلية ونقاشات جماعية.",
    date: "2026-05-10", time: "09:00", location: "مركز الشباب", address: "مركز الشباب الثقافي، الطابق الثاني",
    category: "ورشة عمل", targetAudience: "طلاب المرحلة الثانوية", ageRange: "15-18 سنة", duration: "3 ساعات", capacity: "25 مشارك",
    materials: "أوراق عمل، أقلام ملونة، بطاقات الأدوار، لوحة العصف الذهني",
    objectives: "تعزيز مهارات القيادة، تطوير التواصل الفعّال، بناء فريق متماسك",
    presentationMethod: "المنهجية التفاعلية: تبدأ بجلسة تعريفية ثم أنشطة جماعية ثم عروض تقديمية.",
    steps: "1. استقبال المشاركين وكسر الجليد\n2. تقسيم المجموعات\n3. تقديم سيناريو القيادة\n4. نشاط تمثيل الأدوار\n5. مناقشة جماعية\n6. تلخيص وختام",
    expectedOutcomes: "القدرة على قيادة فريق، التعبير عن الرأي بثقة",
    prerequisites: "لا توجد متطلبات مسبقة", organizer: "قسم التربية غير المنهجية", contact: "info@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1002", title: "يوم البيئة والاستدامة", description: "فعالية بيئية شاملة تجمع الطلاب من مختلف الشعب لتعزيز الوعي البيئي عبر أنشطة تشجير وورش توعوية.",
    date: "2026-05-18", time: "08:30", location: "المتنزه العام", address: "حديقة المدينة الكبرى",
    category: "فعالية بيئية", targetAudience: "جميع الطلاب والمعلمون", ageRange: "جميع الأعمار", duration: "6 ساعات", capacity: "200 مشارك",
    materials: "شتلات أشجار، معدات حديقة، مواد توعوية",
    objectives: "نشر الوعي البيئي، تعزيز التطوع، تطبيق مفاهيم الاستدامة",
    presentationMethod: "تُنظّم على شكل محطات: كل محطة تحتوي على نشاط مختلف.",
    steps: "1. افتتاح رسمي\n2. جولة في المحطات\n3. زرع 100 شجرة\n4. فرز النفايات\n5. عرض مسرحي بيئي\n6. مسابقة وجوائز",
    expectedOutcomes: "زرع 100 شجرة، رفع الوعي لـ200 طالب",
    prerequisites: "ملابس مريحة للعمل الخارجي", organizer: "نادي البيئة", contact: "eco@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1003", title: "مسابقة الإبداع والابتكار 2026", description: "مسابقة علمية وإبداعية تتيح للطلاب تقديم مشاريع مبتكرة تحل مشكلات حقيقية في مجتمعهم.",
    date: "2026-06-01", time: "10:00", location: "قاعة المؤتمرات الكبرى", address: "مبنى الإدارة التعليمية",
    category: "مسابقة", targetAudience: "طلاب المراحل الأساسية والثانوية", ageRange: "12-18 سنة", duration: "يومان", capacity: "60 فريق",
    materials: "أدوات علمية، مواد خام، أجهزة حاسوب",
    objectives: "تحفيز التفكير الإبداعي، تطوير حل المشكلات",
    presentationMethod: "تقديم المشاريع أمام لجنة تحكيم: 10 دقائق عرض + 5 دقائق أسئلة.",
    steps: "1. التسجيل المسبق\n2. جلسة توجيهية\n3. فترة التصميم والبناء\n4. العروض أمام اللجنة\n5. التصويت والجوائز",
    expectedOutcomes: "30 مشروع مبتكر، جوائز للفرق الثلاثة الأولى",
    prerequisites: "تقديم ملخص المشروع قبل أسبوعين", organizer: "إدارة التربية غير المنهجية", contact: "innovation@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1004", title: "مبادرة اقرأ وشارك — نادي الكتاب", description: "مبادرة شهرية تجمع محبي القراءة لمناقشة كتاب مختار جماعياً.",
    date: "2026-05-22", time: "17:00", location: "المكتبة", address: "مبنى المكتبة، الطابق الأول",
    category: "مبادرة", targetAudience: "الطلاب وهواة القراءة", ageRange: "13-18 سنة", duration: "ساعتان", capacity: "20 مشارك",
    materials: "نسخ الكتاب المختار، دفاتر ملاحظات، أقلام",
    objectives: "تعزيز عادة القراءة، تطوير التفكير النقدي",
    presentationMethod: "جلسة حلقية: الجميع يجلس في دائرة. المحاور يطرح أسئلة مفتوحة.",
    steps: "1. تقديم الكتاب\n2. مشاركة المؤثرين\n3. نقاش حر\n4. استخلاص الدروس\n5. التصويت على كتاب الشهر القادم",
    expectedOutcomes: "ملخص جماعي للكتاب منشور على لوحة المدرسة",
    prerequisites: "قراءة الكتاب المحدد مسبقاً", organizer: "نادي الكتاب", contact: "reading@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1005", title: "معسكر بناء الفريق — أبطال الغد", description: "معسكر يومي مكثف يجمع الطلاب في تحديات جماعية لبناء الثقة والتعاون.",
    date: "2026-06-10", time: "08:00", location: "المركز الرياضي", address: "الملاعب الخارجية",
    category: "ورشة عمل", targetAudience: "طلاب الصف العاشر والحادي عشر", ageRange: "15-17 سنة", duration: "8 ساعات", capacity: "80 مشارك",
    materials: "ملابس رياضية، حبال، أعلام ملونة، ألعاب تعاونية",
    objectives: "تعزيز روح الفريق، كسر الحواجز الاجتماعية",
    presentationMethod: "8 فرق مختلطة. كل فريق يمر بـ5 محطات تحدي مختلفة.",
    steps: "1. تكوين الفرق + تصميم شعار\n2. تحدي الثقة\n3. تحدي التواصل\n4. تحدي التخطيط\n5. تحدي الإبداع\n6. تكريم",
    expectedOutcomes: "تكوين صداقات جديدة، رفع الروح الجماعية",
    prerequisites: "ملابس رياضية مريحة", organizer: "فريق التربية غير المنهجية", contact: "camp@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1006", title: "ندوة ريادة الأعمال الشبابية", description: "ندوة تجمع رواد أعمال شباباً ناجحين يشاركون تجاربهم الحقيقية.",
    date: "2026-05-28", time: "16:00", location: "قاعة الاجتماعات", address: "الطابق الثالث، مبنى الإدارة",
    category: "ندوة", targetAudience: "طلاب المرحلة الثانوية", ageRange: "16-22 سنة", duration: "3 ساعات", capacity: "100 مشارك",
    materials: "ميكروفونات، شاشة عرض، كتيّب الندوة",
    objectives: "إلهام الطلاب بالنماذج الناجحة، كسر مخاوف الفشل",
    presentationMethod: "3 متحدثون ثم جلسة أسئلة مفتوحة لـ60 دقيقة.",
    steps: "1. كلمة افتتاحية\n2. عرض المتحدث الأول\n3. عرض المتحدث الثاني\n4. عرض المتحدث الثالث\n5. جلسة أسئلة",
    expectedOutcomes: "إطلاق 5 أفكار مشاريع طلابية",
    prerequisites: "إحضار فكرة مشروع أو سؤال محدد", organizer: "مركز ريادة الأعمال", contact: "startup@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1007", title: "مبادرة السلام الاجتماعي — جسور التفاهم", description: "مبادرة مجتمعية تجمع شباباً من خلفيات متنوعة في ورش حوار بنّاء.",
    date: "2026-06-05", time: "10:00", location: "قاعة الاحتفالات", address: "الطابق الأرضي، المبنى الرئيسي",
    category: "مبادرة", targetAudience: "الشباب من جميع المدارس", ageRange: "14-20 سنة", duration: "4 ساعات", capacity: "60 مشارك",
    materials: "أوراق سيناريوهات، بطاقات القيم، لوح التعهدات",
    objectives: "تعزيز قبول الاختلاف، تطوير مهارات الوساطة",
    presentationMethod: "مجموعات مختلطة تعمل على سيناريوهات نزاع حقيقية.",
    steps: "1. كسر الجليد\n2. شرح مفهوم قبول الاختلاف\n3. العمل على سيناريو النزاع\n4. عروض الحلول\n5. توقيع ميثاق السلام",
    expectedOutcomes: "ميثاق قيم مشترك، تدريب 10 وسطاء شباب",
    prerequisites: "الانفتاح وتقبّل الآراء المختلفة", organizer: "برنامج التعايش", contact: "peace@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1008", title: "يوم الموهبة والإبداع الفني", description: "يوم احتفالي يستعرض فيه الطلاب مواهبهم الفنية في الرسم والشعر والغناء والمسرح.",
    date: "2026-06-15", time: "10:00", location: "المسرح المدرسي", address: "قاعة المسرح",
    category: "فعالية بيئية", targetAudience: "جميع الطلاب", ageRange: "جميع الأعمار", duration: "5 ساعات", capacity: "300 مشارك",
    materials: "أدوات الرسم، ميكروفونات، آلات موسيقية",
    objectives: "اكتشاف المواهب، تعزيز الثقة بالنفس",
    presentationMethod: "عروض متتالية على المسرح: 5-10 دقائق لكل مشارك.",
    steps: "1. التسجيل المسبق\n2. بروفة عامة\n3. حفل الافتتاح\n4. عروض المتسابقين\n5. تصويت الجمهور\n6. توزيع الجوائز",
    expectedOutcomes: "اكتشاف 20 موهبة جديدة",
    prerequisites: "التسجيل المسبق قبل أسبوع", organizer: "نادي الفنون", contact: "arts@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1009", title: "تدريب الإسعافات الأولية للطلاب", description: "دورة عملية مكثفة في الإسعافات الأولية والإنقاذ الأساسي.",
    date: "2026-06-20", time: "09:00", location: "صالة التدريب", address: "مركز الصحة المدرسي",
    category: "ورشة عمل", targetAudience: "جميع الطلاب", ageRange: "12-18 سنة", duration: "4 ساعات", capacity: "30 مشارك",
    materials: "دمى الإسعاف، ضمادات، جهاز إنعاش قلبي تدريبي",
    objectives: "تعلم الإسعافات الأولية، التعامل مع الطوارئ",
    presentationMethod: "نظري + تطبيق عملي. نسبة التطبيق 70%.",
    steps: "1. نظرية الإسعاف (30 دق)\n2. الجروح والنزيف (60 دق)\n3. CPR (90 دق)\n4. حالات الاختناق\n5. اختبار وشهادات",
    expectedOutcomes: "30 طالب حاصل على شهادة الإسعاف الأولي",
    prerequisites: "لا متطلبات — مفتوح للجميع", organizer: "الهلال الأحمر التعليمي", contact: "health@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1010", title: "ورشة التصوير الفوتوغرافي — عين الإبداع", description: "ورشة تعلّم الطلاب أساسيات التصوير الفوتوغرافي والتعبير الفني.",
    date: "2026-07-01", time: "10:00", location: "الفضاء المفتوح", address: "ساحة المدرسة والحديقة",
    category: "ورشة عمل", targetAudience: "الطلاب المهتمون بالفن", ageRange: "13-18 سنة", duration: "3 ساعات", capacity: "20 مشارك",
    materials: "كاميرات (هاتف ذكي أو كاميرا)، بطاقة مهام التصوير",
    objectives: "تعلم أساسيات التصوير، بناء عين فنية",
    presentationMethod: "شرح نظري + تصوير حر في الخارج + عرض ومناقشة.",
    steps: "1. قواعد التصوير\n2. تمرين التعبير الذاتي\n3. جولة التصوير\n4. اختيار أفضل 3 صور\n5. عرض القصص",
    expectedOutcomes: "معرض صور رقمي للطلاب",
    prerequisites: "هاتف ذكي أو كاميرا رقمية", organizer: "نادي الفنون", contact: "photo@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1011", title: "برنامج التربية المالية للشباب", description: "برنامج تثقيفي يعلّم الطلاب الادخار والميزانية والاستثمار.",
    date: "2026-07-08", time: "11:00", location: "قاعة التدريب", address: "مبنى الأنشطة",
    category: "ورشة عمل", targetAudience: "طلاب المرحلة الثانوية", ageRange: "14-18 سنة", duration: "ساعتان ونصف", capacity: "35 مشارك",
    materials: "عملة ورقية تعليمية، أوراق الميزانية، بطاقات السيناريوهات",
    objectives: "فهم الميزانية، الادخار كعادة، التمييز بين الضروري والترفيه",
    presentationMethod: "محاكاة اقتصادية: كل مشارك يدير ميزانيته الشهرية.",
    steps: "1. شرح الدخل والمصروف\n2. محاكاة الميزانية\n3. لعبة السوق\n4. التقييم\n5. خطة الادخار الشخصية",
    expectedOutcomes: "كل طالب يضع خطة ادخار شهرية",
    prerequisites: "لا يشترط خلفية مسبقة", organizer: "مركز التربية غير المنهجية", contact: "finance@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1012", title: "رحلة التعلم الميداني — استكشاف المجتمع", description: "رحلة تعليمية يزور فيها الطلاب مؤسسات مجتمعية متنوعة.",
    date: "2026-07-15", time: "08:00", location: "المؤسسات المجتمعية", address: "نقطة التجمع: باب المدرسة",
    category: "رحلة", targetAudience: "طلاب الصف التاسع والعاشر", ageRange: "14-16 سنة", duration: "يوم كامل", capacity: "45 مشارك",
    materials: "دفتر ملاحظات، أقلام، كاميرا، استمارة الرحلة",
    objectives: "ربط التعلم بالواقع، فهم المهن المختلفة",
    presentationMethod: "زيارة 3-4 مؤسسات: في كل مؤسسة شرح وأسئلة وملاحظات.",
    steps: "1. التوجيه (20 دق)\n2. زيارة المؤسسة الأولى\n3. زيارة المؤسسة الثانية\n4. زيارة الثالثة\n5. غداء وراحة\n6. تقرير جماعي",
    expectedOutcomes: "تقرير ميداني + عرض تقديمي للمدرسة",
    prerequisites: "دفتر ملاحظات + ملابس رسمية مناسبة", organizer: "قسم التربية الميدانية", contact: "field@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1013", title: "ليلة الثقافة العالمية", description: "احتفالية تجمع طلاباً من ثقافات مختلفة يشاركون أكلاتهم التراثية وفنونهم.",
    date: "2026-07-22", time: "17:00", location: "قاعة الأنشطة", address: "الطابق الأول، مبنى الأنشطة",
    category: "مبادرة", targetAudience: "جميع الطلاب والمعلمون وأولياء الأمور", ageRange: "جميع الأعمار", duration: "4 ساعات", capacity: "150 مشارك",
    materials: "أطباق الطعام، ملابس تراثية، ديكورات ثقافية",
    objectives: "تعزيز التنوع الثقافي، قبول الاختلاف",
    presentationMethod: "بوفيه تراثي + عروض ثقافية لكل مجموعة.",
    steps: "1. توزيع الثقافات\n2. تحضير عرض ثقافي\n3. إعداد طبق تراثي\n4. الحفل وجولة الثقافات\n5. العروض والتكريم",
    expectedOutcomes: "كتاب ثقافي مشترك + ألبوم صور",
    prerequisites: "كل مشارك يحضر شيئاً يمثل ثقافته", organizer: "مجلس الطلاب", contact: "culture@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1014", title: "برنامج التطوع المجتمعي الشامل", description: "برنامج تطوعي منظم يشارك فيه الطلاب في خدمة مجتمعهم.",
    date: "2026-08-01", time: "09:00", location: "مواقع مجتمعية متعددة", address: "نقطة التجمع: المدرسة",
    category: "تطوعي", targetAudience: "جميع الطلاب المتطوعون", ageRange: "جميع الأعمار", duration: "يوم كامل", capacity: "120 مشارك",
    materials: "هدايا للمستفيدين، أدوات تنظيف، مواد إبداعية للأطفال",
    objectives: "تنمية روح التطوع، المسؤولية الاجتماعية",
    presentationMethod: "4 فرق تنفذ مبادرات منفصلة ثم تجتمع للمشاركة.",
    steps: "1. تقييم صباحي\n2. فريق زيارة المرضى\n3. فريق أطفال دار الأيتام\n4. فريق كبار السن\n5. فريق تنظيف الحديقة\n6. اجتماع ختامي",
    expectedOutcomes: "100+ ساعة تطوع موثقة، شهادات تقدير",
    prerequisites: "التسجيل المسبق، روح المبادرة", organizer: "برنامج التطوع الطلابي", contact: "volunteer@tarbiya.edu", createdAt: NOW,
  },
  {
    id: "1015", title: "ورشة كتابة القصة والسيناريو", description: "ورشة إبداعية تعلّم الطلاب أساسيات الكتابة الأدبية والسيناريو.",
    date: "2026-08-10", time: "10:00", location: "قاعة التدريب", address: "مبنى الأنشطة، الطابق الثاني",
    category: "ورشة عمل", targetAudience: "الطلاب المهتمون بالكتابة", ageRange: "13-18 سنة", duration: "ساعتان ونصف", capacity: "25 مشارك",
    materials: "أوراق الكتابة الإبداعية، بطاقات الإلهام، أقلام",
    objectives: "تعلم تقنيات الكتابة، تطوير الخيال",
    presentationMethod: "قرأ → فهم → طبّق: كل مفهوم يُشرح ثم يطبّقه الطلاب فوراً.",
    steps: "1. ما مكونات القصة الجيدة؟\n2. تمرين: أول سطر مثير\n3. شرح الشخصية والصراع\n4. كتابة قصة قصيرة\n5. عرض وتغذية راجعة",
    expectedOutcomes: "مجموعة قصصية منشورة في مجلة المدرسة",
    prerequisites: "حب القراءة والكتابة", organizer: "نادي القراءة والكتابة", contact: "writing@tarbiya.edu", createdAt: NOW,
  },
];

const INITIAL_ACTIVITIES: Activity[] = [
  {
    id: "2000", title: "عصف ذهني جماعي", description: "نشاط جماعي لتحفيز التفكير الإبداعي من خلال طرح أسئلة مفتوحة.",
    topic: "التفكير الإبداعي", targetAge: "12-18 سنة", duration: "45 دقيقة",
    skills: ["التفكير النقدي", "التواصل", "العمل الجماعي"],
    steps: "1. تحديد الموضوع\n2. الكتابة الفردية (5 دق)\n3. المشاركة الجماعية\n4. التصنيف والترتيب",
    materials: "لوح أبيض، أقلام ملونة، ملاحظات لاصقة",
    evaluation: "عدد الأفكار، جودة التفاعل، تنوع الحلول", createdAt: NOW,
  },
  {
    id: "2001", title: "لعبة أدوار القيادة", description: "تمثيل أدوار مواقف حياتية تتطلب قرارات قيادية وإدارة الفرق.",
    topic: "القيادة والإدارة", targetAge: "14-18 سنة", duration: "60 دقيقة",
    skills: ["القيادة", "اتخاذ القرار", "التواصل", "إدارة النزاع"],
    steps: "1. توزيع الأدوار\n2. قراءة السيناريو\n3. التمثيل (25 دق)\n4. وقف + خروج من الدور\n5. تقييم جماعي",
    materials: "بطاقات الأدوار، أوراق السيناريو، عصابات ملونة",
    evaluation: "جودة القرارات، التفاعل الإيجابي مع الفريق", createdAt: NOW,
  },
  {
    id: "2002", title: "نشاط التعاون والثقة", description: "سلسلة ألعاب جماعية متصاعدة لبناء الثقة بين أعضاء المجموعة.",
    topic: "بناء الفريق", targetAge: "10-16 سنة", duration: "90 دقيقة",
    skills: ["التعاون", "الثقة", "التنسيق", "التواصل غير اللفظي"],
    steps: "1. لعبة العمياء (15 دق)\n2. بناء البرج (30 دق)\n3. الحبل المتشابك (20 دق)\n4. جسر الثقة\n5. تأمل جماعي",
    materials: "عصابات العيون، مكعبات بناء، حبل طويل",
    evaluation: "مستوى التعاون والتواصل، نجاح المهام الجماعية", createdAt: NOW,
  },
  {
    id: "2003", title: "ورشة التفكير التصميمي", description: "تطبيق منهجية التفكير التصميمي لحل مشكلة حقيقية من الحياة اليومية.",
    topic: "التفكير الإبداعي", targetAge: "14-18 سنة", duration: "120 دقيقة",
    skills: ["التفكير التصميمي", "التعاطف", "النمذجة السريعة", "الإبداع"],
    steps: "1. التعاطف (15 دق)\n2. تعريف المشكلة (10 دق)\n3. عصف ذهني: 20 فكرة\n4. بناء نموذج (40 دق)\n5. اختبار + تحسين",
    materials: "ورق مقوى، غراء، مقص، ملاحظات لاصقة",
    evaluation: "وضوح المشكلة، إبداع الحل، جودة النموذج", createdAt: NOW,
  },
  {
    id: "2004", title: "دائرة المشاعر — الصحة النفسية", description: "جلسة آمنة لاستكشاف المشاعر والتعبير عنها بأمان.",
    topic: "الصحة النفسية", targetAge: "12-17 سنة", duration: "50 دقيقة",
    skills: ["الذكاء العاطفي", "التعبير الآمن", "التعاطف", "التنظيم الذاتي"],
    steps: "1. بطاقات المشاعر\n2. الشرح: كل مشعر مقبول\n3. دائرة المشاركة\n4. تقنية التنفس 4-7-8\n5. رسالة لنفسك",
    materials: "بطاقات المشاعر، دفاتر صغيرة، موسيقى هادئة",
    evaluation: "مستوى الانفتاح، الوعي بالمشاعر، التعاطف", createdAt: NOW,
  },
  {
    id: "2005", title: "مسرحية 5 دقائق", description: "فرق صغيرة تكتب وتؤدي مسرحية قصيرة عن قضية اجتماعية.",
    topic: "الفنون", targetAge: "12-18 سنة", duration: "75 دقيقة",
    skills: ["التعبير الإبداعي", "التعاون", "التواصل", "الإقناع"],
    steps: "1. اختيار القضية (قرعة)\n2. كتابة السيناريو (15 دق)\n3. توزيع الأدوار (15 دق)\n4. الأداء\n5. تقييم الجمهور",
    materials: "ورق للكتابة، أدوات بسيطة، بطاقات القضايا، موقت",
    evaluation: "وضوح الرسالة، قوة الأداء، التأثير العاطفي", createdAt: NOW,
  },
  {
    id: "2006", title: "يوم المبادر — مشروع خير", description: "كل مجموعة تصمم وتنفذ مبادرة خيرية صغيرة ملموسة.",
    topic: "المواطنة", targetAge: "13-18 سنة", duration: "5 ساعات",
    skills: ["المبادرة", "التخطيط", "التطوع", "خدمة المجتمع"],
    steps: "1. تحديد مشكلة (30 دق)\n2. التخطيط (30 دق)\n3. التنفيذ (3 ساعات)\n4. توثيق بالصور\n5. عرض النتائج",
    materials: "مواد التنظيف، أدوات الرسم، كاميرا",
    evaluation: "واقعية المبادرة، الأثر الملموس، الالتزام", createdAt: NOW,
  },
  {
    id: "2007", title: "الذاكرة الثقافية", description: "الطلاب يبحثون ويقدمون عن تراثهم الثقافي المحلي.",
    topic: "التواصل", targetAge: "10-15 سنة", duration: "60 دقيقة",
    skills: ["البحث والاستقصاء", "التواصل", "الانتماء الثقافي"],
    steps: "1. كتابة مثل شعبي\n2. مشاركة وشرح المعاني\n3. مقارنة الأمثال\n4. رسم مثل مفضل",
    materials: "أوراق كبيرة، أقلام ملونة، ألوان مائية",
    evaluation: "الثراء الثقافي، جودة المشاركة", createdAt: NOW,
  },
  {
    id: "2008", title: "تحدي حل الألغاز الجماعية", description: "سلسلة ألغاز ذكية تحتاج تعاوناً جماعياً.",
    topic: "التفكير الإبداعي", targetAge: "11-17 سنة", duration: "60 دقيقة",
    skills: ["التفكير المنطقي", "التعاون", "الصبر", "حل المشكلات"],
    steps: "1. فرق من 4 أشخاص\n2. 10 ألغاز متصاعدة\n3. وقت محدد لكل لغز\n4. الفريق الأول يفوز\n5. مناقشة الاستراتيجيات",
    materials: "بطاقات الألغاز، موقت، أقلام",
    evaluation: "عدد الألغاز المحلولة، الوقت، جودة التعاون", createdAt: NOW,
  },
  {
    id: "2009", title: "جلسة التخطيط الشخصي", description: "كل طالب يضع خطة شخصية لأهدافه للسنة القادمة.",
    topic: "القيادة والإدارة", targetAge: "14-18 سنة", duration: "75 دقيقة",
    skills: ["التخطيط الذاتي", "الأهداف", "إدارة الوقت"],
    steps: "1. تأمل المستقبل (10 دق)\n2. تحديد 3 أهداف كبيرة\n3. تفكيك الأهداف لخطوات\n4. مواعيد نهائية\n5. مشاركة زميل\n6. عقد مع النفس",
    materials: "نموذج الأهداف الذكية، أقلام، ملصقات التحفيز",
    evaluation: "وضوح الأهداف، واقعيتها، الالتزام", createdAt: NOW,
  },
  {
    id: "2010", title: "التعبير بالفن الحر", description: "الطلاب يعبّرون عن أفكارهم بحرية عبر الرسم والتلوين والكولاج.",
    topic: "الفنون", targetAge: "8-16 سنة", duration: "60 دقيقة",
    skills: ["التعبير الإبداعي", "حرية الفكر", "الذكاء العاطفي"],
    steps: "1. الجلوس بشكل دائري\n2. موسيقى هادئة\n3. رسم حر بأي لون (25 دق)\n4. شرح اختياري\n5. معرض اللوحات",
    materials: "ورق A3، ألوان مائية، غراء، مجلات للكولاج",
    evaluation: "مستوى التعبير الحقيقي، الجرأة الفنية", createdAt: NOW,
  },
];

const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: "1", title: "مرحباً بكم في منصة التربية غير المنهجية",
    content: "يسعدنا انضمامكم! استعرضوا الفعاليات والأنشطة المتاحة واستفيدوا منها في رحلتكم التعليمية.",
    priority: "high", createdAt: new Date().toISOString(),
  },
];

const INITIAL_ANTI_VIOLENCE: AntiViolencePost[] = [
  {
    id: "av001", title: "لقاء توعوي: العنف ليس حلاً", content: "عقدنا لقاءً توعوياً جمع أكثر من 80 طالباً لمناقشة آثار العنف وأساليب الوقاية منه. شارك فيه متخصصون في علم النفس الاجتماعي وعرضوا أساليب بديلة لحل النزاعات.", mediaType: "text", author: "فريق التوعية", date: "2026-04-15", createdAt: NOW,
  },
  {
    id: "av002", title: "ورشة الحوار والتسامح", content: "ورشة عملية استهدفت تطوير مهارات الحوار السلمي والتفاوض عند الخلاف. تمكّن المشاركون من اكتساب أدوات عملية للتعامل مع النزاعات بطريقة ناضجة وحضارية.", mediaType: "text", author: "المشرف أشرف مصاروة", date: "2026-03-20", createdAt: NOW,
  },
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [events, setEventsState] = useState<Event[]>(INITIAL_EVENTS);
  const [activities, setActivitiesState] = useState<Activity[]>(INITIAL_ACTIVITIES);
  const [announcements, setAnnouncements] = useState<Announcement[]>(INITIAL_ANNOUNCEMENTS);
  const [antiViolencePosts, setAntiViolencePosts] = useState<AntiViolencePost[]>(INITIAL_ANTI_VIOLENCE);
  const [customRoles, setCustomRoles] = useState<CustomRole[]>([]);
  const [appSettings, setAppSettingsState] = useState<AppSettings>(DEFAULT_APP_SETTINGS);
  const totalMembers = 248;

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const e = await AsyncStorage.getItem("events_v4");
      if (e) setEventsState(JSON.parse(e));
      else await AsyncStorage.setItem("events_v4", JSON.stringify(INITIAL_EVENTS));

      const a = await AsyncStorage.getItem("activities_v4");
      if (a) setActivitiesState(JSON.parse(a));
      else await AsyncStorage.setItem("activities_v4", JSON.stringify(INITIAL_ACTIVITIES));

      const ann = await AsyncStorage.getItem("announcements");
      if (ann) setAnnouncements(JSON.parse(ann));

      const av = await AsyncStorage.getItem("anti_violence_posts");
      if (av) setAntiViolencePosts(JSON.parse(av));

      const cr = await AsyncStorage.getItem("custom_roles");
      if (cr) setCustomRoles(JSON.parse(cr));

      const as = await AsyncStorage.getItem("app_settings");
      if (as) setAppSettingsState({ ...DEFAULT_APP_SETTINGS, ...JSON.parse(as) });
    } catch {}
  };

  const saveEvents = async (evts: Event[]) => { setEventsState(evts); await AsyncStorage.setItem("events_v4", JSON.stringify(evts)); };
  const addEvent = async (d: Omit<Event, "id" | "createdAt">) => { await saveEvents([...events, { ...d, id: Date.now().toString(), createdAt: new Date().toISOString() }]); };
  const deleteEvent = async (id: string) => { await saveEvents(events.filter(e => e.id !== id)); };

  const saveActivities = async (acts: Activity[]) => { setActivitiesState(acts); await AsyncStorage.setItem("activities_v4", JSON.stringify(acts)); };
  const addActivity = async (d: Omit<Activity, "id" | "createdAt">) => { await saveActivities([...activities, { ...d, id: Date.now().toString(), createdAt: new Date().toISOString() }]); };
  const deleteActivity = async (id: string) => { await saveActivities(activities.filter(a => a.id !== id)); };

  const saveAnnouncements = async (ann: Announcement[]) => { setAnnouncements(ann); await AsyncStorage.setItem("announcements", JSON.stringify(ann)); };
  const addAnnouncement = async (d: Omit<Announcement, "id" | "createdAt">) => { await saveAnnouncements([{ ...d, id: Date.now().toString(), createdAt: new Date().toISOString() }, ...announcements]); };
  const deleteAnnouncement = async (id: string) => { await saveAnnouncements(announcements.filter(a => a.id !== id)); };

  const saveAVPosts = async (posts: AntiViolencePost[]) => { setAntiViolencePosts(posts); await AsyncStorage.setItem("anti_violence_posts", JSON.stringify(posts)); };
  const addAntiViolencePost = async (d: Omit<AntiViolencePost, "id" | "createdAt">) => { await saveAVPosts([{ ...d, id: Date.now().toString(), createdAt: new Date().toISOString() }, ...antiViolencePosts]); };
  const deleteAntiViolencePost = async (id: string) => { await saveAVPosts(antiViolencePosts.filter(p => p.id !== id)); };

  const saveCustomRoles = async (roles: CustomRole[]) => { setCustomRoles(roles); await AsyncStorage.setItem("custom_roles", JSON.stringify(roles)); };
  const addCustomRole = async (d: Omit<CustomRole, "id" | "createdAt">) => { await saveCustomRoles([...customRoles, { ...d, id: Date.now().toString(), createdAt: new Date().toISOString() }]); };
  const deleteCustomRole = async (id: string) => { await saveCustomRoles(customRoles.filter(r => r.id !== id)); };
  const updateCustomRole = async (id: string, updates: Partial<CustomRole>) => { await saveCustomRoles(customRoles.map(r => r.id === id ? { ...r, ...updates } : r)); };

  const updateAppSetting = async (key: keyof AppSettings, value: string) => {
    const updated = { ...appSettings, [key]: value };
    setAppSettingsState(updated);
    await AsyncStorage.setItem("app_settings", JSON.stringify(updated));
  };

  const bulkUpdateAppSettings = async (updates: Partial<AppSettings>) => {
    const updated = { ...appSettings, ...updates };
    setAppSettingsState(updated);
    await AsyncStorage.setItem("app_settings", JSON.stringify(updated));
  };

  const getPermissions = (role: UserRole): RolePermissions => {
    if (ROLE_PERMISSIONS[role]) return normalizePermissions(ROLE_PERMISSIONS[role]);
    const custom = customRoles.find(r => r.id === role || r.name === role);
    if (custom) return normalizePermissions(custom.permissions);
    return normalizePermissions(ROLE_PERMISSIONS.student);
  };

  return (
    <AppContext.Provider value={{
      events, addEvent, deleteEvent, activities, addActivity, deleteActivity,
      announcements, addAnnouncement, deleteAnnouncement,
      antiViolencePosts, addAntiViolencePost, deleteAntiViolencePost,
      customRoles, addCustomRole, deleteCustomRole, updateCustomRole,
      appSettings, updateAppSetting, bulkUpdateAppSettings, totalMembers, getPermissions,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

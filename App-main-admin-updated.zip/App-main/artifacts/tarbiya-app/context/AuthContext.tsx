import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { UserRole, RolePermissions } from "./AppContext";

export interface User {
  id: string;
  username: string;
  fullName: string;
  email: string;
  role: UserRole;
  createdAt: string;
  isActive: boolean;
  customPermissions?: Partial<RolePermissions>;
  profilePicture?: string;
}

interface AuthContextType {
  user: User | null;
  allUsers: User[];
  isLoading: boolean;
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (data: RegisterData) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateUserRole: (userId: string, role: UserRole) => Promise<void>;
  toggleUserActive: (userId: string) => Promise<void>;
  deleteUser: (userId: string) => Promise<void>;
  updateUserPermissions: (userId: string, perms: Partial<RolePermissions>) => Promise<void>;
  updateProfilePicture: (picture: string) => Promise<void>;
  exportUsersData: () => Promise<{ fullName: string; username: string; email: string; password: string; role: string; isActive: boolean; createdAt: string }[]>;
}

interface RegisterData {
  username: string;
  password: string;
  fullName: string;
  email: string;
}

interface StoredUser extends User {
  password: string;
}

const ADMIN_USER: StoredUser = {
  id: "admin-001",
  username: "admin",
  fullName: "مدير النظام",
  email: "admin@tarbiya.edu",
  role: "admin",
  password: "Tarbiya@2026",
  createdAt: new Date().toISOString(),
  isActive: true,
};

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => { init(); }, []);

  const getStoredUsers = async (): Promise<StoredUser[]> => {
    const raw = await AsyncStorage.getItem("users_db");
    const users: StoredUser[] = raw ? JSON.parse(raw) : [];
    const hasAdmin = users.find((u) => u.id === ADMIN_USER.id);
    if (!hasAdmin) users.push(ADMIN_USER);
    return users;
  };

  const saveStoredUsers = async (users: StoredUser[]) => {
    await AsyncStorage.setItem("users_db", JSON.stringify(users));
    const publicUsers: User[] = users.map(({ password: _p, ...u }) => u);
    setAllUsers(publicUsers);
    return publicUsers;
  };

  const init = async () => {
    try {
      const users = await getStoredUsers();
      await saveStoredUsers(users);
      const savedUserId = await AsyncStorage.getItem("current_user_id");
      if (savedUserId) {
        const found = users.find((u) => u.id === savedUserId);
        if (found && found.isActive) {
          const { password: _p, ...publicUser } = found;
          setUser(publicUser);
        }
      }
    } catch {}
    setIsLoading(false);
  };

  const login = async (username: string, password: string): Promise<{ success: boolean; error?: string }> => {
    const users = await getStoredUsers();
    const found = users.find(
      (u) => u.username.toLowerCase() === username.toLowerCase() && u.password === password
    );
    if (!found) return { success: false, error: "اسم المستخدم أو كلمة المرور غير صحيحة" };
    if (!found.isActive) return { success: false, error: "هذا الحساب موقوف. تواصل مع المسؤول." };
    const { password: _p, ...publicUser } = found;
    setUser(publicUser);
    await AsyncStorage.setItem("current_user_id", found.id);
    return { success: true };
  };

  const register = async (data: RegisterData): Promise<{ success: boolean; error?: string }> => {
    if (!data.username.trim() || !data.password.trim() || !data.fullName.trim()) {
      return { success: false, error: "جميع الحقول مطلوبة" };
    }
    if (data.password.length < 6) {
      return { success: false, error: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" };
    }
    const users = await getStoredUsers();
    const exists = users.find((u) => u.username.toLowerCase() === data.username.toLowerCase());
    if (exists) return { success: false, error: "اسم المستخدم مستخدم بالفعل" };
    const newUser: StoredUser = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 6),
      username: data.username.trim(),
      fullName: data.fullName.trim(),
      email: data.email.trim(),
      role: "student",
      password: data.password,
      createdAt: new Date().toISOString(),
      isActive: true,
    };
    users.push(newUser);
    await saveStoredUsers(users);
    const { password: _p, ...publicUser } = newUser;
    setUser(publicUser);
    await AsyncStorage.setItem("current_user_id", newUser.id);
    return { success: true };
  };

  const logout = async () => {
    setUser(null);
    await AsyncStorage.removeItem("current_user_id");
  };

  const updateProfilePicture = async (picture: string) => {
    if (!user) return;
    const users = await getStoredUsers();
    const idx = users.findIndex((u) => u.id === user.id);
    if (idx !== -1) {
      users[idx].profilePicture = picture;
      await saveStoredUsers(users);
      setUser({ ...user, profilePicture: picture });
    }
  };

  const exportUsersData = async () => {
    const users = await getStoredUsers();
    return users.map((u) => ({
      fullName: u.fullName,
      username: u.username,
      email: u.email || "",
      password: u.password,
      role: u.role,
      isActive: u.isActive,
      createdAt: u.createdAt,
    }));
  };

  const updateUserRole = async (userId: string, role: UserRole) => {
    const users = await getStoredUsers();
    const idx = users.findIndex((u) => u.id === userId);
    if (idx !== -1) {
      users[idx].role = role;
      await saveStoredUsers(users);
      if (user?.id === userId) setUser({ ...user, role });
    }
  };

  const toggleUserActive = async (userId: string) => {
    const users = await getStoredUsers();
    const idx = users.findIndex((u) => u.id === userId);
    if (idx !== -1) {
      users[idx].isActive = !users[idx].isActive;
      await saveStoredUsers(users);
    }
  };

  const deleteUser = async (userId: string) => {
    const users = await getStoredUsers();
    await saveStoredUsers(users.filter((u) => u.id !== userId));
  };

  const updateUserPermissions = async (userId: string, perms: Partial<RolePermissions>) => {
    const users = await getStoredUsers();
    const idx = users.findIndex((u) => u.id === userId);
    if (idx !== -1) {
      users[idx].customPermissions = Object.keys(perms).length > 0 ? perms : undefined;
      const publicUsers = await saveStoredUsers(users);
      if (user?.id === userId) {
        const updated = publicUsers.find(u => u.id === userId);
        if (updated) setUser(updated);
      }
    }
  };

  return (
    <AuthContext.Provider value={{ user, allUsers, isLoading, login, register, logout, updateUserRole, toggleUserActive, deleteUser, updateUserPermissions, updateProfilePicture, exportUsersData }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

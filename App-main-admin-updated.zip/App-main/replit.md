# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Contains a full-stack mobile app for non-formal education (التربية غير المنهجية) built with Expo React Native, and an Express API server with OpenAI integration.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Mobile**: Expo SDK 54, Expo Router v6
- **AI**: OpenAI via Replit AI Integrations (gpt-5.2)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## App Structure (tarbiya-app)

### Screens
- **Home** (`app/(tabs)/index.tsx`) - Dashboard with stats, announcements, quick actions
- **Events** (`app/(tabs)/events.tsx`) - Browsable/searchable events with add/delete (role-based)
- **Activities** (`app/(tabs)/activities.tsx`) - Educational activities with skills info
- **AI** (`app/(tabs)/ai.tsx`) - AI assistant for non-formal education
- **Topics** (`app/(tabs)/topics.tsx`) - 12 educational topics with activity suggestions

### State Management
- `context/AppContext.tsx` - Stores events, activities, announcements, user role + permissions
- AsyncStorage for persistence

### Role System
5 roles: guest, student, teacher, supervisor, admin
Each role has granular permissions defined in `ROLE_PERMISSIONS`

### AI Integration
- Backend: `/api/ai/chat` endpoint using OpenAI gpt-5.2
- Frontend: Direct fetch in `app/(tabs)/ai.tsx`
- Env vars: `AI_INTEGRATIONS_OPENAI_BASE_URL`, `AI_INTEGRATIONS_OPENAI_API_KEY`

## Features
- Events with full details, category filters, search, add/delete by role
- Activities with skill tags, topic filters
- 12 educational topic templates
- AI assistant with 4 modes (general, activities, leadership, planning)
- Role selector with 5 roles and permission descriptions
- Footer: "مشروع التخرج / دعاء عراقي / أشرف مصاروة"
- Total members only visible to supervisor/admin roles
